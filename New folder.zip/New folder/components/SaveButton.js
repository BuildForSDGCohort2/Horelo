/*Custom Button*/
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
const SaveButton = props => {
    return (
        <TouchableOpacity style={[styles.button, props.style]} onPress={props.customClick}>
            <Text style={styles.text}>{props.title}</Text>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    button: {
        alignItems: 'center',
        backgroundColor: '#091091',
        color: '#ffffff',
        padding: 10,
        marginTop: 5,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 15,
    },
    text: {
        color: '#ffffff',
    },
});
export default SaveButton;