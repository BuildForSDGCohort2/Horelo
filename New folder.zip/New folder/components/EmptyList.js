import React from 'react';
import { StyleSheet, View, Dimensions, Text, Image, ViewPropTypes } from 'react-native';

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;
const s = StyleSheet.create({
  container: {
    margin:1,
  //alignItems: 'center',
  //justifyContent: 'center',
  },
  emptyText: {
    paddingTop: 10,
    textAlign: 'center',
    color: "#5454",
    fontWeight:'bold',
  },
  image: {
    opacity: 0.9,
    width: vw / 1.1,
  },

});

const sadSmile = require('../assets/images/sadSmile.png');

const EmptyList = ({ containerStyle, text = 'There are no transactions' }) => (
  <View style={[s.container, containerStyle]}>
    <Image
      style={s.image}
      resizeMode='contain'
      source={sadSmile}
    />
    <Text style={s.emptyText}>{text}</Text>

  </View>
);


export default EmptyList;
