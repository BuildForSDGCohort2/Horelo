import React from 'react';
import {TouchableHighlight,StyleSheet} from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
//import styles from './styles';

const IconButton = (props) => {

    let icon_name = props.icon ? props.icon : 'add';
    let color = props.color ? props.coolor : '#eee';
    let icon_size = props.size ? props.size : 35;

    return(
        <TouchableHighlight
        style={styles.icon_button}
        underlayColor="#ccc"
        onPress={() =>{alert("hi here");}
    }
        >
            <MaterialIcons name={icon_name}
            size={icon_size}
            color = {color}
            />
        </TouchableHighlight>
    )
}

const styles = StyleSheet.create({
    textStyle:{
      
       // color:'#ffffff',
       // textAlign: 'center',        
    },
    icon_button:{
        padding:10,
        backgroundColor:'#3434',
        borderRadius:20
    }
});

export default IconButton;
