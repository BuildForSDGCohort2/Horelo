/*Custom Button*/
import React from 'react';
import { Button,ImageBackground, TouchableOpacity, Text, StyleSheet, View } from 'react-native';
const WorkItem = props => {
    return (<View style={styles.flex}>
        <TouchableOpacity onPress={props.customClick} style={styles.view}>
            <ImageBackground style={[styles.view]} source={{ uri: props.logo }}>
                <Text style={styles.text}>{props.title}</Text>
                <View style={{ paddingTop: 50 }} />
                <Text style={styles.text1}>{props.name}</Text>
            </ImageBackground>

            
        </TouchableOpacity>
        
    </View>
    );
};

const styles = StyleSheet.create({
    flex: {
        padding: 5,
        marginStart: 5,
        flexDirection: 'row',
    },
    text: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginTop: 5,
    },
    text1: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginBottom: 5,
    },
    view: {
        height: 100,
        width: 100,
        borderRadius: 50,
        alignItems: 'center',
        justifyContent: 'center',
        color: '#043',
        backgroundColor: '#985'
    },
    profileView: {
        height: 35,
        width: 70,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        fontFamily: 'LovingYou',
        fontSize: 30,
        color: 'white',
        marginTop: 10,
    },
});
export default WorkItem;