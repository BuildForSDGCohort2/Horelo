/*Custom Button*/
import React from 'react';
import { TouchableOpacity, Text, StyleSheet,View } from 'react-native';
const AccountItem = props => {
    return (
        <TouchableOpacity  onPress={props.customClick} style={[props.style,{
                backgroundColor: props.color, 
                height: 100,
                width: 100,
                borderRadius: 25,
                marginTop: 10,
                marginLeft: 5,
                marginRight: 5,
                alignItems:'center',
                justifyContent:'center',
            }]}>
            <View>
                <Text style={styles.text}>{props.amount}</Text>
                <Text style={styles.subtitle}>{props.name}</Text> 
            </View>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    flex: {
        height: 100,
        width: 100,
        //backgroundColor: '#f05555',
        borderRadius: 25,
        marginTop: 10,
        
    },
    text: {
        color: 'black',
        fontSize: 15,
        color: '#fff',
        marginTop: 5,
        fontWeight:'bold',
        fontFamily:'maven-pro-bold',
    },
    subtitle: {
        marginTop: 17,
        color: '#fff',
        fontSize: 14,
        fontWeight: 'bold',
    },
    view:{
        flex:1
    }
});
export default AccountItem;