/*Custom Button*/
import React from 'react';
import { TouchableHighlight, Text, StyleSheet } from 'react-native';
const Mybutton = props => {
    return (
        <TouchableHighlight style={styles.button} onPress={props.customClick}>
        </TouchableHighlight>
    );
};

const styles = StyleSheet.create({
    button: {
        flex:1
    },
    });
export default Mybutton;