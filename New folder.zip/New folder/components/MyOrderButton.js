/*Custom Button*/
import React from 'react';
import { Button, ImageBackground,Image, TouchableOpacity, Text, StyleSheet, View } from 'react-native';
const MyOrder = props => {
    return (
    <View style={{flex:1, alignItems:'center'}}>
        <Text style={styles.text}>{props.title}</Text>
            <Text style={styles.text1}>({props.items}){props.total}</Text>
<View style={styles.flex}>
        <TouchableOpacity onPress={props.customClick} style={styles.view}>
            <Image style={[{height: 100,
        width: 100,}]} source={{ uri: props.logo }} />
                 
            
        </TouchableOpacity>
        
        <View style={{ padding: 5 }} >
        <TouchableOpacity
                style={[styles.profileView, {backgroundColor: props.colorSeen}]}
            onPress={props.seenClick}>
             <Text style={styles.logo}>Seen</Text> 
        </TouchableOpacity>
            <View style={{ paddingVertical: 9 }} />
        <TouchableOpacity
            style={[styles.orderView,{backgroundColor: props.colorReady,}]}
            onPress={props.readyClick}>
            <Text style={ {
        fontFamily: 'LovingYou',
        fontSize: 30,
        color:"white",
        
        marginTop: 10,
    }}>Ready</Text>
        </TouchableOpacity>
        </View>
        </View>
        <Text style={ {
           color:'white'
        }}>Successfull?</Text> 
        <View style={{flexDirection:'row',alignItems:'center'}}>
        <TouchableOpacity
         style={ {
            width:40,
            backgroundColor:'gray',
            alignItems:'center',
            borderRadius:15
        }}
            onPress={props.falseClick}>
            <Text style={[{fontSize: 16,
       color:'red'}]}>No</Text> 
        </TouchableOpacity>
            <View style={{ paddingHorizontal:10 }} />
        <TouchableOpacity
        style={ {
            width:40,
            backgroundColor:'gray',
            alignItems:'center',
            borderRadius:15
        }}
            onPress={props.truthClick}>
            <Text style={ {
        fontSize: 16,
        color:"white",
    }}>Yes</Text>
        </TouchableOpacity>
        </View>
    </View>
    );
};

const styles = StyleSheet.create({
    flex: {
        padding: 5,
        marginStart: 5,
        flexDirection:'row',
    },
    text: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginTop: 5,
    },
    text1: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginBottom: 5,
    },
    view: {
        height: 100,
        width: 100,
        borderRadius: 25,
       // alignItems: 'center',
        //justifyContent:'center',
        color: '#043',
        backgroundColor: '#985'
    },
    profileView: {
        height: 35,
        width: 35,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    orderView: {
        height: 35,
        width: 35,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        fontFamily: 'LovingYou',
        fontSize: 30,
        color: 'white',
        marginTop: 10,
    },
});
export default MyOrder;