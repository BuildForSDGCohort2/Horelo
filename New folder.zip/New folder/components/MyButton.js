/* import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';


class MyButton extends Component{
    render(){
        const { text, onPress } = this.props;
        return(
            <TouchableOpacity style={styles.buttonStyle}
                onPress={() => onPress()}
                >
                    <Text style={styles.textStyle}>
                        {text}
                    </Text>
                </TouchableOpacity>
        );
    }
}

MyButton.PropTypes = {
    text: PropTypes.string.isRequired,
    onPress: PropTypes.func.isRequired
};

const styles = StyleSheet.create({
    textStyle:{
        fontSize:20,
        color:'#ffffff',
        textAlign: 'center',        
    },
    buttonStyle:{
        padding:10,
        backgroundColor:'#202646',
        borderRadius:20
    }
});

export default MyButton; */

import React, {Component} from 'react';
import { useNavigation } from '@react-navigation/native';
import ActionButton from 'react-native-action-button';
import {StyleSheet} from 'react-native';
import colors from '../styles/colors.js';
import Icon from '@expo/vector-icons/Foundation';
import POSIcon from '@expo/vector-icons/FontAwesome5';

function MyButton(){
      const iconName = "minus";
      const navigation = useNavigation();
    return(
        
        <ActionButton  size={55}
        spacing={10}
        offsetX={15}
        offsetY={15}
        buttonColor={colors.green} 
        buttonText="+/-" 
        >
        <ActionButton.Item
          buttonColor={colors.greyDarker}
          title="Sale (POS)"
          onPress={() => navigation.navigate('AddPOS')}
        //onPress={() => this.goToPage.bind(this)}
        >
          <POSIcon name='barcode' style={{ fontSize: 35, height: 22, color: 'white', fontWeight: 'bold' }} />
        </ActionButton.Item>

          <ActionButton.Item
            buttonColor={colors.blue}
            title="add incomes"
          onPress={() => navigation.navigate('AddTransaction', { cashF: "income" })}
            >
          <Icon name="plus" style={{ fontSize: 20, height: 22, color: 'white', fontWeight: 'bold'}} />

            </ActionButton.Item>
          <ActionButton.Item
            
            buttonColor={colors.red}
          title="add expense"
         onPress={() => navigation.navigate('AddTransaction',{cashF: "expense"})}
          //onPress={() => this.goToPage.bind(this)}
          >
        <Icon name={iconName} style={{fontSize:20, height:22, color:'white',fontWeight:'bold'}} />
          </ActionButton.Item>
        
        </ActionButton>
        
        

            );
}

  const styles = StyleSheet.create({
    MainContainer: {
        flex: 1,
        paddingTop: 20,
        alignItems: 'center',
        marginTop: 50,
        justifyContent: 'center',
      },
    actionButton:{
      fontSize:20,
      height:22,
      color:'white',
    },
  });
 
export default MyButton;