/*Custom Button*/
import React from 'react';
import { Button,Dimensions, Image,ImageBackground, TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import InputSpinner from "react-native-input-spinner";
import POSIcon from '@expo/vector-icons/FontAwesome5';

const CartItem = props => {
    return (<View style={styles.flex}>
        <TouchableOpacity onPress={props.orgClick} >
            <Image style={{ backgroundColor:'#453', height: vh / 20, width: vw / 5, borderRadius: 50, marginLeft: vw / 25 }} source={{ uri: props.logo }} />
                {/* <Text style={styles.text1}>cafe Javas{props.name}</Text> */}
        </TouchableOpacity>
        
        <TouchableOpacity onPress={props.productClick} style={[styles.view]}>
            <ImageBackground style={[styles.view]} source={{ uri: props.image }}>
            </ImageBackground>
        </TouchableOpacity>
        <TouchableOpacity onPress={props.cartClick} >
            <Text style={[styles.text,{backgroundColor:'#000'}]}>ADD TO CART</Text>
            <Text style={[styles.text, { backgroundColor: '#000', marginTop:0 }]}>{props.price}</Text>
        </TouchableOpacity>
        <View style={{transform: [{ rotate: '0deg' }], marginLeft:5 }} >
            {/* <View style={[styles.circle, { height: 20, }]}>
                <POSIcon name='cart-plus' style={[{ fontSize: 30, fontWeight: 'bold', color: "#606f" }]} />
            </View> */}
            {/* <InputSpinner
                max={1000}
                step={1}
                type={'float'}
                colorMax={"#f04048"}
                colorMin={"#40c5f4"}
                value={1}
                width={70}
                height={25}
                rounded={false}
                //value={this.state.number}
                onChange={(num) => {
                    setQuantity(num);
                    amountPaid();
                }}
            /> */}
        </View>
    </View>
    );
};
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;
const styles = StyleSheet.create({
    flex: {
        //padding: 5,
        //marginStart: 5,
       // flexDirection: 'row',
    },
    text: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginTop: 5,
    },
    text1: {
        color: '#000',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        //marginBottom: 5,
        fontFamily: 'ValidityScriptBI',
        backgroundColor: '#0ff3'
    },
    
    productImage: {
    //width: '100%',
    //height: '50%',
   // height: vh / 20,
    //    borderRadius: 25,
   // resizeMode: 'contain',
    backgroundColor: '#ffffff'
},
    view: {
        height: 100,
        width: 100,
        borderRadius: 25,
        alignItems: 'center',
        justifyContent: 'center',
        //color: '#043',
        backgroundColor: '#985',
        resizeMode: 'contain',
    },
    profileView: {
        height: 35,
        width: 50,
        borderRadius: 10,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        fontFamily: 'maven-pro-bold',
        fontSize: 14,
        color: 'white',
        marginTop: 2,
    },
});
export default CartItem;