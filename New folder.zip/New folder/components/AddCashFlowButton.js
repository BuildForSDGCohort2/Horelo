import React from 'react';
import { useNavigation } from '@react-navigation/native';
import ActionButton from 'react-native-action-button';
import { StyleSheet } from 'react-native';
import colors from '../styles/colors.js';

function AddButton(){
    const navigation = useNavigation();
        return (

            <ActionButton size={55}
                spacing={10}
                offsetX={15}
                offsetY={15}
                buttonColor={colors.green}
                //buttonText="+"
                //title="+"
              //  onPress={props.customClick}
                onPress={() => navigation.navigate('AddCashFlow')}
            >
            </ActionButton>
        );
}

const styles = StyleSheet.create({
    MainContainer: {
        flex: 1,
        paddingTop: 20,
        alignItems: 'center',
        marginTop: 50,
        justifyContent: 'center',
    },
    actionButton: {
        fontSize: 20,
        height: 22,
        color: 'white',
    },
});

export default AddButton;