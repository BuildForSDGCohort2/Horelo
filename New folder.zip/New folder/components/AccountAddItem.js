/*Custom Button*/
import React from 'react';
import { TouchableOpacity, Text, StyleSheet, Image } from 'react-native';

const AccountAddItem = props => {
    const addAccount = require('../assets/images/add-account.png');

    return (
        <TouchableOpacity style={styles.flex} onPress={props.customClick}>
            <Image
                resizeMode='cover'
                source={addAccount}
                style={styles.image}
            />
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    
    image: {
        alignItems: 'center',
        height: 100,
        width: 100,
        borderRadius: 25,
        marginTop: 10,
        marginLeft:5,
        marginRight: 5,
    },
    
});
export default AccountAddItem;