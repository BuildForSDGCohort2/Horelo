/*Custom Button*/
import React from 'react';
import { TouchableOpacity,  StyleSheet} from 'react-native';

const ColourPickers = props => {
    return (
        <TouchableOpacity onPress={props.customClick} style={{
            backgroundColor: props.color,
            height: 50,
            width: 50,
            borderRadius: 35,
            alignItems: 'center',
            margin: 10,
            justifyContent: 'flex-start',
            color: 'white',
        }}>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    flex: {
        height: 100,
        width: 100,
        //backgroundColor: '#f05555',
        borderRadius: 25,
        marginTop: 10,
        marginLeft: 5,
        marginRight: 5,
    },
    circle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        borderTopLeftRadius: 35,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        backgroundColor: '#400f',
        marginStart: 10,
        marginTop: 2,
        marginBottom: 3,
    },

    view: {
        flex: 1
    }
});
export default ColourPickers;