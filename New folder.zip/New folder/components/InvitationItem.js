/*Custom Button*/
import React from 'react';
import { Button, ImageBackground, TouchableOpacity, Text, StyleSheet, View } from 'react-native';
const InvitationItem = props => {
    return (<View style={styles.flex}>
        <TouchableOpacity onPress={props.customClick} style={styles.view}>
            <ImageBackground style={[styles.view]} source={{ uri: props.logo }}>
                <Text style={styles.text}>{props.title}</Text>
                <View style={{ paddingTop: 50 }} />
                <Text style={styles.text1}>{props.name}</Text>
            </ImageBackground>
            
        </TouchableOpacity>
        <View style={{ padding: 5 }} >
            <TouchableOpacity
                style={[styles.profileView, { backgroundColor: '#456' }]}
                onPress={props.acceptClick}>
                <Text style={styles.logo}>Accept</Text>
            </TouchableOpacity>
            <View style={{ paddingVertical: 9 }} />
            <TouchableOpacity
                style={[styles.profileView, { backgroundColor: '#810000' }]}
                onPress={props.declineClick}>
                <Text style={styles.logo}>Decline</Text>
            </TouchableOpacity>
        </View>
    </View>
    );
};

const styles = StyleSheet.create({
    flex: {
        padding: 5,
        marginStart: 5,
        flexDirection: 'row',
    },
    text: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginTop: 5,
    },
    text1: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginBottom: 5,
    },
    view: {
        height: 100,
        width: 100,
        borderRadius: 25,
        alignItems: 'center',
        justifyContent: 'center',
        color: '#043',
        backgroundColor: '#985'
    },
    profileView: {
        height: 35,
        width: 50,
        borderRadius: 10,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        fontFamily: 'maven-pro-bold',
        fontSize: 14,
        color: 'white',
        marginTop: 2,
    },
});
export default InvitationItem;