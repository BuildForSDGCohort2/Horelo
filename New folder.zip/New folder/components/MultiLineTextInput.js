/*Custom TextInput*/
import React from 'react';
import { View} from 'react-native';
import {TextInput} from 'react-native-paper';
const Mytextinput = props => {
  return (
    <View
      style={{
       marginTop: 5,
      }}>
      <TextInput
        underlineColorAndroid="transparent"
        placeholder={props.placeholder}
        placeholderTextColor="#007FFF"
        keyboardType={props.keyboardType}
        onChangeText={props.onChangeText}
        returnKeyType={props.returnKeyType}
        numberOfLines={props.numberOfLines}
        multiline={props.multiline}
        onSubmitEditing={props.onSubmitEditing}
        style={[props.style, {
          borderColor: '#007FFF',
          borderWidth: 1,
          width:200,
          marginBottom:5,
         }]}
        blurOnSubmit={false}
        defaultValue={props.defaultValue}
        value={props.value}
      />
    </View>
  );
};
export default Mytextinput;