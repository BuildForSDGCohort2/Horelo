/*Custom TextInput*/
import React from 'react';
import { View} from 'react-native';
import {TextInput} from 'react-native-paper';
const Mytextinput = props => {
  return (
    <View
      style={{
       // marginLeft: 5,
        marginRight: 10,
       marginTop: 15,
       // borderColor: '#007FFF',
        //borderWidth: 1,
        //width:250,
      }}>
      <TextInput
        underlineColorAndroid="transparent"
        placeholder={props.placeholder}
        placeholderTextColor="#007FFF"
        keyboardType={props.keyboardType}
        onChangeText={props.onChangeText}
        onKeyPress={props.onKeyPress}
        returnKeyType={props.returnKeyType}
        numberOfLines={props.numberOfLines}
        multiline={props.multiline}
        onSubmitEditing={props.onSubmitEditing}
        style={[props.style, {
          borderColor: '#007FFF',
          borderWidth: 1,
          width:250,
          height:40,
         }]}
        blurOnSubmit={false}
        defaultValue={props.defaultValue}
        value={props.value}
      />
    </View>
  );
};
export default Mytextinput;