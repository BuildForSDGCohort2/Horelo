/*Custom Button*/
import React from 'react';
import { Button, Dimensions, Image, ImageBackground, TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import InputSpinner from "react-native-input-spinner";
import POSIcon from '@expo/vector-icons/FontAwesome5';

const CartPage = props => {
    return (<View style={styles.flex}>
       
        <TouchableOpacity onPress={props.productClick} style={[styles.view]}>
            <Image style={[styles.view]} source={{ uri: props.image }}/>
        </TouchableOpacity>
            <InputSpinner
                max={1000}
                step={1}
                type={'float'}
                colorMax={"#f04048"}
                colorMin={"#40c5f4"}
                value={props.value}
                width={70}
                height={25}
                rounded={false}
                //value={this.state.number}
                onChange={ props.onChange }
            /> 
        <TouchableOpacity onPress={props.cartClick} >

            <Text style={[styles.text, { backgroundColor: 'red' }]}>REMOVE ITEM</Text>
            <Text style={[styles.text, { backgroundColor: 'red', marginTop: 0 }]}>{props.price}</Text>
        </TouchableOpacity>
       
    </View>
    );
};
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;
const styles = StyleSheet.create({
    flex: {
        //padding: 5,
        //marginStart: 5,
        // flexDirection: 'row',
    },
    text: {
        color: 'black',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        marginTop: 5,
    },
    text1: {
        color: '#000',
        fontSize: 15,
        justifyContent: 'center',
        color: 'white',
        //marginBottom: 5,
        fontFamily: 'ValidityScriptBI',
        backgroundColor: '#0ff3'
    },

    productImage: {
        //width: '100%',
        //height: '50%',
        // height: vh / 20,
        //    borderRadius: 25,
        // resizeMode: 'contain',
        backgroundColor: '#ffffff'
    },
    view: {
        height: 100,
        width: 100,
        borderRadius: 25,
        alignItems: 'center',
        justifyContent: 'center',
        //color: '#043',
        backgroundColor: '#985',
        resizeMode: 'contain',
    },
    profileView: {
        height: 35,
        width: 50,
        borderRadius: 10,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        fontFamily: 'maven-pro-bold',
        fontSize: 14,
        color: 'white',
        marginTop: 2,
    },
});
export default CartPage;