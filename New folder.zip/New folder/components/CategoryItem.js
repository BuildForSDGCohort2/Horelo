/*Custom Button*/
import React from 'react';
import { TouchableOpacity, Text, StyleSheet,View } from 'react-native';
const CategoryItem = props => {
    return (
        <TouchableOpacity  onPress={props.customClick} style={[props.style,{
                backgroundColor: '#5454', 
                height: 50,
                width: 80,
                borderRadius: 25,
                marginTop: 3,
                marginLeft: 5,
                marginRight: 5,
                alignItems:'center',
                justifyContent:'center',
            }]}>
            <View>
                <Text style={styles.subtitle}>{props.name}</Text> 
            </View>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    flex: {
        height: 10,
        width: 100,
        //backgroundColor: '#f05555',
        borderRadius: 25,
        marginTop: 10,
        
    },
    text: {
        color: 'black',
        fontSize: 15,
        color: '#000',
        marginTop: 5,
        fontWeight:'bold',
        fontFamily:'maven-pro-bold',
    },
    subtitle: {
        //marginTop: 17,
        color: '#000',
        fontSize: 14,
        fontWeight: 'bold',
    },
    view:{
        flex:1
    }
});
export default CategoryItem;