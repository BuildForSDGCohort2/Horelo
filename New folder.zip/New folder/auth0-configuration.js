module.exports = {
  clientId: "",
  domain: ""
};