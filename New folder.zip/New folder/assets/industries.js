export const deptss =[{
            label: 'Sales',
    value: 'sales',
            color: 'orange',
        },
        {
            label: 'Data',
            value: 'data',
            color: 'green',
        },
         {
            label: 'User',
             value: 'user',
            color: 'green',
        }];
export const user_roles = [
    {
            label: 'Data Entry',
            value: 'data',
        },
        {
            label: 'Depart Head',
            value: 'depart',
        },
        {
            label: 'Administrator',
            value: 'admin',
        },
];
export const deptPlaceHolder = {
    label: 'Select depart...',
    value: null,
    color: '#9EA0A4',
};
export const rolesPlaceHolder = {
    label: 'Select role...',
    value: null,
    color: '#9EA0A4',
};
export const industries = {
    label: 'Select an industry...',
    value: null,
    color: '#9EA0A4',
};
export const industryCategory = [
    {
        label: 'Retail',
        value: 1,
    },
    {
        label: 'WholeSale',
        value: 3,
    },
    {
        label: 'Furniture',
        value: 4,
    },
    {
        label: 'Electronics',
        value: 5,
    },
    
    {
        label: 'Restaurant',
        value: 6,
    },
    {
        label: 'Local Market',
        value: 7,
    },
    {
        label: 'Diary',
        value: 8,
    },
    {
        label: 'Boutique',
        value: 9,
    },
    {
        label: 'Vegetables',
        value: 10,
    },
    {
        label: 'Flowers, Florist',
        value: 11,
    },
    {
        label: 'Soda, Beverages & liquor',
        value: 12,
    },
    {
        label: 'General Merchandise',
        value: 13,
    },
    {
        label: 'Pharmaceuticals',
        value: 14,
    },
    {
        label: 'Supermarket',
        value: 15,
    },
    {
        label: 'Bookshop',
        value: 16,
    }, {
        label: 'Jewelry',
        value: 17,
    },
    {
        label: 'Others',
        value: 19,
    },
];
export const productCategory = [
    {
        label: 'Groceries',
        value: "groceries",
    },
    {
        label: 'Hardware',
        value: 'hardware',
    },
    
    {
        label: 'Electronics',
        value: 'electronics',
    },

    {
        label: 'Restaurant Menu',
        value: 'menu',
    },
    
    {
        label: 'Fashion',
        value: 'fashion',
    },
    
    {
        label: 'Flowers, Florist',
        value: "flowers, florist",
    },
    {
        label: 'Soda, Beverages & liquor',
        value: "Soda, Beverages & liquor",
    },
    {
        label: 'General Merchandise',
        value: "general merchandise",
    },
    {
        label: 'Pharmaceuticals',
        value: 'pharmaceuticals',
    },
    
    {
        label: 'Bookshop',
        value: 'bookshop',
    }, 
    {
        label: 'Jewelry',
        value: 'jewelry',
    },
    {
        label: 'Others',
        value: 'others',
    }
];
export const unitList = [
    {
        label: 'gramme(s)',
        value: 'g',
    },
    {
        label: 'Kilogram(s)',
        value: 'Kg(s)',
    },
    {
        label: 'Roll(s)',
        value: 'roll(s)',
    },
    {
        label: 'Canton(s)',
        value: 'canton(s)',
    },
    {
        label: 'milligram(s)',
        value: 'mg',
    },
    {
        label: 'Tonne(s)',
        value: 'tonne(s)',
    },
    {
        label: 'piece(s)',
        value: 'pc(s)',
    },
    {
        label: 'Tablet(s)',
        value: 'tab(s)',
    },
    {
        label: 'Litre(s)',
        value: 'ltr(s)',
    },
    {
        label: 'milliliter(s)',
        value: 'ml(s)',
    },
    {
        label: 'meter(s)',
        value: 'm',
    },
    {
        label: 'Inch(es)',
        value: 'Inch',
    },
    {
        label: 'centimeter(s)',
        value: 'cm',
    },
    {
        label: 'Kilometer(s)',
        value: 'Km',
    },
    {
        label: 'Feet',
        value: 'ft',
    },
    {
        label: 'Packet(s)',
        value: 'pack(s)',
    },
    {
        label: 'Strip(s)',
        value: 'strip(s)',
    },
    {
        label: 'Bottle(s)',
        value: 'bottle(s)',
    }
];
export const sectionList = [
    {
        label: 'Groceries',
        value: "groceries",
    },
    {
        label: 'Hardware',
        value: 'hardware',
    },

    {
        label: 'Electronics',
        value: 'electronics',
    },

    {
        label: 'Restaurant, Bar & Grill',
        value: 'Restaurant, Bar & Grill',
    },

    {
        label: 'Fashion',
        value: 'fashion',
    },

    {
        label: 'Horticulture, Flowers & Shrubs',
        value: "flowers, florist",
    },
    {
        label: 'Soda, Beverages & liquor',
        value: "Soda, Beverages & liquor",
    },
    {
        label: 'General Merchandise',
        value: "general merchandise",
    },
    {
        label: 'Pharmaceuticals',
        value: 'pharmaceuticals',
    },

    {
        label: 'Bookshop',
        value: 'bookshop',
    },
    {
        label: 'Jewelry',
        value: 'jewelry',
    },
    {
        label: 'Others',
        value: 'others',
    },
    {
        label: 'Cosmetics ',
        value: 'Cosmetics',
    },
    {
        label: 'Bakery, Confectionery & Pastries',
        value: 'Bakery, Confectionery & Pastries',
    },
    {
        label: 'Manicure & Pedicure',
        value: 'Manicure & Pedicure',
    },
    {
        label: 'LiveStock & Poultry',
        value: 'LiveStock & Poultry',
    },
    {
        label: 'Camping',
        value: 'Camping',
    },
    {
        label: 'Sports & Games',
        value: 'Sports & Games',
    }
];