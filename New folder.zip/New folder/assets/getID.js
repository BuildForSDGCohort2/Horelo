import uuid from 'react-native-uuid';

const genId = () => uuid.v4();

export default genId;
