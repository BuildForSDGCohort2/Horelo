import R from 'ramda';

export const categoriesTypes = {
  expense: 'Expense',
  income: 'Income',
};

export const isExpense = type => type === categoriesTypes.expense;

export const isIncome = type => type === categoriesTypes.income;

export const incomeCategories = [
  { id: '1Hello', name: 'Salary', icon: 'cash' },
  { id: '2Hello', name: 'Savings', icon: 'coin' },
  { id: '3Hello', name: 'Deposits', icon: 'castle' },
];

export const expenseCategories = [
  { id: '1Hello', name: 'Bills', icon: 'tag' },
  { id: '2Hello', name: 'Car', icon: 'car' },
  { id: '3Hello', name: 'Communications', icon: 'phone' },
  { id: '4Hello', name: 'Eating Out', icon: 'silverware' },
  { id: '5Hello', name: 'Entertainment', icon: 'speaker' },
  { id: '6Hello', name: 'Food', icon: 'food' },
  { id: '7Hello', name: 'Gifts', icon: 'gift' },
  { id: '8Hello', name: 'Health', icon: 'heart-pulse' },
  { id: '9Hello', name: 'Home', icon: 'home-variant' },
  { id: '10Hello', name: 'Pets', icon: 'cat' },
  { id: '11Hello', name: 'Sport', icon: 'dumbbell' },
  { id: '12Hello', name: 'Taxi', icon: 'taxi' },
];

/* const withType = type => category => ({ ...category, type });
const allWithType = type => R.map(withType(type));

export const defaultCategories = [
  ...allWithType(categoriesTypes.income)(incomeCategories),
  ...allWithType(categoriesTypes.expense)(expenseCategories),
]; */
