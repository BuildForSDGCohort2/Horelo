import React, { useState, useEffect } from 'react';
import {
    KeyboardAvoidingView, SafeAreaView, TouchableOpacity,
    Button,
    FlatList,
    Image,
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    View,
    Dimensions
} from 'react-native';
import {Text} from 'react-native-paper';
import MyButtons from '../../components/MyButtons';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import SaveButton from '../../components/SaveButton';
import { UserContext } from '../../App';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import * as R from 'ramda';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { rolesPlaceHolder, deptPlaceHolder, user_roles, deptss } from '../../assets/industries';
import { getTS } from '../../assets/getTS';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import * as Permissions from 'expo-permissions';

const UPDATE_USERS = gql`
  mutation ($name: String, $userID: String!
     $phone:String, $avatar: String) {
    update_users (
      _set: {
        name: $name,
        avatar: $avatar,
        phone: $phone,
      },
      where: {
        auth0_id: {
          _eq: $userID
        }
      }
    ) {
      returning {
        auth0_id
      }
    }
  }
`;

const UserProfile = () => {

    useEffect(() => {
        getPermissionAsync();
    }, []);
    const user_context = React.useContext(UserContext);


    UserProfile.navigationOptions = {
        title: user_context.name,
    };

    const userID = user_context.userId;
    const [phone, setPhone] = useState(null);
    const [avatar, setAvatar] = useState(null);
    const [avatarBase, setAvatarBase] = useState(null);
    const [image, setImage] = useState(null);
    const [name, setUserName] = useState('');

    const pickImage = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: false,
                base64: true,
                aspect: [16, 9],
                quality: 1,
            });
            if (!result.cancelled) {
                setImage(result.uri);
                setAvatarBase('data:image/jpeg;base64,' + result.base64);
            }

            //console.log(result);
        } catch (E) {
            console.log(E);
        }
    };
    //  render() {
    return (
        <SafeAreaView style={{ flex: 1 }}>

            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>

                <ScrollView>

                    <View style={styles.MainContainer}>

                        <View style={styles.rowItem}>
                            <TouchableOpacity
                                style={styles.bigCircle}>
                                {user_context.avatar !== null ? <Image source={{ uri: user_context.avatar }} style={styles.bigCircle} /> :
                                    <Text> no Image</Text>
                                }
                            </TouchableOpacity>
                            <View style={{ marginLeft: 20 }}>
                                <Text style={styles.text}> {user_context.name}</Text>
                                <Text style={styles.text}> {user_context.email}</Text>
                                <Text style={styles.text}> {user_context.phone}</Text>
                            </View>

                        </View>
                        <Mutation
                            mutation={UPDATE_USERS}
                            variables={{
                                phone,
                                avatar,
                                name,
                                userID
                            }} >
                            {
                                (updateUserProfile, { loading, error }) => {
                                    const submit = () => {
                                        if (error) {
                                            return <Text> Error </Text>;
                                        }
                                        if (loading) {
                                            return;
                                        }
                                        updateUserProfile();
                                        //
                                    }
                                    return (
                                        <View style={{ width: 200, marginLeft: 10 }}>

                                            <View paddingVertical={5} />
                                            <TextInput
                                                placeholder="user's Name"
                                                onChangeText={(value) => { setUserName(value) }}
                                                style={styles.textInput}
                                                value={name}
                                                defaultValue={user_context.name}
                                            />
                                            <View paddingVertical={5} />

                                            <View paddingVertical={5} />
                                            <TextInput
                                                placeholder="user's Phone"
                                                onChangeText={(value) => { setPhone(value) }}
                                                style={styles.textInput}
                                                value={phone}
                                                defaultValue={user_context.phone}
                                                keyboardType={"numeric"}
                                            />

                                            <View paddingVertical={5} />

                                            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                                                <TouchableOpacity
                                                    style={{ backgroundColor: '#8585', color: '#fff', height: 30, padding: 10, alignItems: 'center', justifyContent: 'center', borderRadius: 15 }}
                                                    onPress={() => pickImage()}>
                                                    <Text style={styles.Mytextinput}>Upload Image</Text>
                                                </TouchableOpacity>
                                                <View padding={5} />
                                                {
                                                    image && <View style={{ flexDirection: 'row', alignItems: 'center', marginLeft: 30 }}>
                                                        <Image source={{ uri: image }} style={{ width: 100, height: 100, borderRadius: 35 }} />
                                                        <View padding={10}>
                                                            <TouchableOpacity
                                                                style={{ backgroundColor: '#154', color: '#fff', height: 30, padding: 10, alignItems: 'center', justifyContent: 'center', borderRadius: 15 }}
                                                                onPress={() => {
                                                                    
                                                                    user_context.setAvatar(avatarBase);
                                                                    setAvatar(avatarBase);
                                                                    //console.log( );
                                                                    //console.log(typeof avatar);
                                                                   // console.log(typeof phone);
                                                                   // console.log(typeof 'appdividend');
                                                                   
                                                                }}>
                                                               
                                                                <Text style={styles.Mytextinput, { color: '#fff' }}>CONFIRM IMAGE(s) </Text>
                                                            </TouchableOpacity>
                                                            <View padding={5} />
                                                            <TouchableOpacity
                                                                style={{ backgroundColor: '#7878', color: '#fff', height: 30, padding: 10, alignItems: 'center', justifyContent: 'center', borderRadius: 15 }}
                                                                onPress={() => {
                                                                       setImage(null)}}>
                                                                <Text style={styles.Mytextinput, { color: '#fff' }}>CANCEL</Text>
                                                            </TouchableOpacity>
                                                        </View>
                                                    </View>
                                                }
                                            </View>

                                            <View paddingVertical={5} />

                                            <MyButtons
                                                title="Update User Info "
                                                customClick={() => submit()}
                                            />
                                        </View>
                                    );
                                }
                            }
                        </Mutation>
                    </View>


                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );

    // }
}
//title of the page
const getPermissionAsync = async () => {
    if (Constants.platform.ios || Constants.platform.android) {
        const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
        if (status !== 'granted') {
            alert('Sorry, we need camera roll permissions to make this work!');
        }
    }
};

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({

    MainContainer: {
        flex: 1,
        paddingHorizontal: 20,
        justifyContent: 'flex-end',
        width: 250,
        marginLeft: 10,
        marginTop: 10,
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 3,
    },
    row: {
        marginRight: 3,
        marginBottom: 10,
    },
    textInput: {
        borderRadius: 15,
        marginRight: 3,
        width: 250,
        height: 50,
        borderColor: '#000',
        backgroundColor: '#7ed',
        paddingLeft: 10,
    },
    bigCircle: {
        width: 100,
        height: 100,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        //  marginRight:4,
    },
    icons: {
        fontSize: 30,
        fontFamily: 'ValidityScriptBI',
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
        backgroundColor: '#000',
        borderRadius: 35,
        height: 40,
        width: 40,
    },
    text: {
        color: 'brown',
        fontSize: 20,
        fontFamily: 'YellowRabbit',
    },

    logo: {
        fontFamily: 'LovingYou',
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },


});
const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});


export default UserProfile;