import gql from 'graphql-tag';

export const FETCH_TODOS = gql` 
query {
  todos{
    id
    text
    is_complete
  }
}`;
/* export const FETCH_USERS = gql` 
query {
  invitations{
    id
    user
    org_id
    accepted
  }
  
}`;
 */
export const GET_Users = gql`
query { 
    users{
            auth0_id
            org_id
            dept_id
            role
            name
            email 
                }
    
}`;