import React, { useState, useEffect, useContext } from 'react';
import {ActivityIndicator,FlatList, View,ScrollView, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import gql from 'graphql-tag';
import {Text} from 'react-native-paper';
import { UserContext } from '../../App';
import { EmptyList} from '../../components/EmptyList'
import CategoryItem from '../../components/CategoryItem';
import MyButtons from '../../components/MyButtons'
import { Query, Mutation } from 'react-apollo';
import ProductsItem from '../../components/ProductsItem';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import AsyncStorage from '@react-native-community/async-storage';

export const FETCH_PRODUCTS = gql`
query ($org_ID: String!){
    products(where: {org_id:{_eq: $org_ID}})
      {
        id
        pdt_id
        name
        price
        quantity
        category
        section
        image
        description
        units
      }
  }
`;


export default function Products ({route, navigation}) {
    const { itemPass }= route.params;
    var org_ID = itemPass.orgid;
    var logo = itemPass.logo;
    React.useEffect(() => {
       // setItemPass(navigation.getParam('item'));

    }, []);
    const user_context = useContext(UserContext);
    const [userID, setUserId] = React.useState('');
    const [pdt_id, setAccountID] = React.useState('');
    const [amount, setAmounts] = React.useState('');
    const [items, setItems] = React.useState('');
    const [name, setPdt_name] = React.useState('');
    const [trans_id, setTrans_id] = React.useState('');
    const [list, setList] = React.useState([]);
    const [dataCart, setDataCart] = React.useState([]);
    const [querySections, setQuerySections] = useState('');
    const [sections, setSections] = useState();
    const [clicked, setClicked] = useState(false);

    
    let cart= dataCart.length == 0 ? 0 : dataCart.length ;
    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: itemPass.orgname+'\'s ITEMS',
            headerRight: () => (
            <TouchableOpacity
                style={{ marginRight: 10, marginBottom: 20 }}
                onPress={() => { navigation.navigate('Cart') }}>
                <Text style={[{ marginBottom: 1, marginLeft:13,color: "#000", }]}>{cart}</Text>
                <View style={[{ height: 20, }]}>
                    <POSIcon name='cart-plus' style={[{ fontSize: 30, fontWeight: 'bold', color: "#000",marginBottom:10 }]} />
                </View>
            </TouchableOpacity>
        ), });
    }, [navigation, cart]);

    function cartAdd(dataItem) {
      
        const itemcart = {
            item: dataItem,
            quantity:  1,
            price: dataItem.price,
            pref:"none"
          }
       
          AsyncStorage.getItem('cart').then((datacart)=>{
              if (datacart !== null) {
                // We have data!!
                const cart = JSON.parse(datacart)
                cart.push(itemcart)
                AsyncStorage.setItem('cart',JSON.stringify(cart));
              }
              else{
                const cart  = []
                cart.push(itemcart)
                AsyncStorage.setItem('cart',JSON.stringify(cart));
              }
              alert("Add to Cart");
              AsyncStorage.getItem('cart').then((cart)=>{
                if (cart !== null) {
                  // We have data!!
                  const cartfood = JSON.parse(cart)
                  //const uniquecart = [...new Map(cartfood.map(item=>[item[item.item.pdtid], item])).values()];
                  const uniquecart = Object.values(cartfood.reduce((acc, cur)=>Object.assign(acc,{[cur.item.pdtid]:cur}),{}));
                  setDataCart(uniquecart);
                }
              })
              .catch((err)=>{
                alert(err)
              })
            })
            .catch((err)=>{
              alert(err)
            })
       
    }
    
    return (
            <View style={styles.container}>
                <Query query={FETCH_PRODUCTS} 
                
                variables={{ org_ID }} fetchPolicy='cache-and-network'>
                    {({ loading, error, data, refetch }) => {
                        if (loading) return <View styles={styles.activity}>
                            <ActivityIndicator size="large" color="#000ff" />
                        </View>
                        if (error) return <View>{console.log("my error gql " + error)}
                            <Text>Data loading error ${error.message}</Text>
                            <TouchableOpacity
                                onPress={() => { refetch() }}>
                                {/* <Text style={styles.circle} />  */}
                                {/* <Text style={styles.circle} />  */}
                                <View style={[styles.circle, { height: 45, backgroundColor: 'blue' }]}>
                                    <POSIcon name='refresh' style={[styles.icons, { color: "#9fff" }]} />
                                </View>
                            </TouchableOpacity>
                            </View>
// setDataList(data.org_product_view) 
function findSection(querySections) {
    if (querySections === '') {
        return [];
    }

     const regex = new RegExp(`${querySections.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&').trim()}`, 'ig');
    return data.products.filter(sectionCollect => sectionCollect.name.search(regex) >= 0);
}
var fSections = findSection(querySections);
const comp = (a, b) => a.toLowerCase().trim() === b.toLowerCase().trim();
                            return (
                                <View>
                                   
            <Image style={styles.header} source={{ uri: logo }} />

                                    <View style={{ marginLeft: 30, marginTop: 30 }}>
                                       
                                        <Text style={styles.title}>{itemPass.orgname}</Text>
                                        <Text style={styles.subtitle}>SECTION:{sections.length() >=2 ? sections: 'none'}</Text>
                                    </View>
                                    <View style={{ flex: 1, top: 0, alignItems: 'center' }}>
                                <View style={styles.autocompleteContainer}>
                                    <Autocomplete
                                        autoCapitalize="words"
                                        autoCorrect={false}
                                        data={clicked || fSections.length === 1 && comp(querySections, data.products[0].name) ? [] : fSections}
                                        defaultValue={querySections}
                                        onChangeText={(text) => { setQuerySections(text); setClicked(false) }}
                                        onPress={() => setClicked(true)}
                                        placeholder="Enter the Product Name title"
                                        renderItem={({ item }) => (
                                            <TouchableOpacity onPress={() => {
                                                setClicked(true);
                                                setQuerySections(item.name);
                                                navigation.navigate('ProductPage', {item: item})
                                            }}>
                                                <Text style={styles.text}>
                                                    {item.name}</Text>
                                                <Image style={[styles.productImage,{borderRadius:270}]} source={{ uri: item.image }} />
                                            </TouchableOpacity>
                                        )}
                                    />
                                </View>
                            </View>
                                    <ScrollView style={styles.MainContainer}>
                                  
            {
                data.products.map((item, index) => {
                    return(
                  <View  {...item} key={index}>
                    <CategoryItem
                      name={item.section}
                      customClick={() => {setSections(item.section)}} {...item}/>
                  </View>)
                })
              }
            </ScrollView>
            {setList(data.products)}
                            <FlatList
                                style={styles.list}
                                data={list}
                                extraData={list}
                                 renderItem={({item}) =>
                                <TouchableOpacity
                                onPress={()=>{}}
                                >
                                    <View style={{
                                        //backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#f99f",
                                        marginTop:35,
                                        width:vw/3.5
                                    }} >
                                        <ProductsItem 
                                            title={item.name}
                                            price={"Ugx: " + (item.price)
                                            .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                                            }
                                               // .toFixed(0)
                                               // .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')} 
                                            image={item.image}
                                            productClick={() => navigation.navigate("ProductPage", { item: item })}
                                            cartClick={() => {
                                                cartAdd(item);
                                           }}                                          
                                            />
                                            </View></TouchableOpacity>} 
                                //horizontal={true}
                                numColumns={3}
                                ItemSeparatorComponent={()=><View paddingHorizontal={10} />}
                                enableEmptySections={true}
                                keyExtractor={(item, index) => index.toString()}
                            // ListHeaderComponent={renderHeader}
                            />
                                </View>);
                        }
                    }
                </Query>
            </View>
        );
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
    autocompleteContainer: {
        flex: 1,
        left: 15,
        position: 'absolute',
        right: 0,
        top: 0,
        zIndex: 1, width: 300
    },
    MainContainer: {
        height:vh/10,
        width: vw,
        //flexDirection: 'row',
        //zIndex: 10,
        //position: 'absolute',
        //top: vh / 6,
      },
      productImage: {
        width: '100%',
        //height: '50%',
        height: vh / 20,
        resizeMode: 'contain',
        backgroundColor: '#ffffff'
    },
    textStyle: {
        padding: 5,
    },
    textInputStyle: {
        height: 40,
        borderWidth: 1,
        paddingLeft: 5,
        borderColor: '#009688',
        backgroundColor: '#FFFFFF',
    },
    container: {
        flex: 1,
        flexWrap: 'wrap',
        alignItems: 'flex-start',
        height: vh,
        width: vw,
        backgroundColor: '#fdfdfd'
    },
    backButton: {
        position: 'absolute',
        top: vh / 18,
        left: vw / 30,
        zIndex: 10,
        width: 50,
        height: 50,
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    backText: {
        fontFamily: 'maven-pro-bold',
        fontSize: 23,
        color: '#fff',
    },
    backgroundFill: {
        width: '100%',
        height: vh / 3.2
    },
    productImage: {
        width: '100%',
        height: vh / 2.7,
        resizeMode: 'contain',
        position: 'absolute',
        top: vh / 14
    },
    details: {
        margin: 50,
        position: 'absolute',
        top: vh / 2.5
    },
    title: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 14,
        color: '#252525'
    },
    subtitle: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 14,
        color: '#bf200b',
        marginTop: 10
    },
    description: {
        fontFamily: 'maven-pro-regular',
        fontSize: vw / 22,
        color: '#4c4c4c',
        marginTop: 20
    },
    detail: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b',
        marginTop: 20
    },
    header: {
        width: vw,
        height: vw / 3.6,
        resizeMode: 'cover'
    },
});