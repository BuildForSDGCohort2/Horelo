/*jshint -W033 */
import React, { useState, useEffect, useContext } from 'react';
import { ScrollView,StyleSheet,SafeAreaView, View, Image, FlatList, TouchableOpacity, Dimensions, Button } from 'react-native';
import {Text} from 'react-native-paper';
import gql from 'graphql-tag';
import { UserContext } from '../../App';
import { Mutation } from 'react-apollo';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import InputSpinner from "react-native-input-spinner";
import EmptyList from '../../components/EmptyList';
import genId from '../../assets/getID';
import MyTextInput from '../../components/MultiLineTextInput';
import MyButtons from '../../components/MyButtons';
import CartPage from '../../components/CartPage';
import AsyncStorage from '@react-native-community/async-storage';
import Icon from 'react-native-vector-icons/Ionicons';

const INSERT_ORDER = gql`
  mutation ($orgID: String, $userId: String, $trans_id: String,
     $accountID: Int, $amounts: numeric, $phone:String,
    $quantity: Int, $pdt_name: String, $comment:String){
    insert_order  (
      objects: [{
        orgID: $orgID,
        userID: $userId,
        pdt_id: $accountID,
        amount: $amounts,
        items: $quantity,
        pdt_name: $pdt_name,
        trans_id:$trans_id,
        phone:$phone,
        comment:$comment,
      }]
    ){
      returning {
        id
        amount
        items
        pdt_name
        trans_id
        phone
      }
    }
  }
`;
 Cart.navigationOptions = ({ navigation }) => {
    return{
    title: 'Cart',
    headerRight: () => {
        <Text style={[{ fontFamily: 'maven-pro-bold', fontSize: 30, marginBottom: 1, }]}>
            Ttl: {(navigation.getParam('cart', 0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
        </Text>
    },
    }
}; 
export default function Cart({route, navigation }) {
    const user_context = useContext(UserContext);
    const [orgID, setOrgID] = React.useState(null);
    const [orgName, setOrgName] = React.useState(null);
    const [userId, setUserId] = React.useState(user_context.userId);
    const [pdtID, setPdtID] = React.useState(null);
    const [amounts, setAmounts] = React.useState(0);
    const [data, setData] = React.useState(null);
    const [pdt_name, setPdt_name] = React.useState(null);
    const [pdt_image, setPdt_image] = React.useState(null);
    const [quantity, setQuantity] = React.useState(1);
    const [trans_id, setTrans_id] = React.useState(null);
    const [price, setPrice] = React.useState(0);
    const [phone, setPhone] = React.useState(user_context.phone);
    const [comment, setComment] = React.useState(null);
    const [list, settList] = React.useState();
    const [dataCart, setDataCart] = React.useState([]);

    let cart= !list==[] && !list==null ? cart= list.reduce((acc, cart) => {
        return acc + cart.price;
    }, 0) :
    cart = list.reduce((acc, cart) => {
       return acc + cart.price;
   }, 0);
   React.useLayoutEffect(() => {

    AsyncStorage.getItem('cart').then((cart)=>{
        if (cart !== null) {
          // We have data!!
          const cartfood = JSON.parse(cart)
          setDataCart(cartfood);
        }
      })
      .catch((err)=>{
        alert(err)
      })
}, []);
    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: 'My Cart',
            headerRight: () => (
                <Text style={[{ fontFamily: 'maven-pro-bold', fontSize: 24, marginBottom: 1, }]}>
                Ttl: {(cart).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
            </Text>
        ), });
    }, [navigation]);
    
    const onClearArray = () => {
        setList([]);
        removeItem();
    };
    const removeItem = async () => {
        try{
          let res = await await AsyncStorage.removeItem('cartList');
          console.log('deleted successfully');
        }
        catch(e){
          //onLogin();
        }      
      }
    function cartEdit(pdtID) {

        const newList = list.concat((item) => {
                    //pdt_image,
                    pdt_name,
                    amounts,
                    quantity,
                    price,
                    pdtID,
                    orgID,
                    orgName,
                    comment               
        });
        //AsyncStorage.setItem('cartList', JSON.stringify(newList));
        console.log( newList.map(obj => obj.amounts)+" none ")
        setList(newList);
        cart = newList.reduce((acc, cart) => {
            return acc + cart.amounts;
        }, 0);
        setOrgID(null);
        setOrgName(null);
        setPdtID(null);
        setPdt_name(null);
        setPdt_image(null);
        setQuantity(null);
        setPrice(null);
        setComment(null);
    }
    function cartDel(pdtID) {
        const newList = list.filter((item) => item.id !== pdtID);
        //user_context.setCart(newList);
        setList(newList);
    }
    
    return (
        <View style={styles.container}>
            {/* <Mutation
                mutation={INSERT_ORDER}
                variables={{
                    orgID,
                    userId,
                    amounts,
                    pdt_name,
                    trans_id,
                    quantity,
                    price,
                    comment
                }}

            >
                {

                    (insertTransactions, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text>${error.message} {console.log("my error gql " + error)}</Text>;
                            }
                            if (loading || list === []) {
                                return;
                            }
 }
                        return (
                            <View style={styles.container}>
                                <SafeAreaView>
                <ScrollView>
                {pdt_image !== null ?  <Image style={styles.header} source={{uri: pdt_image}}/> :
                                        <Image style={styles.header} source={require('../../assets/images/header.png')}/>
                                        }
                                    <Text style={[{marginLeft: vw/20,
                                        marginRight: vw/20,
                                       }]}>Store: {orgName !== null ?  orgName :
                                      'unKnown'
                                       }</Text>
                                    <Text style={[styles.title,{marginLeft: vw/20,
                                        marginRight: vw/20,
                                       }]}>Item:{pdt_name !== null ?  pdt_name :
                                        'unKnown'
                                         } </Text>
                                    <Text style={[styles.subtitle,{marginLeft: vw/20,
                                        marginRight: vw/20,
                                       }]}>Item Price: {(price * quantity).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</Text>
                                    <InputSpinner
                                    style={{marginLeft: vw/20,
                                        marginRight: vw/20,
                                       }}
                                                max={1000}
                                                step={1}
                                                type={'float'}
                                                colorMax={"#f04048"}
                                                colorMin={"#40c5f4"}
                                                color={"#9777"}
                                                value={quantity}
                                                rounded={false}
                                                arrows={false}
                                                height={vw/10}
                                                onChange={(num) => {
                                                    setQuantity(num);
                                                    setAmounts(num*price);
                                                }}
                                            />
                                            <Text style={{marginLeft: vw/20,
                                                        marginRight: vw/20,
                                                       }}>Preference(s):</Text>
                                < MyTextInput
                                placeholder = {
                                    "size:40, Pepper:hot, color:blue"+" "+
                                    //item+
                                   // 
                                   // item.forEach(function (obj) {obj.price})+
                                   //  
                                    list.map(obj => obj.amounts)+" none "+
                                     user_context.cart.reduce((acc, cart) => {
                                        return acc + cart.amounts;
                                    }, 0)
                                }
                                onChangeText = {
                                    (text) => {
setComment(text);
                                    }
                                }
                                style = {
                                    {
                                        marginLeft: vw / 20,
                                        marginRight: vw / 20,
                                    }
                                }
                                multiline = {
                                    true
                                }
                                value = {
                                    comment
                                }
                                numberOfLines = {
                                    2
                                }
                                //editable={true}
                                />
                                    <View style={{flexDirection: 'row', paddingHorizontal:50}}>
                                    <MyButtons
                                    title={"update Item"}
                                    customClick={() => {cartEdit(pdtID)}}
                                    style={{width:120, height: 40, marginTop: 10, backgroundColor:'#7676' }}
                                /> 
                              <MyButtons
                                    title="Place Order"
                                    customClick={() => { onClearArray() }}
                                    style={{width:120, height: 40, marginTop: 10 }}
                                />
                                    </View>
                               
                                 
                </ScrollView>
                <FlatList
                                    style={styles.list}
                                    data={list}
                                    extraData={list}
                                    renderItem={({ item }) => <TouchableOpacity style={styles.block} onPress={() => {
                                        setOrgID(item.orgID);
                                        setOrgName(item.orgName);
                                        setPdtID(item.pdtID);
                                        setPdt_name(item.pdt_name);
                                        setPdt_image(item.pdt_image);
                                        setQuantity(item.quantity);
                                        setTrans_id('');
                                        setPrice(item.price);
                                        setPhone('');
                                        setComment(item.comment);}}>
                                        <Image style={styles.productImage} source={{ uri: item.pdt_image }} />
                                        <Text style={styles.name}>({item.quantity}){item.pdt_name}</Text>
                                        <Text style={styles.price}>{(item.price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</Text>
                                        <View style={{flexDirection:'row'}}>
                                        <Text style={styles.name}>{item.orgName}</Text>
                                        </View>
                                        
                                    </TouchableOpacity>}
                                    numColumns={2}
                                    //horizontal={true}
                                    //keyExtractor={(item) => item.pdtid.toString()}
                                    ListEmptyComponent={<EmptyList containerStyle={{ width: 300, }} />}

                                />
                                  
                                  <View style={{flex:1,alignItems: 'center', justifyContent: 'center'}}>
         <View style={{height:20}} />
         <Text style={{fontSize:28, color:"gray"}}>Cart food</Text>
         <View style={{height:10}} />

         <View style={{flex:1}}>

           <View style={{width:width-20,margin:10,backgroundColor:'transparent', flexDirection:'row', borderBottomWidth:2, borderColor:"#cccccc", paddingBottom:10}}>
             <Image resizeMode={"contain"} style={{width:width/3,height:width/3}} source={{uri: "http://tutofox.com/foodapp/food/pizza/pizza-1.png"}} />
             <View style={{flex:1, backgroundColor:'transparent', padding:10, justifyContent:"space-between"}}>
               <View>
                 <Text style={{fontWeight:"bold", fontSize:20}}>Titulo de producto</Text>
                 <Text>Descripcion de food</Text>
               </View>
               <View style={{flexDirection:'row',justifyContent:'space-between'}}>
                 <Text style={{fontWeight:'bold',color:"#9fd236",fontSize:20}}>$565</Text>
                 <View style={{flexDirection:'row', alignItems:'center'}}>
                   <TouchableOpacity>
                     <Icon name="ios-remove-circle" size={30} color={"#9fd236"} />
                   </TouchableOpacity>
                   <Text style={{paddingHorizontal:8, fontWeight:'bold'}}>5</Text>
                   <TouchableOpacity>
                     <Icon name="ios-add-circle" size={30} color={"#9fd236"} />
                   </TouchableOpacity>
                 </View>
               </View>
             </View>
           </View>

         </View>

         <View style={{height:20}} />

       <TouchableOpacity style={{
           backgroundColor:"#9fd236",
           width:width-40,
           alignItems:'center',
           padding:10,
           borderRadius:5
         }}>
         <Text style={{
             fontSize:24,
             fontWeight:"bold",
             color:'white'
           }}>
           CHECKOUT
         </Text>
       </TouchableOpacity>

       <View style={{height:20}} />


      </View>
                                </SafeAreaView>
                                   
                                <View paddingVertical={5} paddingHorizontal={20} style={styles.rowItem}>
                                    <MyButtons
                                        title="Save Items"
                                        customClick={() => { setProductID(genId()); submit() }}
                                        style={{ height: 40, marginTop: 10 }}
                                    />
                                    <View paddingHorizontal={20} />
                                    <TouchableOpacity
                                        onPress={() => { handleAdd() }}>

                                        <View style={[styles.circle, { height: 45, backgroundColor: 'blue' }]}>
                                            <POSIcon name='cart-plus' style={[styles.icons, { color: "#9fff" }]} />
                                        </View>
                                    </TouchableOpacity>
                                </View> 

                            </View>);
                    }
                }
            </Mutation> */}
            <View style={{flex:1,alignItems: 'center', justifyContent: 'center'}}>
         <View style={{height:20}} />
         <Text style={{fontSize:32,fontWeight:"bold",color:"#33c37d"}}>Cart food</Text>
         <View style={{height:10}} />

         <View style={{flex:1}}>

           <ScrollView>

             {
               dataCart.map((item)=>{
                 return(
                   <View style={{width:width-20,margin:10,backgroundColor:'transparent', flexDirection:'row', borderBottomWidth:2, borderColor:"#cccccc", paddingBottom:10}}>
                     <Image resizeMode={"contain"} style={{width:width/3,height:width/3}} source={{uri: item.food.image}} />
                     <View style={{flex:1, backgroundColor:'trangraysparent', padding:10, justifyContent:"space-between"}}>
                       <View>
                         <Text style={{fontWeight:"bold", fontSize:20}}>{item.food.name}</Text>
                         <Text>Lorem Ipsum de food</Text>
                       </View>
                       <View style={{flexDirection:'row',justifyContent:'space-between'}}>
                         <Text style={{fontWeight:'bold',color:"#33c37d",fontSize:20}}>${item.price*item.quantity}</Text>
                         <View style={{flexDirection:'row', alignItems:'center'}}>
                           <TouchableOpacity>
                             <Icon name="ios-remove-circle" size={35} color={"#33c37d"} />
                           </TouchableOpacity>
                           <Text style={{paddingHorizontal:8, fontWeight:'bold', fontSize:18}}>5</Text>
                           <TouchableOpacity>
                             <Icon name="ios-add-circle" size={35} color={"#33c37d"} />
                           </TouchableOpacity>
                         </View>
                       </View>
                     </View>
                   </View>
                 )
               })
             }

             <View style={{height:20}} />

             <TouchableOpacity style={{
                 backgroundColor:"#33c37d",
                 width:width-40,
                 alignItems:'center',
                 padding:10,
                 borderRadius:5,
                 margin:20
               }}>
               <Text style={{
                   fontSize:24,
                   fontWeight:"bold",
                   color:'white'
                 }}>
                 CHECKOUT
               </Text>
             </TouchableOpacity>

             <View style={{height:20}} />
           </ScrollView>
         </View>
         
      </View>
        </View>

    );
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
    container: {
        height: vh,
        width: vw,
        backgroundColor: '#fdfdfd',
        //marginLeft: vw/20,
        //marginRight: vw/20,
       // justifyContent:'center',
       // alignItems:'center',
    },
    header: {
        width: vw ,
        height: vw / 2.5,
        resizeMode: 'contain'
    },
    name: {
        fontFamily: 'maven-pro-regular',
        fontSize: vw / 22,
        color: '#252525'
    },
    title: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#252525'
    },
    subtitle: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b'
    },
    list: {
       margin: vw / 20,
        height: vh / 4,
        backgroundColor:'#0436',
       // marginBottom: vh / 20,
    },
    block: {
        flex: 1,
        height: vh / 4,
        margin: vw / 40
    },
    productImage: {
        width: '100%',
        height: vh / 7,
        resizeMode: 'contain',
        backgroundColor: '#ffffff'
    },
    
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        marginTop: 10,
        justifyContent: 'center',
    },
    icons: {
        fontSize: 30,
        color: 'white',
    },
    price: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b',
        //marginTop: 7
    }
});
