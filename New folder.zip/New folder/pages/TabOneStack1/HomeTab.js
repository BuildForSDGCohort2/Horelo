/*jshint -W033 */
import React, { useState, useEffect, useContext } from 'react';
import { ActivityIndicator, StyleSheet, View, Image,TextInput, FlatList, TouchableOpacity, Dimensions, Button } from 'react-native';
import ApolloClient from 'apollo-boost';
import {Text} from 'react-native-paper';
import MyTextInput from '../../components/MultiLineTextInput';
import gql from 'graphql-tag';
import { Query } from 'react-apollo';
import { UserContext } from '../../App';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import * as Font from 'expo-font';
import MyButton from '../../components/MyButtons';
import { set } from 'ramda';
import Autocomplete from 'react-native-autocomplete-input';
import CartItem from '../../components/CartItem';
import AsyncStorage from '@react-native-community/async-storage';
import Icon from 'react-native-vector-icons/Ionicons';


const GET_PRODUCTS = gql`
{
  org_product_view {
    description
    industry
    orgname
    price
    qty
    units
    image
    orgid
    name
    logo
    pdtid
  }
  users {
    name
    email
    avatar
    org_id
    organizations{
      name
      logo
    }
    dept
    role
    phone
  }
}
`

export default function HomeTab({route, navigation }) {
    let trans = [];
    const user_context = useContext(UserContext);
    var [list, setList] = React.useState(trans);
    const [querySections, setQuerySections] = useState('');
    const [clicked, setClicked] = useState(false);
    const [pdt_name, setPdt_name] = useState('');
    const [pdt_image, setPdt_image] = useState('');
    const [amounts, setAmounts] = useState('');
    const [quantity, setQuantity] = useState('');
    const [price, setPrice] = useState('');
    const [pdtID, setPdtID] = useState('');
    const [orgID, setOrgID] = useState('');
    const [orgName, setOrgName] = useState('');
    const [count, setCount] = useState(0);
    const [title, setTitle] = useState('Title here');
    const [dataCart, setDataCart] = React.useState([]);

    
    let cart= dataCart.length == 0 ? 0 : dataCart.length ;

  
   
    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: 'Shopping',
            headerRight: () => (
            <TouchableOpacity
                style={{ marginRight: 10, marginBottom: 20 }}
                onPress={() => { navigation.navigate('Cart') }}>
                <Text style={[{ marginBottom: 1, marginLeft:13,color: "#fff", }]}>{cart}</Text>
                <View style={[{ height: 20, }]}>
                    <POSIcon name='cart-plus' style={[{ fontSize: 30, fontWeight: 'bold', color: "#fff",marginBottom:10 }]} />
                </View>
            </TouchableOpacity>
        ), });
    }, [navigation, cart]);
  
      const saveItem = async () => {
        
      }
    
    function cartAdd(dataItem) {
      
        const itemcart = {
            item: dataItem,
            quantity:  1,
            price: dataItem.price,
            pref:"none"
          }
       
          AsyncStorage.getItem('cart').then((datacart)=>{
              if (datacart !== null) {
                // We have data!!
                const cart = JSON.parse(datacart)
                cart.push(itemcart)
                AsyncStorage.setItem('cart',JSON.stringify(cart));
              }
              else{
                const cart  = []
                cart.push(itemcart)
                AsyncStorage.setItem('cart',JSON.stringify(cart));
              }
              alert("Add to Cart");
              AsyncStorage.getItem('cart').then((cart)=>{
                if (cart !== null) {
                  // We have data!!
                  const cartfood = JSON.parse(cart)
                  //const uniquecart = [...new Map(cartfood.map(item=>[item[item.item.pdtid], item])).values()];
                  const uniquecart = Object.values(cartfood.reduce((acc, cur)=>Object.assign(acc,{[cur.item.pdtid]:cur}),{}));
                  setDataCart(uniquecart);
                }
              })
              .catch((err)=>{
                alert(err)
              })
            })
            .catch((err)=>{
              alert(err)
            })
       
    }
    
  
    return (
        <View >
        <View style={[{flex:1},styles.container]}></View>
            <View style={{ marginLeft: 30, marginTop: 30 }}>
                <Text style={styles.title}>SHOPS:</Text>
                <Text style={styles.subtitle}>SELECTION:</Text>
            </View>
            <Query query={GET_PRODUCTS} 
            
            fetchPolicy='cache-and-network'>
                {({ loading, error, data }) => {
                    if (loading) return <View styles={styles.activity}>
                        <ActivityIndicator size="large" color="#000ff" />
                    </View>
                    if (error) return <View>{console.log("my error gql " + error)}
                        <Text>Data loading error ${error.message} </Text>
                        <MyButton
                            style={{ width: 100 }}
                            title={"refresh"}
                            onPress={() => {}}
                        />
                    </View>
                   // setDataList(data.org_product_view) 
                        function findSection(querySections) {
                            if (querySections === '') {
                                return [];
                            }

                             const regex = new RegExp(`${querySections.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&').trim()}`, 'ig');
                            return (data.org_product_view.filter(sectionCollect => 
                                sectionCollect.name.search(regex) >= 0
                            ||  sectionCollect.orgname.search(regex) >= 0
                            ));
                        }
                        var fSections = findSection(querySections);
                        const comp = (a, b) => a.toLowerCase().trim() === b.toLowerCase().trim();

                         //setSectionCollection(data.org_product_view);
                         data.users.forEach(function (obj) {
                            user_context.setOrg_id(obj.org_id);
                            user_context.setDept_id(obj.dept);
                            user_context.setRole(obj.role);
                            user_context.setPhone(obj.phone);
                            user_context.setEmail(obj.email);
                            user_context.setUsername(obj.name);
                            user_context.setAvatar(obj.avatar);
                            user_context.setLogo(obj.organizations.logo);
                            user_context.setOrgName(obj.organizations.name);
                            AsyncStorage.setItem(
                                'CurrentProfile',
                                JSON.stringify({
                                    username:obj.name,
                                    avatar:obj.avatar,
                                    orgID: obj.org_id,
                                    deptID: obj.dept_id,
                                    role: obj.role,
                                    phone:obj.phone,
                                    others: obj.others,
                                    email: obj.email,
                                    orgName:obj.organizations.name,
                                    logo:obj.organizations.logo
                                })
                            ).then(() => {
                               // alert('Profile Set');
                            });
                        });   

                    return (
                        <View>
                            <View style={{ flex: 1, top: 0, alignItems: 'center' }}>
                                <View style={styles.autocompleteContainer}>
                                    <Autocomplete
                                        autoCapitalize="words"
                                        autoCorrect={false}
                                        data={clicked || fSections.length === 1 && comp(querySections, data.org_product_view[0].name) || fSections.length === 1 && comp(querySections, data.org_product_view[0].orgname) ? [] : fSections}
                                        defaultValue={querySections}
                                        onChangeText={(text) => { setQuerySections(text); setClicked(false) }}
                                        onPress={() => setClicked(true)}
                                        placeholder="Enter the Shop or Item name title"
                                        renderItem={({ item }) => (
                                            <TouchableOpacity onPress={() => {
                                                setClicked(true);
                                                setQuerySections(item.name);
                                                navigation.navigate('Products', {itemPass: item})
                                            }}>
                                                <Text style={styles.text}>
                                        {item.name}  {item.orgname}</Text>
                                                <Image style={[styles.productImage,{borderRadius:270}]} source={{ uri: item.logo }} />
                                            </TouchableOpacity>
                                        )}
                                    />
                                </View>
                            </View>

                            <FlatList
                                style={styles.list}
                                data={data.org_product_view}
                                renderItem={({item}) =>
                                <TouchableOpacity
                                onPress={()=>{}}
                                >
                                    <View style={{
                                        //backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#f99f",
                                        marginTop:35,
                                        width:vw/3.5
                                    }} >
                                        <CartItem 
                                            title={item.name}
                                            price={"Ugx: " + (item.price)
                                            .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                                            }
                                               // .toFixed(0)
                                               // .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')} 
                                            image={item.image}
                                            logo={item.logo}
                                            status={item.orgname}
                                            orgClick={() => navigation.navigate("Products", { itemPass: item })}
                                            productClick={() => navigation.navigate("ProductPage", { item: item })}
                                            cartClick={() => {
                                                cartAdd(item);
                                               /*  const newList = list.concat({ 
                                                    pdt_image:item.image,
                                                    //pdt_image:item.image,
                                                    pdt_name:item.name, 
                                                    amounts:item.price, 
                                                    quantity:1, 
                                                    price:item.price, 
                                                    pdtID:item.pdtid, 
                                                    orgID:item.orgid, 
                                                    orgName:item.orgname});
                                                setList(newList);
                                                //user_context.setCart(newList);
                                                setCount(count+1); 
                                                console.log("my Text " + list.map(item => console.log(item)) + " SEND"+ count);
                                            */ }}                                          
                                            />
                                            </View></TouchableOpacity>}
                                horizontal={true}
                                ItemSeparatorComponent={()=><View style={{
                                    flex: 1,
                                    height: 1,
                                    backgroundColor: '#e4e4e4',
                                    marginLeft: 10,
                                }} />}
                                enableEmptySections={true}
                                keyExtractor={(item, index) => index.toString()}
                            // ListHeaderComponent={renderHeader}
                            />
                        </View>);
                }
                }
            </Query>

        </View>


    );  
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
    autocompleteContainer: {
        flex: 1,
        left: 15,
        position: 'absolute',
        right: 0,
        top: 0,
        zIndex: 1, width: 300
    },
    container: {
        height: vh,
        width: vw,
        backgroundColor: '#fdfdfd'
    },
    header: {
        width: vw,
        height: vw / 3.6,
        resizeMode: 'stretch'
    },
    title: {
        fontFamily: 'ValidityScriptBI',
        fontSize: vw / 22,
        color: '#252525'
    },
    subtitle: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b'
    },
    list: {
        margin: vw / 40
    },
    block: {
        //flex: 1,
        height: vh / 10,
        margin: vw / 10
    },
    productImage: {
        width: '100%',
        //height: '50%',
        height: vh / 20,
        resizeMode: 'contain',
        backgroundColor: '#ffffff'
    },
    name: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#252525',
        width: '80%',
        marginTop: 2
    },
    price: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b',
        marginTop: 2,
    }, 
   /*  viewStyle: {
        justifyContent: 'center',
        flex: 1,
        marginTop: 40,
        padding: 16,
    }, */
    textStyle: {
        padding: 5,
    },
    textInputStyle: {
        height: 40,
        borderWidth: 1,
        paddingLeft: 5,
        borderColor: '#009688',
        backgroundColor: '#FFFFFF',
    },
});
{/* renderItem={({ item }) => <TouchableOpacity style={[styles.block,{width:vw/4}]} onPress={() => navigation.navigate('ProductPage', { item: item })}>
                                    <Text style={styles.name}>{item.orgname}</Text>
                                    <Image style={styles.productImage} source={{ uri: item.image }} />
                                    <Text style={styles.name}>{item.name}</Text>
                                    <Text style={styles.price}>{item.price}</Text>
                                </TouchableOpacity>} */}
                                //numColumns={2}