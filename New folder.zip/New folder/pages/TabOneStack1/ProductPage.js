import React, { useState, useEffect, useContext } from 'react';
import { View, StyleSheet, Image,ImageBackground, TouchableOpacity, Dimensions } from 'react-native';
import { UserContext } from '../../App';
import {Text} from 'react-native-paper';
import POSIcon from '@expo/vector-icons/FontAwesome5';



export default function ProductPage({ route, navigation })  {
    const { item } = route.params;
    const user_context = useContext(UserContext);
    const [dataCart, setDataCart] = React.useState([]);

    
    let cart= dataCart.length == 0 ? 0 : dataCart.length ;

  
   
    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: item.name,
            headerRight: () => (
            <TouchableOpacity
                style={{ marginRight: 10, marginBottom: 20 }}
                onPress={() => { navigation.navigate('Cart') }}>
                <Text style={[{ marginBottom: 1, marginLeft:13,color: "#000", }]}>{cart}</Text>
                <View style={[{ height: 20, }]}>
                    <POSIcon name='cart-plus' style={[{ fontSize: 30, fontWeight: 'bold', color: "#000",marginBottom:10 }]} />
                </View>
            </TouchableOpacity>
        ), });
    }, [navigation, cart]);
  
      const saveItem = async () => {
        
      }
    
    function cartAdd(dataItem) {
      
        const itemcart = {
            item: item,
            quantity:  1,
            price: item.price,
            pref:"none"
          }
       
          AsyncStorage.getItem('cart').then((datacart)=>{
              if (datacart !== null) {
                // We have data!!
                const cart = JSON.parse(datacart)
                cart.push(itemcart)
                AsyncStorage.setItem('cart',JSON.stringify(cart));
              }
              else{
                const cart  = []
                cart.push(itemcart)
                AsyncStorage.setItem('cart',JSON.stringify(cart));
              }
              alert("Add to Cart");
              AsyncStorage.getItem('cart').then((cart)=>{
                if (cart !== null) {
                  // We have data!!
                  const cartfood = JSON.parse(cart)
                  //const uniquecart = [...new Map(cartfood.map(item=>[item[item.item.pdtid], item])).values()];
                  const uniquecart = Object.values(cartfood.reduce((acc, cur)=>Object.assign(acc,{[cur.item.pdtid]:cur}),{}));
                  setDataCart(uniquecart);
                }
              })
              .catch((err)=>{
                alert(err)
              })
            })
            .catch((err)=>{
              alert(err)
            })
       
    }
    
        return (
            <View style={styles.container}>
                <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}><Text style={styles.backText}>X</Text></TouchableOpacity>
                <ImageBackground source={{ uri: item.logo }} style={{ ...styles.backgroundFill, backgroundColor: 'teal' }} />
                <Image style={styles.productImage} source={{ uri: item.image }} />
                <View style={styles.details}>
                    <Text style={styles.title}>{item.name}</Text>
                    <View style={{flexDirection:'row-reverse'}}>
                    <TouchableOpacity onPress={()=>{cartAdd(item)}}>
                        <Text style={styles.detail}> Add To Cart</Text>
                    </TouchableOpacity>
                    <Text style={styles.subtitle}>{item.price}</Text>
                    </View>
                    <Text style={styles.description}>{item.description}</Text>
                    <Text style={styles.detail}>{`Unit Type: ${item.units}`}</Text>
                </View>
            </View>
        );
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
    container: {
        height: vh,
        width: vw,
        backgroundColor: '#fdfdfd'
    },
    backButton: {
        position: 'absolute',
        top: vh / 18,
        left: vw / 30,
        zIndex: 10,
        width: 50,
        height: 50,
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    backText: {
        fontFamily: 'maven-pro-bold',
        fontSize: 23,
        color: '#fff',
    },
    backgroundFill: {
        width: '100%',
        height: vh / 3.2
    },
    productImage: {
        width: '100%',
        height: vh / 2.7,
        resizeMode: 'contain',
        position: 'absolute',
        top: vh / 14
    },
    details: {
        margin: 50,
        position: 'absolute',
        top: vh / 2.5
    },
    title: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 14,
        color: '#252525'
    },
    subtitle: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 14,
        color: '#bf200b',
        marginTop: 10
    },
    description: {
        fontFamily: 'maven-pro-regular',
        fontSize: vw / 22,
        color: '#4c4c4c',
        marginTop: 20
    },
    detail: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b',
        marginTop: 20
    },
});