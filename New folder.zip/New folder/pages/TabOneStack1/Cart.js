/*jshint -W033 */
import React, { useState, useEffect, useContext } from 'react';
import { Alert,ScrollView,StyleSheet,SafeAreaView, View, Image, FlatList, TouchableOpacity, Dimensions, Button } from 'react-native';
import { Text,TextInput } from 'react-native-paper';
import gql from 'graphql-tag';
import createApolloClient from '../apollo';
import { UserContext } from '../../App';
import { Mutation } from 'react-apollo';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import InputSpinner from "react-native-input-spinner";
import EmptyList from '../../components/EmptyList';
import genId from '../../assets/getID';
import MyTextInput from '../../components/MultiLineTextInput';
import MyButtons from '../../components/MyButtons';
import CartPage from '../../components/CartPage';
import AsyncStorage from '@react-native-community/async-storage';
import Icon from '@expo/vector-icons/Ionicons';

const INSERT_ORDER = gql`
  mutation ($orgID: String, $userId: String, $trans_id: String,
     $pdtID: String, $amounts: numeric, $phone:String,
    $quantity: Int, $pdt_name: String, $comment:String){
    insert_orders  (
      objects: [{
        orgID: $orgID,
        userID: $userId,
        pdt_id: $pdtID,
        amount: $amounts,
        items: $quantity,
        pdt_name: $pdt_name,
        trans_id:$trans_id,
        phone:$phone,
        comment:$comment,
      }]
    ){
      returning {
        id
        amount
        items
        pdt_name
        trans_id
        phone
      }
    }
  }
`;
  
export default function Cart({route, navigation }) {
    const user_context = useContext(UserContext);
  const client = createApolloClient(user_context.token);

    //const [orgID, setOrgID] = React.useState(null);
    const [orgName, setOrgName] = React.useState(null);
    const [userId, setUserId] = React.useState(user_context.userId);
    //const [pdtID, setPdtID] = React.useState(null);
    //const [amounts, setAmounts] = React.useState(0);
    const [data, setData] = React.useState(null);
    //const [pdt_name, setPdt_name] = React.useState(null);
    const [pdt_image, setPdt_image] = React.useState(null);
    //const [quantity, setQuantity] = React.useState(1);
    const trans_id =genId();
    const [price, setPrice] = React.useState(0);
    const [phone, setPhone]= React.useState(user_context.phone);
    //const [comment, setComment] = React.useState(null);
    const [list, setList] = React.useState();
    const [dataCart, setDataCart] = React.useState([]);
    const [reOpen, setReOpen] = React.useState(false);
    var   orgID=''; 
    var pdtID='';
    var amounts=1; 
    var quantity=1;
    var pdt_name='';
    var comment=''; 
let  qty=1;
    let cart= dataCart !== null ? dataCart.reduce((acc, cart) => {
                                    return acc + (cart.quantity * cart.price);
                                }, 0) : 0;
   React.useLayoutEffect(() => {

    AsyncStorage.getItem('cart').then((cart)=>{
        if (cart !== null) {
          // We have data!!
          const cartfood = JSON.parse(cart)
          //const uniquecart = [...new Map(cartfood.map(item=>[item[item.item.pdtid], item])).values()];
          const uniquecart = Object.values(cartfood.reduce((acc, cur)=>Object.assign(acc,{[cur.item.pdtid]:cur}),{}));
          setDataCart(uniquecart);
        }
      })
      .catch((err)=>{
        alert(err)
      })
}, []);
React.useLayoutEffect(() => {
    cart= dataCart !== null ? dataCart.reduce((acc, cart) => {
        return acc + (cart.quantity * cart.price);
    }, 0) : 0;
}, [reOpen]);
    React.useLayoutEffect(() => {
        
        navigation.setOptions({ 
            title: 'My Cart',
            headerRight: () => (
                <Text style={[{ fontFamily: 'maven-pro-bold', fontSize: 22, marginBottom: 1, }]}>
               :{(dataCart.reduce((acc, cart) => {
        return acc + (cart.quantity * cart.price);
    }, 0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}/= 
            </Text>
        ), });
    }, [navigation,cart]);
    function onChangeQual(i,type)
    {
      const dataCar = dataCart
      dataCar[i].quantity = type;
      console.log(type);
      console.log(dataCar[i].quantity );
      console.log(dataCar[i].price );
      setDataCart(dataCar);
      console.log(dataCart[i].price );
      setReOpen(!reOpen);
     /*  let cantd = dataCar[i].quantity;
  
      if (type) {
       cantd = cantd + 1
       dataCar[i].quantity = cantd
       setDataCart(dataCar)
      }
      else if (type==false&&cantd>=2){
       cantd = cantd - 1
       dataCar[i].quantity = cantd
       setDataCart(dataCar)
      }
      else if (type==false&&cantd==1){
       dataCar.splice(i,1)
       setDataCart(dataCar)
      }  */
    }
    function onChangePref(i,type)
    {
      const dataCar = dataCart
      dataCar[i].pref = type;
      setDataCart(dataCar);
      setReOpen(!reOpen);
    }
    function onRemoveItem(i,type)
    {
        const dataCar = dataCart
      // let cantd = dataCar[i].quantity;
     if (type==false){
       dataCar.splice(i,1)
       setDataCart(dataCar)
      } 
      setReOpen(!reOpen);
    }
    function onCancel()
    {
      try
      {AsyncStorage.removeItem('cart')
    //navigation.popToTop();
    }
      catch(err){
        alert(err)
      }

    }
    const  onOrder = async () => {
      
      await client.mutate({
          mutation: gql`
          mutation ($orgID: String, $userId: String, $trans_id: String,
            $pdtID: String, $amounts: numeric, $phone:String,
           $quantity: Int, $pdt_name: String, $comment:String){
           insert_orders  (
             objects: [{
               orgID: $orgID,
               userID: $userId,
               pdt_id: $pdtID,
               amount: $amounts,
               items: $quantity,
               pdt_name: $pdt_name,
               trans_id:$trans_id,
               phone:$phone,
               comment:$comment,
             }]
           ){
             returning {
               id
               amount
               items
               pdt_name
               trans_id
               phone
             }
           }
         }
       `  ,
          variables: {
            orgID, userId, trans_id,
            pdtID, amounts, phone,
           quantity, pdt_name, comment
          }
      }).then(console.log);
      /* }).then((result) => {
          console.log("graphql response", result);
          return result.data;
      }).catch((error) => {
          console.log("Graphql query error", error);

          let err = error;
          if (error.graphQlErrors && error.graphQlErrors.length > 0)
              err = error.graphQlErrors[0];
          throw err;
      }); */

  };
    
    return (
        <View style={styles.container}>
            <Mutation
                mutation={INSERT_ORDER}
                variables={{
                  orgID, userId, trans_id,
                  pdtID, amounts, phone,
                 quantity, pdt_name, comment
                }}
            >
                {

                    (insertOrders, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text>${error.message} {console.log("my error gql " + error)}</Text>;
                            }
                            if (loading || list === []) {
                                return;
                            }

                            
                            console.log(trans_id+"  my trans is");
                            dataCart.map((obj, i) => {
                                orgID=obj.item.orgid; 
                              pdtID=obj.item.pdtid; 
                              pdt_name=obj.item.name; 
                              amounts=obj.price; 
                               quantity=obj.quantity;
                               comment=obj.pref;
                               
                            console.log(pdt_name);
                                onOrder();
                               // insertOrders();
                           }); 
                            // insertOrders();
                            Alert.alert("Order Sent!");
                            onCancel();
                            //setList([]);
                        }
                        return (
            <View style={{flex:1,alignItems: 'center', justifyContent: 'center'}}>
         <View style={{height:10}} />
         <Text style={{fontSize:32,fontWeight:"bold",color:"teal"}}>Cart({dataCart.length})</Text>
         <View style={{flex:1}}>

           <ScrollView>

             {
               dataCart.map((obj,i)=>{
                 return(
                   <View style={{width:vw-20,margin:5,backgroundColor:'transparent', flexDirection:'row', borderBottomWidth:2, borderColor:"#cccccc", paddingBottom:10}}
                  
                   >
                     <Image resizeMode={"contain"} style={{width:vw/3,height:vw/3, borderRadius:35}} source={{uri: obj.item.image}} />
                     <View style={{flex:1, backgroundColor:'trangraysparent', padding:10, justifyContent:"space-between"}}>
                       <View>
                         <View style={{flexDirection:'row'}}>
                 <Text style={{fontWeight:"bold", fontSize:20}}>{obj.item.name}</Text><Text style={{marginTop:4}}>({obj.item.qty}{obj.item.units})</Text></View>
                         <TextInput
                                placeholder = {"size:40, Pepper:hot, color:blue"}
                                onChangeText = {(text) => {onChangePref(i,text);}}
                                style = {{ fontSize:14 }}
                                multiline = {true}
                                value = {obj.pref}
                                />
                       </View>
                       <View style={{flexDirection:'row',justifyContent:'space-between', alignItems:"center"}}  >
                         <Text style={{fontWeight:'bold',color:"#33c37d",fontSize:20}}>{(obj.price * obj.quantity).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</Text>
                         <InputSpinner
                                    style={{marginLeft: vw/50,
                                        //marginRight: vw/20,
                                       }}
                                                max={1000}
                                                min={1}
                                                step={1}
                                                type={'float'}
                                                colorMax={"#f04048"}
                                                colorMin={"#40c5f4"}
                                                color={"#9777"}
                                                value={quantity}
                                                rounded={false}
                                                arrows={false}
                                                height={vw/10}
                                                width={100}
                                                onChange={(num) => {
                                                   //setQuantity(num);
                                                   onChangeQual(i,num);
                                                   
                                                }}
                                            />
                           {/* <TouchableOpacity onPress={()=>onChangeQual(i,false)}>
                             <Icon name="ios-remove-circle" size={35} color={"#33c37d"} />
                           </TouchableOpacity >
                           <Text style={{paddingHorizontal:8, fontWeight:'bold', fontSize:18}}>5</Text>
                           <TouchableOpacity onPress={()=>onChangeQual(i,true)}>
                             <Icon name="ios-add-circle" size={35} color={"#33c37d"} />
                           </TouchableOpacity> */}
                       </View>
                       <View style={{flexDirection:'row-reverse',justifyContent:'space-between'}}  >
                       <Text style={{ fontWeight:'bold', fontSize:14}}>{obj.item.orgname}</Text>
                       <TouchableOpacity onPress={()=>onRemoveItem(i,false)} style={{ backgroundColor:"pink"}}>
                       <Text style={{ fontWeight:'bold', fontSize:14}}>Remove</Text>
                       </TouchableOpacity>
                       
                       </View>
                     </View>
                   </View>
                 )
               })
             }
<TouchableOpacity style={{
                 backgroundColor:"red",
                 width:vw-40,
                 alignItems:'center',
                 padding:10,
                 borderRadius:15,
                 margin:20
               }}>
               <Text style={{
                   fontSize:24,
                   fontWeight:"bold",
                   color:'white'
                 }}>
                CANCEL
               </Text>
             </TouchableOpacity>
           </ScrollView>
         </View>
         <TouchableOpacity 
         onPress={()=>{ submit();}}
         style={{
                 backgroundColor:"#33c37d",
                 width:vw-40,
                 alignItems:'center',
                 padding:10,
                 borderRadius:15,
                 margin:20
               }}>
               <Text style={{
                   fontSize:24,
                   fontWeight:"bold",
                   color:'white'
                 }}>
                 ORDER
               </Text>
             </TouchableOpacity>

      </View>
      );
                    }
                }
            </Mutation>
        </View>

    );
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
    container: {
        height: vh/1.3,
        width: vw,
        backgroundColor: '#fdfdfd',
       // marginBottom:10,
        //marginLeft: vw/20,
        //marginRight: vw/20,
       // justifyContent:'center',
       // alignItems:'center',
    },
    header: {
        width: vw ,
        height: vw / 2.5,
        resizeMode: 'contain'
    },
    name: {
        fontFamily: 'maven-pro-regular',
        fontSize: vw / 22,
        color: '#252525'
    },
    title: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#252525'
    },
    subtitle: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b'
    },
    list: {
       margin: vw / 20,
        height: vh / 4,
        backgroundColor:'#0436',
       // marginBottom: vh / 20,
    },
    block: {
        flex: 1,
        height: vh / 4,
        margin: vw / 40
    },
    productImage: {
        width: '100%',
        height: vh / 7,
        resizeMode: 'contain',
        backgroundColor: '#ffffff'
    },
    
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        marginTop: 10,
        justifyContent: 'center',
    },
    icons: {
        fontSize: 30,
        color: 'white',
    },
    price: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b',
        //marginTop: 7
    }
});
