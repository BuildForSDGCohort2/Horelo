import React, { useEffect, useState } from 'react';
import { ActivityIndicator,TextInput, Image, View, StyleSheet, Dimensions, FlatList, TouchableHighlight } from 'react-native';
import MyButton from '../../components/AddProductButton';
import {Text} from 'react-native-paper';
import MyButtons from '../../components/MyButtons';
import * as R from 'ramda';
import SwitchSelector from 'react-native-switch-selector';
import { Query, Mutation } from 'react-apollo';
import { UserContext } from '../../App';
import gql from 'graphql-tag';
import createApolloClient from '../apollo';
import AsyncStorage from '@react-native-community/async-storage';

export const GET_Products = gql`
    query products($orgID: String!) {
  products(where: {org_id: {_eq: $orgID}}){
    id
    alias
    barcode
    name 
    quantity
    units
    subcategory
    section
    image
    pdt_id
    org_id
    description
    category
    cost
    price
  }

}`;
const options = [
    { label: 'PriceList', value: '0' },
    { label: 'Stock', value: '1' },
];
const refetchQueries = [{ query: GET_Products }];
export default function Stock({ navigation }) {
    const [key, setKey] = React.useState(options[0]);
    const [price, setPrice] = React.useState('');
    var num;
    const [priceList, setPriceList] = React.useState([]);

    const [isLoading, setIsLoading] = React.useState(false);
    const [pdt_Name, setPdt_Name] = React.useState(null);
    const [id, setPdtID] = React.useState(null);
    const [productID, setProductID] = React.useState(null);
    const [keyLabel, setKeyLabel] = React.useState(key.label);
    const [keyValue, setKeyValue] = React.useState(key.value);
    const user_context = React.useContext(UserContext);
    const client = createApolloClient(user_context.token);

    const orgID = user_context.org_id;

    const [val, setVal] = React.useState("price");
    /* function numFormat(num){
        //num = price;
       // return setPrice(value.toFixed().trimLeft("$"));
        return Number(num).toFixed(2).replace(/[$,]/g,'');
    } */
    const submit = async () => {

        await client.mutate({
            mutation: gql`
        mutation ($productID: String, $price: numeric, $id:Int){
          update_products (
            _set: { price: $price},
           where:{
               pdt_id: {
                   _eq: $productID
                },_and: {id: {_eq: $id}}
            }

          ) {
            affected_rows
            returning{
     id
            }
          }
        }
      `  ,
            variables: {
                id: id,
                price: price,
                productID: productID
            } //,refetch: {GET_Products},
            //,refetchQueries
        }).then(console.log);
    }
    const numFormat = price => {
        //setPrice(price * 1);
        return Number(price.replace(/[^0-9.-]+/g, ''));
    };
    const format = amount => {
        setAmount(price * quantity * 1);
        return Number(amount)
            .toFixed(2)
            .replace(/\d(?=(\d{3})+\.)/g, '$&,');
    };

    return (
        <View
            style={[styles.scene, { backgroundColor: '#ff24' }]} >
            <View style={styles.view}>
                <Text style={styles.view}>Product lists</Text>
            </View>
            <View style={{ paddingTop: 5 }} />
            <SwitchSelector
                options={options}
                hasPadding={true}
                bold={true}
                initial={0}
                fontSize={12}
                textColor={'#aaaaaa'}
                selectedColor={'#fff'}
                buttonColor={'#262625'}
                backgroundColor={'#328'}
                borderColor={'#689'}
                onPress={value => {
                    setVal(value == 0 ? "price" : "stock");
                    setKey(options[value])
                    setKeyLabel(key.label)
                    setKeyValue(key.value)
                }}
            />



            <View style={[styles.scene, { backgroundColor: '#23bbbb' }]} >
                <Query query={GET_Products} 
                
                variables={{ orgID }} fetchPolicy='cache-and-network' >
                    {({ loading, error, data, refetch }) => {
                        if (loading) return <View styles={styles.activity}>
                            <ActivityIndicator size="large" color="#000ff" />
                        </View>
                        if (error) return <View>{console.log("my error gql " + error)}
                            <Text>Data loading error ${error.message} </Text></View>

                        
                            AsyncStorage.setItem('priceList', JSON.stringify(data.products));
                        
                        
                        return (
                            <View style={{ marginLeft: 10 }}>
                                {setIsLoading(false)}
                                {val === "price" ? <View>
                                    <Text style={{ color: '#fff' }}>Product Name: {pdt_Name}</Text>
                                    <TextInput
                                        placeholder={"Price"}
                                        //value={String(numFormat(price))}
                                        value={String(price)}
                                        onChangeText={(value) => {
                                            setPrice(Number(value));
                                        }}
                                        style={styles.textInput}
                                        keyboardType={"numeric"}
                                    />
                                    <View style={{flexDirection:'row-reverse', paddingHorizontal:10, alignItems:'center', justifyContent:'center'}}>
                                    <MyButtons
                                        title="Update Price"
                                        customClick={() => {
                                            submit();
                                            //refetch()
                                        }}
                                        style={{ backgroundColor: '#876', width: 100, marginBottom: 5 }}
                                    />
                                    <View paddingHorizontal={10} />
                                    <MyButtons
                                        title="Refetch"
                                        customClick={() => {
                                            refetch()
                                        }}
                                        style={{ backgroundColor: '#698', width: 100, marginBottom: 5 }}
                                    />
                                    </View>
                                </View>
                                    : <View />
                                }
                                <FlatList
                                    data={data.products}

                                    renderItem={({ item, index }) =>
                                        <View  {...item}>
                                            {val === "price" ?
                                                <TouchableHighlight
                                                    onPress={() => { setProductID(item.pdt_id); setPdtID(item.id); setPdt_Name(item.alias); setPrice(item.price); }}
                                                >
                                                    <View style={styles.item,
                                                    {
                                                        alignItems: 'center', flexDirection: 'row',
                                                        backgroundColor: index % 2 == 0 ? "#f4d4b4" : "#fdfdfe"
                                                    }}>
                                                        <View style={styles.incomecircle}>
                                                            <Image source={{ uri: item.image }} style={styles.icons} />
                                                        </View>
                                                        <View>
                                                            <Text style={[styles.name]}>{item.alias}</Text>
                                                            {/*  <Text style={[styles.price,{color:'#000aff'}]}></Text> */}
                                                            <Text style={[styles.price, { color: '#098', fontSize: 16 }]}>{Number(item.price)
                                                                .toFixed(2)
                                                                .replace(/\d(?=(\d{3})+\.)/g, '$&,')}</Text>
                                                        </View>
                                                    </View>
                                                </TouchableHighlight>

                                                :
                                                <TouchableHighlight
                                                    onPress={() => { navigation.navigate('EditProduct', { itemEdit: item }) }}>
                                                    <View style={styles.item, { alignItems: 'center', flexDirection: 'row', backgroundColor: index % 2 == 0 ? "#f4d4b4" : "#fdfdfd" }}>
                                                        <View style={styles.expenseCircle}>
                                                            <Image source={{ uri: item.image }} style={styles.icons} />
                                                        </View>
                                                        <View>
                                                            <Text style={[styles.name]}>{item.name}</Text>
                                                            <Text style={[styles.price, { color: '#000aff' }]}>{item.section}</Text>
                                                            <View style={{ flexDirection: 'row' }}>
                                                                <Text style={[styles.price, { color: '#098', fontSize: 16 }]}>{item.category}</Text>
                                                                <View paddingHorizontal={10} />
                                                                <Text style={[styles.price, { color: '#678', fontSize: 16 }]}>{item.subcategory} </Text>
                                                            </View>
                                                        </View>
                                                    </View>
                                                </TouchableHighlight>

                                            }
                                        </View>
                                    }
                                    keyExtractor={item => item.id.toString()}
                                    refreshing={isLoading}
                                    onRefresh={()=>{refetch()}}
                                />
                            </View>
                        );
                    }
                    }
                </Query>
            </View>
            <MyButton />
        </View>
    );
}


const styles = StyleSheet.create({
    activity: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
    scene: {
        flex: 1,
        fontFamily: 'ValidityScriptBI',
    },
    view: {
        alignItems: "center",
        justifyContent: "center",
        fontSize: 30,
        fontFamily: 'ValidityScriptBI',
    },
    tab: {
        padding: 5,
    },
    textInput: {
        paddingLeft: 10,
        marginLeft: 15,
        marginRight: 10,
        marginTop: 2,
        borderWidth: 1,
        borderColor: '#007FFF',
        backgroundColor: '#fff',
        color: '#000',
        width: 250,
        height: 40,
        borderRadius: 35,
        fontSize: 18,
    },
    item: {
        flex: 1,
        marginLeft: 1,
        flexDirection: 'row',
    },

    name: {
        fontSize: 18,
        fontWeight: 'bold',
        paddingLeft: 10
    },
    price: {
        fontSize: 11,
        fontWeight: 'bold',
        paddingLeft: 10
    },

    icons: {
        height: 50,
        width: 50,
        borderRadius: 35,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        borderTopLeftRadius: 35,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        backgroundColor: '#004f32',
        marginStart: 10,
        marginTop: 2,
        marginBottom: 3,
    },

});