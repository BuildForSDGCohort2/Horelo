/*jshint -W033 */

import React, { useState, useEffect } from 'react';
import { Alert, FlatList, Image, StyleSheet, Button, ScrollView, View,  KeyboardAvoidingView, SafeAreaView, TouchableOpacity } from 'react-native';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import {Text,TextInput} from 'react-native-paper';
import ListItem, { Separator } from '../Home/ListItem';
import MyTextInput from '../../components/MyTextInput';
import MultiLineTextInput from '../../components/MultiLineTextInput';
import MyButtons from '../../components/MyButtons';
import { BarCodeScanner } from 'expo-barcode-scanner';
import Modal from 'react-native-modal';
import gql from 'graphql-tag';
import { Mutation } from 'react-apollo';
import { UserContext } from '../../App';
import genId from '../../assets/getID';
import dateTime from '../../assets/getTS';
import { unitList, sectionList } from '../../assets/industries';
import Autocomplete from 'react-native-autocomplete-input';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import * as Permissions from 'expo-permissions';
import SaveButton from '../../components/SaveButton';


const UPDATE_PRODUCTS = gql`
  mutation ($productID: String!, $siUnits: String, $quantity: Int!, $image:String!,$userID:String!,
    $pdt_name: String!, $pdt_barcode: String, $price: numeric!, $cost: numeric, $id:Int!, 
    $alias: String!, $section:String!, $subcategory: String!,$category: String!, $description:String! ){
    update_products  (
      _set: {
    barcode:$pdt_barcode,
    name : $pdt_name,
    quantity:$quantity,
    units: $siUnits,
    subcategory:$subcategory,
    section:$section,
    image:  $image,
    description:$description, 
    category:$category,
    cost:$cost,
    price:$price,
    editedBY:$userID,
    alias:$alias,
      },
      where:{
               id: {
                   _eq: $id
                }
            }
    ){
      affected_rows
    }
  }
`;

EditProduct.navigationOptions = {
    title: 'Edit Item',
};

export default function EditProduct({ route,navigation }) {
    const {itemEdit} = route.params;

    useEffect(() => {
       

        (async () => {
            const { status } = await BarCodeScanner.requestPermissionsAsync();
            setHasPermission(status === 'granted');
            getPermissionAsync();
        })();
    }, []);

    var n = 1;
    const user_context = React.useContext(UserContext);
    var id = itemEdit.id;
    var userID = user_context.userId;
    //var alias;
    var [alias, setAlias] = React.useState(null);
    var [text, setText] = React.useState('');
    var [hasPermission, setHasPermission] = useState(null);
    var [scanned, SetScanned] = useState(null);
    var [barcodeItem, SetBarcodeItem] = useState(null);
    var [modalVisible, setModalVisible] = useState(false);
    var [category, setCategory] = useState(null);
    var [subcategory, setSubcategory] = useState(null);
    var [section, setSection] = useState(null);
    var [pdt_name, setPdt_name] = useState(null);
    var [description, setDescription] = useState(null);
    var [pdt_barcode, setPdt_barcode] = useState(null);
    var [siUnits, setUnits] = useState(null);
    var [quantity, setQuantity] = useState(null);
    var [price, setPrice] = useState(null);
    var [cost, setCost] = useState(null);
    var [image, setImage] = useState(null);
    var productID = itemEdit.pdt_id;
    var [createdAT, setCreatedAT] = useState(null);
    const [unitsCollection, setUnitsCollection] = useState(unitList);
    const [sectionCollection, setSectionCollection] = useState(sectionList);
    const [queryResults, setQueryResults] = useState('');
    const [querySections, setQuerySections] = useState('');
    const [clicked, setClicked] = useState(false);
    var [show, setShow] = useState(false);




    const handleBarCodeScanned = ({ type, data }) => {
        SetScanned(true);
        SetBarcodeItem(data);
        // handleSearch(data);
        // Alert.alert('Bar code with type ${type} and  ${data} has been captured');
        SetScanned(null);
        setModalVisible(!modalVisible);
    };

    if (hasPermission === null) {
        return (<Text> Requesting for camera permission</Text>);
    }
    if (hasPermission === false) {
        return <Text>No access to camera</Text>
    }

   
    function findUnit(queryResults) {
        //method called every time when we change the value of the input
        if (queryResults === '') {
            //if the query is null then return blank
            return [];
        }
        /* function escapeRegExp(text) {
            return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
        } */
        //const { films } = this.state;
        //making a case insensitive regular expression to get similar value from the film json
        const regex = new RegExp(`${queryResults.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&').trim()}`, 'ig');
        //const regex = new RegExp(`^${queryResults.trim()}`, 'i');
        //return the filtered film array according the query from the input
        //return unitsCollection.filter(unitsCollection => unitsCollection.label.search(regex) >= 0);
        return unitsCollection.filter(unitsCollection => unitsCollection.label.search(regex) >= 0);
    }
    const fUnits = findUnit(queryResults);
    function findSection(querySections) {
        //method called every time when we change the value of the input
        if (querySections === '') {
            //if the query is null then return blank
            return [];
        }

        //const { films } = this.state;
        //making a case insensitive regular expression to get similar value from the film json
        const regex = new RegExp(`${querySections.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&').trim()}`, 'ig');
        //const regex = new RegExp(`${querySections.trim()}`, 'ig');
        //const regex = new RegExp(`^${queryResults.trim()}`, 'i');// first character
        //return the filtered film array according the query from the input
        //return unitsCollection.filter(unitsCollection => unitsCollection.label.search(regex) >= 0);
        return sectionCollection.filter(sectionCollect => sectionCollect.label.search(regex) >= 0);
    }
    var fSections = findSection(querySections);
    const comp = (a, b) => a.toLowerCase().trim() === b.toLowerCase().trim();

    const pickImage = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: false,
                base64: true,
                aspect: [4, 3],
                quality: 0.1,
            });
            if (!result.cancelled) {
                setImage('data:image/jpeg;base64,' + result.base64);
                setImage('data:image/jpeg;base64,' + result.base64);
            }

            //console.log(result);
        } catch (E) {
            console.log(E);
        }
    };
    //
    return (
        <SafeAreaView style={styles.flex}>
            <ScrollView>
                <KeyboardAvoidingView
                    behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>
                    <Mutation
                        mutation={UPDATE_PRODUCTS}
                        variables={{
                            productID,
                            category,
                            subcategory,
                            section,
                            pdt_name,
                            pdt_barcode,
                            siUnits,
                            quantity,
                            price,
                            cost,
                            alias,
                            image,
                            description,
                            id,
                            userID,
                        }}>
                        {
                            (updateProducts, { loading, error }) => {
                                const submit = () => {
                                    if (error) {
                                        return <Text> Error </Text>;
                                    }
                                    if (loading) {
                                        return;
                                    }
                                   //setCreatedAT(dateTime());
                                //    setDescription(description);
                                    alias = pdt_name + "_" + quantity + siUnits
                                    
                                     updateProducts();
                                    
                                    alert("product(s) updated!");
                                  
                                }
                                return (
                                    <View>
                                        <View style={styles.MainContainer}>

                                            <Text style={styles.text}>
                                                Section: </Text>

                                            <View style={{ flex: 1, top: 0, alignItems: 'center' }}>
                                                <View style={styles.autocompleteContainer}>
                                                    <Autocomplete
                                                        //autoCapitalize="none"
                                                        autoCapitalize="words"
                                                        autoCorrect={false}
                                                        //containerStyle={styles.autocompleteContainer}
                                                        //data to show in suggestion
                                                        data={clicked || fSections.length === 1 && comp(querySections, sectionCollection[0].label) ? [] : fSections}
                                                        //default value if you want to set something in input
                                                        defaultValue={querySections ? queryResults : itemEdit.section}
                                                        /*onchange of the text changing the state of the query which will trigger
                                                        the findFilm method to show the suggestions*/
                                                        //onKeyPress={() => { nativeEvent.key === 'Backspace' ? setQueryResults('') :  setQueryResults(text) }}
                                                        onChangeText={(text) => { setQuerySections(text); setClicked(false) }}
                                                        onPress={() => setClicked(true)}
                                                        placeholder="Enter the Sec title"
                                                        renderItem={({ item }) => (
                                                            //you can change the view you want to show in suggestion from here
                                                            <TouchableOpacity onPress={() => {
                                                                setClicked(true);
                                                                setSection(item.label);
                                                                setQuerySections(item.label)
                                                            }}>
                                                                <Text style={styles.text}>
                                                                    {item.label}</Text>
                                                            </TouchableOpacity>
                                                        )}
                                                    />
                                                    {/* <View style={stylesA.descriptionContainer}>
                                                        {sectionCollection.length > 0 ? (
                                                            <Text style={stylesA.infoText}>{querySections}</Text>
                                                        ) : (
                                                                <Text style={stylesA.infoText}>Enter The Film Title</Text>
                                                            )}
                                                    </View> */}
                                                </View>
                                            </View>
                                            <View paddingVertical={20} />
                                            <Text style={styles.text}>
                                                Category:  </Text>
                                            <MyTextInput
                                                placeholder={"category"}
                                                defaultValue={itemEdit.category}
                                                onChangeText={(value) => {
                                                    setCategory(value);
                                                }}
                                                style={styles.textInput}
                                            />
                                            <View paddingVertical={5} />

                                            <Text style={styles.text}>
                                                Subcategory: </Text>
                                            <MyTextInput
                                                placeholder={"Subcategory"}
                                                defaultValue={itemEdit.subcategory}
                                                onChangeText={(value) => {
                                                    setSubcategory(value);
                                                }}
                                                style={styles.textInput}
                                            />
                                            <Text style={styles.text}>
                                                Item Name:  {itemEdit.barcode}</Text>
                                            <MyTextInput
                                                placeholder={"Item Name"}
                                                defaultValue={itemEdit.name}
                                                onChangeText={(value) => {
                                                    setPdt_name(value);
                                                    alias = pdt_name + "_" + quantity + siUnits;

                                                }}
                                                style={styles.textInput}
                                            />
                                            <View style={styles.rowItem}>
                                                <View style={styles.rowItem}>
                                                    {barcodeItem && <TouchableOpacity
                                                        onPress={() => { SetBarcodeItem(null) }}>
                                                        <View style={styles.circle}>
                                                            <POSIcon name='minus' style={styles.icons} />
                                                        </View>
                                                    </TouchableOpacity>}
                                                    <View>
                                                        <Text
                                                            style={styles.text}
                                                        >Insert Barcode -></Text>
                                                        {itemEdit.barcode && <Text
                                                            placeholder={"Item Bar code"}
                                                            style={{ paddingLeft: 10, paddingVertical: 5, fontWeight: 'bold' }}
                                                        >{itemEdit.barcode}</Text>}</View>
                                                </View>
                                                <TouchableOpacity
                                                    onPress={() => { setModalVisible(true) }}>
                                                    {/* <Text style={styles.circle} />  */}
                                                    <View style={styles.circle}>
                                                        <POSIcon name='barcode' style={styles.icons} />
                                                    </View>
                                                </TouchableOpacity>

                                            </View>
                                            <Text style={styles.text}>
                                                Description: </Text>
                                            <View paddingVertical={5} style={{ marginLeft: 15 }}>

                                                <MultiLineTextInput
                                                    placeholder={"none or Item Description, uses or anything for a rare product"}
                                                    defaultValue={itemEdit.description}
                                                    onChangeText={(value) => {
                                                        setDescription(value);
                                                    }}
                                                    style={{
                                                        borderColor: '#007FFF',
                                                        borderWidth: 1,
                                                        width:300,
                                                        marginBottom:20,
                                                        //borderRadius: 35,
                                                       }}
                                                    multiline={true}
                                                    numberOfLines={5}
                                                />
                                            </View>
                                            <View paddingVertical={1} />

                                            <Modal
                                                animationType='slide'
                                                transparent={false}
                                                visible={modalVisible}
                                                onRequestClose={() =>
                                                    Alert.alert("modal has closed")}>
                                                <View style={styles.BarCodeContainer}>
                                                    <Text>{itemEdit.name}</Text>

                                                    <BarCodeScanner
                                                        onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
                                                        style={StyleSheet.absoluteFillObject}
                                                    >

                                                    </BarCodeScanner>
                                                    {scanned && <Button title={'tap to scan again'}
                                                        onPress={() => SetScanned(false)} />}

                                                </View>
                                                <Button style={{ marginBottom: 20 }} title="Cancel" onPress={() => { setModalVisible(!modalVisible) }} />

                                            </Modal>
                                            <Text style={styles.text}>
                                                Package/Unit Quantity: </Text>
                                            <MyTextInput
                                                placeholder="100"
                                                onChangeText={(value) => {
                                                    setQuantity(Number(value));
                                                    alias = pdt_name + "_" + quantity + siUnits;
                                                }}
                                                keyboardType="numeric"
                                                style={styles.textInput}
                                                defaultValue={String(itemEdit.quantity)}
                                            />
                                            <View paddingVertical={5} />

                                            <Text style={styles.text}>
                                                Measures Units:</Text>

                                            <View style={{ flex: 1, top: 0, alignItems: 'center' }}>
                                                <View style={styles.autocompleteContainer}>
                                                    <Autocomplete
                                                        autoCapitalize="none"
                                                        autoCorrect={false}
                                                        //containerStyle={styles.autocompleteContainer}
                                                        //data to show in suggestion
                                                        data={clicked || fUnits.length === 1 && comp(queryResults, unitsCollection[0].label) ? [] : fUnits}
                                                        //default value if you want to set something in input
                                                        defaultValue={queryResults ? queryResults : itemEdit.units}
                                                        /*onchange of the text changing the state of the query which will trigger
                                                        the findFilm method to show the suggestions*/
                                                        //onKeyPress={() => { nativeEvent.key === 'Backspace' ? setQueryResults('') :  setQueryResults(text) }}
                                                        onChangeText={(text) => { setQueryResults(text); setClicked(false) }}
                                                        //onPress={() => fUnits=[]}
                                                        placeholder="Enter the Unit title"
                                                        onPress={() => setClicked(true)}
                                                        renderItem={({ item }) => (
                                                            //you can change the view you want to show in suggestion from here
                                                            <TouchableOpacity onPress={() => {
                                                                setClicked(true);
                                                                setUnits(item.label);
                                                                setQueryResults(item.label);
                                                                alias = pdt_name + "_" + quantity + siUnits;

                                                            }}>
                                                                <Text style={styles.text}>
                                                                    {item.label}</Text>
                                                            </TouchableOpacity>
                                                        )}
                                                    />
                                                </View>
                                            </View>
                                            <View paddingVertical={20} />

                                            <Text style={styles.text}>
                                                Unit Price: </Text>
                                            <MyTextInput
                                                placeholder="2000"
                                                defaultValue={String(itemEdit.price)}
                                                onChangeText={(value) => {
                                                    setPrice(Number(value));
                                                }}
                                                keyboardType={"numeric"}
                                                style={styles.textInput}
                                            />
                                            <Text style={styles.text}>
                                                Unit Cost: </Text>
                                            <MyTextInput
                                                placeholder="1000"
                                                defaultValue={String(itemEdit.cost)}
                                                onChangeText={(value) => {

                                                    setCost(Number(value));
                                                }}
                                                keyboardType={"numeric"}
                                                style={styles.textInput}
                                            />


                                            <View paddingVertical={5} />
                                            <TouchableOpacity
                                                style={[styles.bigCircle, { marginLeft: 20, width: 100, height: 30, backgroundColor: 'teal', color: "#fff" }]}
                                                onPress={() => pickImage()}
                                            >
                                                <Text style={{ color: "#fff", padding: 5 }}>Select Image</Text>
                                            </TouchableOpacity>
                                            <View paddingVertical={5} />
                                            {
                                                image ?
                                                <View style={[styles.rowItem, { marginLeft: 20 }]}>
                                                    <TouchableOpacity
                                                        onPress={() => setImage(null)}>
                                                        <View style={[styles.circle, { backgroundColor: 'red', }]}>
                                                            <POSIcon name='minus' style={styles.icons} />
                                                        </View>
                                                    </TouchableOpacity>
                                                    <Image source={{ uri: image }} style={{
                                                        width: 100,
                                                        height: 100, borderRadius: 35, marginLeft: 10
                                                    }} />
                                                    </View> :
                                                    <View style={[styles.rowItem, { marginLeft: 20 }]}>
                                                     <TouchableOpacity
                                                        onPress={() => setImage("none")}>
                                                        <View style={[styles.circle, { backgroundColor: 'red', }]}>
                                                            <POSIcon name='minus' style={styles.icons} />
                                                        </View>
                                                    </TouchableOpacity>
                                                    <Image source={{ uri: itemEdit.image }} style={{
                                                        width: 100,
                                                        height: 100, borderRadius: 35, marginLeft: 10
                                                    }} />
                                                </View>
                                            }
                                        </View>
                                        <View style={{ marginTop: 20, marginBottom: 20, flexDirection: 'row' }}>

                                            <View paddingHorizontal={5} />
                                            {show ? <SaveButton
                                                title="CONFIRM"
                                                style={{ width: 100, backgroundColor: 'green', }}
                                                customClick={() => {
                                                    submit();
                                                    navigation.goBack();
                                                    setShow(false);
                                                }}
                                            /> : <SaveButton
                                                    style={{ width: 100, }}
                                                    title="UPDATE"
                                                    customClick={() => {
                                                        category ? category : setCategory(itemEdit.category);
                                                        subcategory ? subcategory : setSubcategory(itemEdit.subcategory);
                                                        section ? section : setSection(itemEdit.section);
                                                        pdt_name ? pdt_name : setPdt_name(itemEdit.name);
                                                        pdt_barcode ? pdt_barcode : setPdt_barcode(itemEdit.barcode);
                                                        siUnits ? siUnits : setUnits(itemEdit.units);
                                                        quantity ? quantity : setQuantity(itemEdit.quantity);
                                                        price ? price : setPrice(itemEdit.price);
                                                        cost ? cost : setCost(itemEdit.cost);
                                                        id ? id : setID(itemEdit.id);
                                                        setAlias(pdt_name + "_" + quantity + siUnits);
                                                        image ? image : setImage(itemEdit.image);
                                                        description ? description : setDescription(itemEdit.description);
                                                        setShow(true);
                                                        //submit();
                                                    }}
                                                />}

                                            <View paddingRight={30} />
                                            <SaveButton
                                                title="Delete"
                                                onPress={() => { del() }} />
                                        </View>
                                    </View>
                                );
                            }
                        }
                    </Mutation>
                </KeyboardAvoidingView>
            </ScrollView>
        </SafeAreaView>

    );
}
//
const getPermissionAsync = async () => {
    if (Constants.platform.ios || Constants.platform.android) {
        const { status: camera } = await Permissions.askAsync(Permissions.CAMERA);
        const { status: cameraRoll } = await Permissions.askAsync(
            Permissions.CAMERA_ROLL
        );
        if (camera && cameraRoll !== "granted") {
            alert("camera roll not  granted");
        }
    }
};
const styles = StyleSheet.create({
    autocompleteContainer: {
        flex: 1,
        left: 15,
        position: 'absolute',
        right: 0,
        top: 0,
        zIndex: 1, width: 300
    },
    flex: {
        flex: 1
    },
    MainContainer: {
        flex: 1,
        marginTop: 5,

        justifyContent: 'center',
    },
    BarCodeContainer: {
        flex: 1,
        alignItems: 'center',
        margin: 20,
        justifyContent: 'flex-start',

    },
    rowItem: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        marginTop: 10,
        justifyContent: 'flex-start',
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 0,
        marginTop: 10,
    },
    text: {
        paddingLeft: 10,
        marginLeft: 5,
        marginRight: 10,
        marginTop: 5,
        borderColor: '#007FFF',
        borderRadius: 35,
    },
    textInput: {
        paddingLeft: 10,
        marginLeft: 15,
        marginRight: 10,
        marginTop: 2,
        borderWidth: 1,
        borderColor: '#007FFF',
        width: 300,
        height: 40,
        borderRadius: 35,
        fontSize: 18,
    },
});
const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});
const stylesA = StyleSheet.create({
    container: {
        backgroundColor: '#F5FCFF',
        flex: 1,
    },
    autocompleteContainer: {
        backgroundColor: '#ffffff',
        borderWidth: 0,
    },
    descriptionContainer: {
        flex: 1,
        justifyContent: 'center',
    },
    itemText: {
        fontSize: 15,
        paddingTop: 5,
        paddingBottom: 5,
        margin: 2,
    },
    infoText: {
        textAlign: 'center',
        fontSize: 16,
    },
});