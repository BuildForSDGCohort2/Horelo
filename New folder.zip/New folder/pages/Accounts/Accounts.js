import React, { Component, useState, useEffect } from 'react';
import { ActivityIndicator, Button, StyleSheet, View, TouchableHighlight as TouchableOpacity } from 'react-native';
import { UserContext } from '../../App';
import {Text} from 'react-native-paper';
import AccountItem from '../../components/AccountItem';
import AccountAddItem from '../../components/AccountAddItem';
//import { withNavigation } from 'react-navigation';
import { Query, Mutation } from 'react-apollo';
import gql from 'graphql-tag';
import AsyncStorage from '@react-native-community/async-storage';


// inside App functional component
/* const GET_Accounts = gql`
query ($org_id: String!){
  accounts(where:{orgID: {_eq:$org_id}}){
    id
    name
    color
  }
  transactions_aggregate(where:{orgID: {_eq:$org_id}}) {
    aggregate {
      count(columns: createdAT)
      sum {
        amount
      }
    }
    nodes {
      amount
      createdAT
      cashflowByCashflowId {
        icon
        id
        name
      }
      trans_id
      accountByAccount {
        color
        id
        name
      }
    }
  }
}`;
 */
const GET_Accounts = gql`
query ($org_id: String!){
  accounts(where:{orgID: {_eq:$org_id}}){
    id
    name
    color
    initialBalance
  }
  
}`;
function Accounts({ navigation }) {
  const [accountsList, setAccountsList] = React.useState([]);

  const user_context = React.useContext(UserContext);
  const org_id = user_context.org_id;

  function cashFlowValues() {
    try {
        AsyncStorage.setItem('accountValues',JSON.stringify(accountsList));
    } catch (error) {
        
    }
     
}

    return (
      <View style={styles.MainContainer}>
        <Query query={GET_Accounts}
        
        variables={{ org_id, }} fetchPolicy='cache-and-network'>
          {({ loading, error, data }) => {
            if (loading) return <View styles={styles.activity}>
              <ActivityIndicator size="large" color="#000ff" /></View>
            if (error) return <View>{console.log("my error gql " + error)}
              <Text>Data loading error ${error.message}</Text></View>

            
              AsyncStorage.setItem('accountValues', JSON.stringify(data.accounts));
          
            return data.accounts.map((item) => {
                    return <AccountItem
                    //style={{backgroundColor:item.color}}
                        name={item.name}
                        amount={item.initialBalance}
                        color={item.color}
                      customClick={() => navigation.navigate('EditAccount', { itemEdit: item })} {...item} key={item.id}/>
                 
                  })
          }
          }
        </Query>

        {
          //renderButtons()
        
        }
       {/*  <AccountItem
          name={"obj.name"}
          amount={"obj.initialBalance"}
          title='titles'
          color={"red"}
          customClick={() => navigation.navigate('EditAccount', { item: obj })} /> */}

        <AccountAddItem customClick={() => navigation.navigate('AddAccount')} />
        
      </View>
    );
    // }
  
}

const styles = StyleSheet.create({
  MainContainer: {
    flex: 1,
    flexWrap: 'wrap',
    alignItems: 'flex-start',
    flexDirection: 'row',
  },

  actionButton: {
    fontSize: 20,
    height: 100,
    width: 100,
    color: 'white',
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingVertical: 20
  },

});
export default Accounts;
//export default withNavigation(Accounts);