import React, { useState, useEffect, useContext } from 'react';
import {
    SafeAreaView, TouchableOpacity,
    Button,
    ScrollView,
    StyleSheet,
    View,
} from 'react-native';
import {Text} from 'react-native-paper';
import Icon from '@expo/vector-icons/MaterialCommunityIcons';
import ColourPickers from '../../components/ColourPickers';
import Modal from 'react-native-modal';
// import FlatList from 'flatlist-react';
import chartPalette from '../../assets/colors';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import Header from '../../components/Header';
import Ionicons from '@expo/vector-icons/Ionicons';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { UserContext } from '../../App';

// import RNPickerSelect, { defaultStyles } from './debug';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import dateTime from '../../assets/getTS';
import { type } from 'ramda';

const INSERT_ACCOUNT = gql`
  mutation ($orgID: String!, $userId: String!, 
    $accountName: String!, $color: String, $initialBal: numeric,
    $deptID: String!){
    insert_accounts (
      objects: [{
        name: $accountName,
        createdBY: $userId,
        color: $color,
        orgID: $orgID,
        dept: $deptID,
        initialBalance: $initialBal,
      }]
    ){
      returning {
        id
              }
    }
  }
`;

const arrChartPalette = Object.values(chartPalette);

AddAccount.navigationOptions = {
    title: 'Add Account',
};
//export default class App extends React.Component {

export default function AddAccount({ navigation }) {
    const User_context = React.useContext(UserContext);
    const orgID = User_context.org_id;
    const userId = User_context.userId;
    const deptID = User_context.dept_id;
    const [modalVisible, setModalVisible] = useState(false);
    const [accountName, setAccountName] = useState(null);
    const [color, setColor] = useState('#400f');
    const [icon, setIcon] = useState("refresh");
    const [initialBal, setInitialBal] = useState(0);
    const [createdAT, setCreatedAT] = useState(null);


    return (
        <View style={styles.container}>
            {/*  <Header titleText="Add Category" /> */}
            <Mutation
                mutation={INSERT_ACCOUNT}
                variables={{
                    accountName,
                    color,
                    userId,
                    orgID,
                    deptID,
                    initialBal,
                }}

            >
                {
                    (insertAccount, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text> Error </Text>;
                            }
                            if (loading || accountName === '') {
                                return;
                            }
                            

                            insertAccount();
                            //setAccountName("");
                            alert("account Added Successfully")
                        }

                        return (
                            <View style={styles.MainContainer}>
                                <ScrollView>

                                    <View style={styles.rowItem}>
                                        <TouchableOpacity
                                            onPress={() => { setModalVisible(true) }}>
                                            <View style={{
                                                backgroundColor: color,
                                                height: 50,
                                                width: 50,
                                                color: "#000",
                                                borderRadius: 35,
                                                //marginStart: 10,
                                                marginTop: 12,
                                                //marginBottom: 3, 
                                            }}>
                                                <Icon name={icon} style={styles.icons} />
                                            </View>
                                        </TouchableOpacity>

                                        <Mytextinput
                                            placeholder="Account name"
                                            onChangeText={(value) => { setAccountName(value) }}
                                        />
                                    </View>
                                    <Modal
                                        animationType='slide'
                                        transparent={true}
                                        visible={modalVisible}
                                        onRequestClose={() =>
                                            Alert.alert("modal has closed")}>
                                        <View style={{ backgroundColor: '#0014', }}>
                                            <ScrollView>
                                                <View style={styles.rowItems}>
                                                    {arrChartPalette.map(item => (
                                                        <ColourPickers
                                                            color={item}
                                                            customClick={() => {
                                                                //navigation.navigate('AddAccount')
                                                                // 'thumb-up'
                                                                setColor(item);
                                                                setIcon("thumb-up");
                                                                setModalVisible(!modalVisible);
                                                            }}
                                                        />
                                                    ))}
                                                </View>
                                            </ScrollView>
                                            <Button style={{ marginTop: 20 }} title="Cancel" onPress={() => { setModalVisible(!modalVisible) }} />
                                        </View>

                                    </Modal>
                                    <View style={{ alignContent: 'center', justifyContent: "center", marginLeft: 60 }}>
                                        <Mytextinput
                                            placeholder="Initial Balance"
                                            onChangeText={(value) => { setInitialBal(Number(value)) }}
                                            keyboardType={'numeric'}
                                        />
                                    </View>
                                </ScrollView>
                                <Button style={{ height: 30, fontSize: 30 }}
                                    title="Save"
                                    onPress={() => {
                                         submit();
                                        navigation.goBack() 
                                    }} />
                            </View>
                        );
                    }
                }
            </Mutation>
        </View>
    );
    //}
}

const styles = StyleSheet.create({
    flex: {
        flex: 1
    },
    MainContainer: {
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 20,
        justifyContent: 'center',
        alignSelf: 'center',
    },
    rowItems: {
        flex: 1,
        flexWrap: 'wrap',
        alignItems: 'flex-start',
        flexDirection: 'row',
        marginLeft: 12,
    },
    rowItem: {
        //flexWrap: 'wrap',
        //alignItems: 'flex-start',
        flexDirection: 'row',
        marginLeft: 12,
    },

    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 10,
        marginTop: 8,
    },


});

