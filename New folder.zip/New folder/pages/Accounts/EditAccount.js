import React, { useState, useEffect, useContext } from 'react';
import {
    SafeAreaView, TouchableOpacity,
    Button,
    ScrollView,
    StyleSheet,
    View,
} from 'react-native';
import {Text} from 'react-native-paper';
import Icon from '@expo/vector-icons/MaterialCommunityIcons';
import ColourPickers from '../../components/ColourPickers';
import Modal from 'react-native-modal';
import chartPalette from '../../assets/colors';
import Mytextinput from '../../components/MyTextInput';
import { UserContext } from '../../App';
import SaveButton from '../../components/SaveButton';
import gql from 'graphql-tag';
import { Mutation } from 'react-apollo';

const UPDATE_ACCOUNT = gql`
  mutation ($id: Int!, $orgID: String!, $userId: String!, 
    $accountName: String!, $color: String, $initialBal: numeric,
    $deptID: String!){
    update_accounts (
      _set: {
        name: $accountName,
        createdBY: $userId,
        color: $color,
        orgID: $orgID,
        dept: $deptID,
        initialBalance: $initialBal,
      },
      where: {
        id: {
          _eq: $id
        }
      }
    ){
      returning {
        id
              }
    }
  }
`;

const arrChartPalette = Object.values(chartPalette);

EditAccount.navigationOptions = {
    title: 'Edit Account',
};
//export default class App extends React.Component {

export default function EditAccount({route, navigation }) {
    const { itemEdit }= route.params;

    
    var [show, setShow] = useState(false);
    const User_context = React.useContext(UserContext);
    const orgID = User_context.org_id;
    const userId = User_context.userId;
    const deptID = User_context.dept_id;
    const [modalVisible, setModalVisible] = useState(false);
    var [accountName, setAccountName] = useState(null);
    var [color, setColor] = useState(null);
    var [icon, setIcon] = useState("refresh");
    var [initialBal, setInitialBal] = useState(0);
    const [createdAT, setCreatedAT] = useState(null);
    let id = itemEdit.id;

    return (
        <View style={styles.container}>
            {/*  <Header titleText="Add Category" /> */}
            <Mutation
                mutation={UPDATE_ACCOUNT}
                variables={{
                    id,
                    accountName,
                    color,
                    userId,
                    orgID,
                    deptID,
                    initialBal,
                }}

            >
                {
                    (updateAccount, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text> Error </Text>;
                            }
                            if (loading || accountName === '') {
                                return;
                            }
                         //  console.log(" my id " + typeof userId + " " + userId);
                         //   console.log(" dept id " + typeof deptID + " " + deptID);
                         //   console.log(" org id " + typeof orgID + " " + orgID);
                         //   console.log(" my color " + typeof color + " " + color);
                         //   console.log(" tim stamp " + typeof initialBal + " " + initialBal);
                         //   console.log(" tim stamp " + typeof deptID + " " + deptID);
                            console.log(" tim stamp " + accountName + " ");
                            console.log(" tim stamp " + color + " ");
                            console.log(" tim stamp " + initialBal + " ");

                            //setText('');

                            updateAccount();
                            alert('updated successfully')
                            setAccountName("");
                            setColor("");
                            setInitialBal("");

                        }

                        return (
                            <View style={styles.MainContainer}>
                                <ScrollView>
                                    { color?
                                        <View style={styles.rowItem}>
                                        <TouchableOpacity
                                            onPress={() => { setModalVisible(true) }}>
                                            <View style={{
                                                backgroundColor: color,
                                                height: 50,
                                                width: 50,
                                                color: "#000",
                                                borderRadius: 35,
                                                //marginStart: 10,
                                                marginTop: 12,
                                                //marginBottom: 3, 
                                            }}>
                                                <Icon name={icon} style={styles.icons} />
                                            </View>
                                        </TouchableOpacity>

                                        <Mytextinput
                                            placeholder="Account name"
                                            onChangeText={(text) => { setAccountName(text) }}
                                            defaultValue={itemEdit.name}
                                        />
                                    </View>
                                    :
                                        <View style={styles.rowItem}>
                                            <TouchableOpacity
                                                onPress={() => { setModalVisible(true) }}>
                                                <View style={{
                                                    backgroundColor: itemEdit.color,
                                                    height: 50,
                                                    width: 50,
                                                    color: "#000",
                                                    borderRadius: 35,
                                                    //marginStart: 10,
                                                    marginTop: 12,
                                                    //marginBottom: 3, 
                                                }}>
                                                    <Icon name={icon} style={styles.icons} />
                                                </View>
                                            </TouchableOpacity>

                                            <Mytextinput
                                                placeholder="Account name"
                                                onChangeText={(text) => { setAccountName(text) }}
                                                defaultValue={itemEdit.name}
                                            />
                                        </View>
                                    }
                                    <Modal
                                        animationType='slide'
                                        transparent={true}
                                        visible={modalVisible}>
                                        <View style={{ backgroundColor: '#0014', }}>
                                            <ScrollView>
                                                <View style={styles.rowItems}>
                                                    {arrChartPalette.map(item => (
                                                        <ColourPickers
                                                            color={item}
                                                            customClick={() => {
                                                                //navigation.navigate('AddAccount')
                                                                // 'thumb-up'
                                                                setColor(item);
                                                                setIcon("thumb-up");
                                                                setModalVisible(!modalVisible);
                                                            }}
                                                        />
                                                    ))}
                                                </View>
                                            </ScrollView>
                                            <Button style={{ marginTop: 20 }} title="Cancel" onPress={() => { setModalVisible(!modalVisible) }} />
                                        </View>

                                    </Modal>
                                    <View style={{ alignContent: 'center', justifyContent: "center", marginLeft: 60 }}>
                                        <Mytextinput
                                            placeholder="Initial Balance"
                                            onChangeText={(text) => { setInitialBal(Number(text)) }}
                                            keyboardType={'numeric'}
                                            defaultValue={String(itemEdit.initialBalance)}
                                        />
                                    </View>
                                </ScrollView>
                                <View style={{ marginTop: 20, marginBottom: 20, flexDirection: 'row' }}>

                                    <View paddingHorizontal={5} />
                                    {show ? <SaveButton
                                        title="CONFIRM"
                                        style={{ width: 100, backgroundColor: 'green', }}
                                        customClick={() => {
                                            submit();
                                            navigation.goBack();
                                            setShow(false);
                                        }}
                                    /> : <SaveButton
                                            style={{ width: 100, }}
                                            title="UPDATE"
                                            customClick={() => {
                                                accountName ? accountName : setAccountName(itemEdit.name);
                                                initialBal ? initialBal : setInitialBal(itemEdit.initialBalance);
                                                color ? color : setColor(itemEdit.color);
                                                setShow(true);
                                                //submit();
                                            }}
                                        />}

                                    <View paddingRight={30} />
                                    <SaveButton
                                        title="Delete"
                                        onPress={() => { del() }} />
                                </View>
                            </View>
                        );
                    }
                }
            </Mutation>
        </View>
    );
    //}
}

const styles = StyleSheet.create({
    flex: {
        flex: 1
    },
    MainContainer: {
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 20,
        justifyContent: 'center',
        alignSelf: 'center',
    },
    rowItems: {
        flex: 1,
        flexWrap: 'wrap',
        alignItems: 'flex-start',
        flexDirection: 'row',
        marginLeft: 12,
    },
    rowItem: {
        //flexWrap: 'wrap',
        //alignItems: 'flex-start',
        flexDirection: 'row',
        marginLeft: 12,
    },

    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 10,
        marginTop: 8,
    },


});

