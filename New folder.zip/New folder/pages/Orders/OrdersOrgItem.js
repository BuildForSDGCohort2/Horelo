/*jshint -W033 */
import React, { useState, useEffect, useContext } from 'react';
import { ActivityIndicator, StyleSheet, View, Image,TextInput, FlatList, TouchableOpacity, Dimensions, Button } from 'react-native';
import ApolloClient from 'apollo-boost';
import {Text} from 'react-native-paper';
import MyTextInput from '../../components/MultiLineTextInput';
import gql from 'graphql-tag';
import { Query } from 'react-apollo';
import { UserContext } from '../../App';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import * as Font from 'expo-font';
import MyButton from '../../components/MyButtons';
import { set } from 'ramda';
import Autocomplete from 'react-native-autocomplete-input';
import CartItem from '../../components/CartItem';
import InputSpinner from "react-native-input-spinner";
import AsyncStorage from '@react-native-community/async-storage';
import Icon from 'react-native-vector-icons/Ionicons';
import { ScrollView } from 'react-native-gesture-handler';


const FETCH_ORDERS = gql`
query order_view($trans_id: String!, $orgid: String!, $userid: String!){
  order_view (where: {trans_id:{_eq:$trans_id}, orgid:{_eq:$orgid}, userid:{_eq:$userid}}){
    orgid
    userid
    image
    amount
    items
    pdt_name
    trans_id
    phone
    comment
    createdat
    completed
    ready
    org_phone
    org_name
  }
}
`

export default function OrdersOrgItem({route, navigation }) {
    let trans = [];
    const user_context = useContext(UserContext);
    const [dataCart, setDataCart] = React.useState([]);
    const {order} = route.params;
    const trans_id = order.trans_id;
    const orgid = user_context.org_id;
    const userid = order.userid;
    

  
   
    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: 'Order Details',
           
         });
    }, [navigation]);
  
    return (
        <View style={[{flex:1},styles.container]}>
        <ScrollView>

            <Query query={FETCH_ORDERS} variables={{
              trans_id, orgid, userid
            }} fetchPolicy='cache-and-network'>
                {({ loading, error, data }) => {
                    if (loading) return <View styles={styles.activity}>
                        <ActivityIndicator size="large" color="#000ff" />
                    </View>
                    if (error) return <View>{console.log("my error gql " + error)}
                        <Text>Data loading error ${error.message} </Text>
                       
                    </View>
               return(     

               data.order_view.map((obj,i)=>{
                return(

                   <View style={{width:vw-20,margin:5,backgroundColor:'transparent', flexDirection:'row', borderBottomWidth:2, borderColor:"#cccccc", paddingBottom:10}}
                  
                   >
                     <Image resizeMode={"contain"} style={{width:vw/3,height:vw/3, borderRadius:35}} source={{uri: obj.image}} />
                     <View style={{flex:1, backgroundColor:'trangraysparent', padding:10, justifyContent:"space-between"}}>
                       <View>
                         <View style={{flexDirection:'row'}}>
                 <Text style={{fontWeight:"bold", fontSize:20}}>{obj.pdt_name}</Text></View>
                         <Text>{obj.comment}</Text>
                               
                       </View>
                       <View style={{flexDirection:'row',justifyContent:'space-between', alignItems:"center"}}  >
                         <Text style={{fontWeight:'bold',color:"#33c37d",fontSize:20}}>{(obj.amount * obj.items).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</Text>
                         <InputSpinner
                                    style={{marginLeft: vw/50,
                                        //marginRight: vw/20,
                                       }}
                                                max={1000}
                                                min={1}
                                                step={1}
                                                type={'float'}
                                                colorMax={"#f04048"}
                                                colorMin={"#40c5f4"}
                                                color={"#9777"}
                                                value={obj.items}
                                                rounded={false}
                                                arrows={false}
                                                height={vw/10}
                                                width={100}
                                                onChange={(num) => {
                                                   //setQuantity(num);
                                                }}
                                            />
                         
                       </View>

                       <View style={{flexDirection:'row-reverse',justifyContent:'space-between'}}  >
                       <Text style={{ fontWeight:'bold', fontSize:14}}>{obj.org_name}</Text>
                       <TouchableOpacity onPress={()=>{}} style={{ backgroundColor:"pink"}}>
                       <Text style={{ fontWeight:'bold', fontSize:14}}>{obj.org_phone}</Text>
                       </TouchableOpacity>
                       </View>
                     </View>
                   </View>
                   

                ) 
               }))
             }
                           
                }
            </Query>
</ScrollView>
        </View>


    );  
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
    autocompleteContainer: {
        flex: 1,
        left: 15,
        position: 'absolute',
        right: 0,
        top: 0,
        zIndex: 1, width: 300
    },
    container: {
        height: vh,
        width: vw,
        backgroundColor: '#fdfdfd'
    },
    header: {
        width: vw,
        height: vw / 3.6,
        resizeMode: 'stretch'
    },
    title: {
        fontFamily: 'ValidityScriptBI',
        fontSize: vw / 22,
        color: '#252525'
    },
    subtitle: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b'
    },
    list: {
        margin: vw / 40
    },
    block: {
        //flex: 1,
        height: vh / 10,
        margin: vw / 10
    },
    productImage: {
        width: '100%',
        //height: '50%',
        height: vh / 20,
        resizeMode: 'contain',
        backgroundColor: '#ffffff'
    },
    name: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#252525',
        width: '80%',
        marginTop: 2
    },
    price: {
        fontFamily: 'maven-pro-bold',
        fontSize: vw / 22,
        color: '#bf200b',
        marginTop: 2,
    }, 
   /*  viewStyle: {
        justifyContent: 'center',
        flex: 1,
        marginTop: 40,
        padding: 16,
    }, */
    textStyle: {
        padding: 5,
    },
    textInputStyle: {
        height: 40,
        borderWidth: 1,
        paddingLeft: 5,
        borderColor: '#009688',
        backgroundColor: '#FFFFFF',
    },
});
