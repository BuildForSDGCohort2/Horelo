//This is an example code for NavigationDrawer//
import React, { Component, useState, useEffect } from 'react';
//import react in our code.
import { Alert, ActivityIndicator, Button, Image, ScrollView, StyleSheet, View,  FlatList, TouchableOpacity, TouchableHighlight } from 'react-native';
// import all basic components
import * as R from 'ramda';
import AsyncStorage from '@react-native-community/async-storage';
import {Text} from 'react-native-paper';
import createApolloClient from '../apollo';
import MyOrderButton from '../../components/MyOrderButton';
import { UserContext } from '../../App';
import MyButton from '../../components/MyButtons';
import { Query, Mutation } from 'react-apollo';
//import gql from 'graphql-tag';
import {gql, useMutation} from '@apollo/client';
import Modal from 'react-native-modal';
import moment from 'moment';


const GET_USER_ORDERS = gql`
query org_order_view($orgid: String){
  org_order_view(where:{orgid:{_eq:$orgid}},order_by:{name: desc})
      {
    seen
    servedat
    completed
    userid
    ready
    name
    trans_id
    avatar
    phone
    sum
    count
  }
}`;

const AllOrders = ({ navigation }) => {
  React.useLayoutEffect(() => {
    navigation.setOptions({ 
        title: 'All Orders',
         });
}, [navigation]);

    const user_context = React.useContext(UserContext);
    const servedby = user_context.userId;
    const [servedat, setServedat] = useState(null);
    const [ready, setReady] = useState(false);
    const [seen, setSeen] = useState(false);
    const [trans_id, setTrans_id] = useState(null);
    const [userid, setUserid] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const orgid = user_context.org_id;
    const [reload, setReload] = useState(false);
    const [colorServed, setColorServed] = useState('white');
    var id;
React.useEffect(()=>{
  //setReload(false);
  user_context.setUserId(servedby);
},[reload]);
    const client = createApolloClient(user_context.token);

    const readyOrder = async () => {
      await client.mutate({
          mutation: gql`
      mutation ($ready: Boolean!, $orgid: String!, 
        $trans_id: String!, $userid: String!){
          update_orders (
          _set: {  ready: $ready,
            },
         where:{
             OrgID: {
                 _eq: $orgid
              },
              UserID:{
                _eq: $userid
              },
              _and: {trans_id: {_eq: $trans_id}}
          }

        ) {
          affected_rows
          returning{
              id
          }
        }
      }
    `  ,
          variables: {
            orgid,
            ready,
            trans_id, userid
          }
      }).then(console.log);
      /* }).then((result) => {
          console.log("graphql response", result);
          return result.data;
      }).catch((error) => {
          console.log("Graphql query error", error);

          let err = error;
          if (error.graphQlErrors && error.graphQlErrors.length > 0)
              err = error.graphQlErrors[0];
          throw err;
      }); */
      alert("Order Is now Ready for Deleivery");
      setReload(!reload);
  };
  const servedOrder = async () => {
    await client.mutate({
        mutation: gql`
    mutation ($servedat: timestamptz, $servedby: String!, $orgid: String!, 
      $trans_id: String!, $userid: String!){
        update_orders (
        _set: { 
          servedby: $servedby,
          servedat: $servedat,
        },
       where:{
           OrgID: {
               _eq: $orgid
            },
            UserID:{
              _eq: $userid
            },
            _and: {trans_id: {_eq: $trans_id}}
        }

      ) {
        affected_rows
        returning{
            id
        }
      }
    }
  `  ,
        variables: {
          orgid,
          trans_id, userid,
          servedby, servedat
        }
    }).then(console.log);
    /* }).then((result) => {
        console.log("graphql response", result);
        return result.data;
    }).catch((error) => {
        console.log("Graphql query error", error);

        let err = error;
        if (error.graphQlErrors && error.graphQlErrors.length > 0)
            err = error.graphQlErrors[0];
        throw err;
    }); */
    alert("Order has been Delivered Successfully");
      setReload(!reload);
};
const seenOrder = async () => {
  await client.mutate({
      mutation: gql`
  mutation ($seen: Boolean!, $orgid: String!, 
    $trans_id: String!, $userid: String!){
      update_orders (
      _set: { seen: $seen},
     where:{
         OrgID: {
             _eq: $orgid
          },
          UserID:{
            _eq: $userid
          },
          _and: {trans_id: {_eq: $trans_id}}
      }

    ) {
      affected_rows
      returning{
          id
      }
    }
  }
`  ,
      variables: {
        orgid,
        seen,
        trans_id, userid
      }
  }).then(console.log);
  /* }).then((result) => {
      console.log("graphql response", result);
      return result.data;
  }).catch((error) => {
      console.log("Graphql query error", error);

      let err = error;
      if (error.graphQlErrors && error.graphQlErrors.length > 0)
          err = error.graphQlErrors[0];
      throw err;
  }); */
  alert("Order is marked Seen Successfully");
  setReload(!reload);
};
    
    function  compFalse(){
      Alert.alert(
        'Order Not Deliverd?',
        "Press Not if not delivered",
        [
          {
            text: 'not',
            onPress:()=>{setCompleted(false); deliveredOrder();setReload(!reload);}
          },
          {
            text: 'Cancel',
            onPress:()=>{}
          }
        ],
       
      )
    }
function  compTrue(){
  Alert.alert(
    'Order Deliverd?',
    "Press OHK if delivered",
    [
      {
        text: 'ohk',
        onPress:()=>{
          console.log(trans_id+" o "+ orgid+" c "+ completed+ " u "+ userid)
          setCompleted(true);
          deliveredOrder();setReload(!reload);}
      },
      {
        text: 'Cancel',
        onPress:()=>{}
      }
    ]
  )
}
function getCurrentLocalDateTime(){
  return moment().format('YYYY-MM-DD hh:mm:ss A');
}
function getCurrentUTCDateTime(){
  return moment.utc().format('YYYY-MM-DD hh:mm:ss A');
}
    //  render() {
    return (<View style={styles.MainContainer}>
        
            <Query query={GET_USER_ORDERS} variables={{orgid}} fetchPolicy='cache-and-network'>
                {({ loading, error, data, refetch }) => {
                    if (loading) return <View styles={styles.activity}>
                        <ActivityIndicator size="large" color="#000ff" />
                    </View>
                    if (error) return <View style={{ marginLeft:10,}}>{console.log("my error gql " + error)}
                        <Text>Data loading error ${error.message} </Text></View>
                    return (
                        <View>
                            <Text>ALl Orders</Text>
                            <View>
                            <FlatList
                                  extraData={data.org_order_view} 
                                    data={data.org_order_view}
                                    horizontal={true}
                                   //numColumns={2}
                                renderItem={({ item, index }) =>
                                    <View style={{ marginLeft:10, height:199,
                                        backgroundColor: index % 2 == 0 ? "#5d4c4f" : "#bababa"
                                    }} {...item}>
                                        <MyOrderButton {...item}
                                            logo={item.avatar}
                                            title={item.name}
                                            items={item.count}
                                            total={(item.sum).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                                            status={item.ready}
                                            colorReady={item.ready ? "green":"pink"}
                                            colorSeen={item.seen ? "blue":'#456'}
                                            customClick={() => { navigation.navigate('OrdersOrgItem',{order:item}) }}
                                          
                                        />
                                        
                                    </View>
                                }
                                ItemSeparatorComponent={()=><View paddingHorizontal={7}/>}
                                keyExtractor={item => item.toString()}
                                refreshing={isLoading}
                  onRefresh={() => { refetch() }}
                            />
</View>
                                 </View>
                    );
                }
                }
            </Query>
    </View>
    );
    // }
}

const styles = StyleSheet.create({
    activity: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
   
    MainContainer: {
        flex: 1,
        paddingHorizontal: 5,
        padding: 10,
       
    },
   
    
});
export default AllOrders;
