import React, { useState, useEffect } from 'react';
import {
    KeyboardAvoidingView, SafeAreaView, TouchableOpacity, TouchableWithoutFeedbackBase,
    Button,
    FlatList,
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    TouchableWithoutFeedback,
    View, Keyboard, Dimensions
} from 'react-native';
import {Text} from 'react-native-paper';
import Modal from 'react-native-modal';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import SaveButton from '../../components/SaveButton';
import { UserContext } from '../../App';

import Ionicons from '@expo/vector-icons/Ionicons';
import Icon from '@expo/vector-icons/FontAwesome5';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { industryCategory, industries } from '../../assets/industries';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';

const GET_ProductCategories = gql` 
query product_categories($org_id: String!, $dept_id: String!){
  product_categories(distinct_on: name, order_by: {name: asc}) {
    name
    id
  }}`;

const INSERT_ORGANIZATION = gql`
  mutation ($companyName: String, $userId: String,$admin1: String,
    $admin2: String!, $companyEmail: String!,$location: String,
    $industry: Int!, $phone:String! $logo: String){
    insert_organizations (
      objects: [{
        name: $companyName,
        createdBY: $userId,
        admin1: $admin1,
        admin2: $admin2,
        email: $companyEmail,
        location: $location,
        cat_id: $industry,
        phone: $phone,
      }]
    ){
      affected_rows
    }
  }
`;

AddCompany.navigationOptions = {
    title: 'Add Company',
};
//export default class App extends React.Component {
export default function AddCompany({navigation}) {
    const user_context = React.useContext(UserContext);

    const [companyName, setCompanyName] = useState('');
    const [location, setLocation] = useState('');
    const [modalVisible, setModalVisible] = useState('');
    const [phone, setPhone] = useState('');
    const [industry, setIndustry] = useState('');
    const [department, setDepartment] = useState('');
    const [logo, setLogo] = useState('');
    const [userId, setUserId] = useState(user_context.userId);
    const [admin1, setAdmin1Email] = useState('');
    const [admin2, setAdmin2Email] = useState('');
    const [userRole, setUserRole] = useState('');
    const [companyEmail, setCompanyEmail] = useState('');


    const numbers = [
        {
            label: '1',
            value: 1,
            color: 'orange',
        },
        {
            label: '2',
            value: 2,
            color: 'green',
        },
    ];
    const User_roles = [
        {
            label: 'Data Entry',
            value: 'data',
        },
        {
            label: 'Department Head',
            value: 'head',
        },
        {
            label: 'Administrator',
            value: 'comp_admin',
        },
    ];

    //render() {



    return (
        <SafeAreaView style={{ flex: 1 }}>
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>

                <ScrollView>
                    {/* <Query query={GET_ProductCategories} fetchPolicy='cache-and-network'>
                        {({ loading, error, data }) => {
                            if (loading || error) return <View><Text>Data loading error Check Internet connectivity</Text></View>
                            return ( */}
                    <Mutation
                        mutation={INSERT_ORGANIZATION}
                        variables={{
                            companyName,
                            userId,
                            admin1,
                            admin2,
                            companyEmail,
                            location,
                            industry,
                            phone,
                            logo,
                        }}
                        
                    >
                        {
                            (insertOrganization, { loading, error }) => {
                                const submit = () => {
                                    if (error) {
                                        return <Text> Error </Text>;
                                    }
                                    if (loading || companyName === '' &&
                                        userId === '' &&
                                        admin1 === '' &&
                                        admin2 === '' &&
                                        companyEmail === '' &&
                                        location === '' &&
                                        industry === '' &&
                                        logo === '') {
                                        return;
                                    }
                                    insertOrganization();
                                    alert("successful");
                                    navigation.goBack();
                                }

                                return (

                                    <View style={styles.MainContainer}>
                                        <View style={{ width: 250, marginLeft: 10 }}>
                                            <Text>Please Select a nature of business </Text>

                                            <RNPickerSelect
                                                placeholder={industries}
                                                items={industryCategory}
                                                onValueChange={(value) => {
                                                    setIndustry(value)
                                                }}
                                                style={{
                                                    ...pickerSelectStyles,
                                                    iconContainer: {
                                                        top: 10,
                                                        right: 12,
                                                    },
                                                }}
                                                value={industry}
                                                useNativeAndroidPickerStyle={false}
                                                textInputProps={{ underlineColor: 'yellow' }}
                                                Icon={() => {
                                                    return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                                                }}
                                            />
                                        </View>

                                        <View paddingVertical={5} />

                                        <Mytextinput
                                            placeholder="Company name"
                                            onChangeText={(value) => { setCompanyName(value) }}
                                        />

                                        <View paddingVertical={5} />

                                        <Mytextinput
                                            placeholder="Company Location"
                                            onChangeText={(value) => { setLocation(value) }}
                                        />
                                        <View paddingVertical={5} />
                                        <Mytextinput
                                            placeholder="Company Email"
                                            onChangeText={(value) => { setCompanyEmail(value) }}
                                        />

                                        <View paddingVertical={5} />
                                        <Mytextinput
                                            placeholder="Company Phone"
                                            onChangeText={(value) => { setPhone(value) }}
                                        />
                                        <View paddingVertical={5} />
                                        <Text>Admin1 email address </Text>
                                        <View style={styles.rowItem}>
                                            <TextInput
                                                placeholder="Admin1's Email Address"
                                                onChangeText={(value) => { setAdmin1Email(value) }}
                                                style={styles.textInput}
                                            />
                                            <TouchableOpacity
                                                style={styles.circle}
                                                onPress={() => { setModalVisible(true) }}>
                                                <Icon name='user-plus' style={styles.icons} />
                                            </TouchableOpacity>
                                        </View>
                                        <View paddingVertical={5} />
                                        <Text>Admin2 email address </Text>

                                        <View style={styles.rowItem}>
                                            <TextInput
                                                placeholder="Admin2's Email Address"
                                                onChangeText={(value) => { setAdmin2Email(value) }}
                                                style={styles.textInput}
                                            />
                                            <TouchableOpacity
                                                style={styles.circle}
                                                onPress={() => { setModalVisible(true) }}>
                                                <Icon name='user-plus' style={styles.icons} />
                                            </TouchableOpacity>
                                        </View>

                                        <View paddingVertical={5} />
                                        <View style={styles.row}>
                                            <SaveButton
                                                title="SAVE"
                                                customClick={() => { submit(); }}
                                            />

                                        </View>
                                    </View>
                                );
                            }
                        }
                    </Mutation>

                    {/*    );
                        }
                        }
                    </Query> */}
                </ScrollView>
            </KeyboardAvoidingView>

        </SafeAreaView>
    );
    //}
}
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({

    MainContainer: {
        flex: 1,
        paddingHorizontal: 20,
        justifyContent: 'flex-end',
        width: 250,
        marginLeft: 10,
        marginTop: 10,
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 3,
    },
    row: {
        marginRight: 3,
        marginBottom: 10,
    },
    textInput: {
        borderRadius: 15,
        marginRight: 3,
        width: 250,
        borderColor: '#000',
        backgroundColor: '#7ed',
        paddingLeft: 10,
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        //  marginRight:4,
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        backgroundColor: '#400f',
        marginTop: 2,
        marginBottom: 3,
    },

});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});