import React from 'react';
import {
    View,
    StyleSheet,
    Animated,
    TouchableOpacity,
} from 'react-native';
import {Text} from 'react-native-paper';
import Swipeable from 'react-native-gesture-handler/Swipeable';
//import { GestureHandler } from 'expo';
//const { Swipeable } = GestureHandler;

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        paddingHorizontal: 10,
        paddingVertical: 20,
        flexDirection: 'row',

    },
    text: {
        color: '#4a4a4a',
        fontSize: 15,
        marginLeft: 10,
    },
    price: {
        color: '#9a4a4a',
        fontSize: 15,
        alignItems: 'flex-end',
        alignContent:'flex-end',
        paddingRight: 30,
    },
    separator: {
        flex: 1,
        height: 1,
        backgroundColor: '#e4e4e4',
        marginLeft: 10,
    },
    leftAction: {
        backgroundColor: '#388e3c',
        justifyContent: 'center',
        flex: 1,
        alignItems: 'flex-start',
    },
    rightAction: {
        // backgroundColor: '#dd2c00',
        justifyContent: 'center',
        // flex: 1,
        alignItems: 'center',
        flexDirection: 'row',

    },
    actionText: {
        color: '#fff',
        fontWeight: '600',
        padding: 20,
    },
});

export const Separator = () => <View style={styles.separator} />;

const LeftActions = (progress, dragX, onPress) => {
    const scale = dragX.interpolate({
        inputRange: [0, 100],
        outputRange: [0, 1.3],
        extrapolate: 'clamp',
    });
    return (
        <View style={styles.leftAction}>
            <TouchableOpacity onPress={onPress}>
                <Animated.Text useNativeDriver={true} style={[styles.actionText, { transform: [{ scale }] }]}>
                    Deleting Item
        </Animated.Text>
            </TouchableOpacity>
        </View>
    );
};

const RightActions = ({ progress, dragX, onPress }) => {
    const scale = dragX.interpolate({
        inputRange: [-100, 0],
        outputRange: [1, 0],
        extrapolate: 'clamp',
    });
    return (

        <View style={styles.rightAction}>
            <TouchableOpacity onPress={onPress}>
                <View style={{ backgroundColor: 'red' }}>
                    <Animated.Text useNativeDriver={true} style={[styles.actionText, { transform: [{ scale }] }]}>
                        Edit
        </Animated.Text>
                </View>
            </TouchableOpacity>
        </View>

    );
};

const ListItem = ({ id, userDept, userRole,userEmail, onSwipeFromLeft, onRightPress }) => (
    <Swipeable
        renderLeftActions={LeftActions}
        onSwipeableLeftOpen={onSwipeFromLeft}
        renderRightActions={(progress, dragX) => (
            <RightActions progress={progress} dragX={dragX} onPress={onRightPress} />
        )}
    >
        <View style={styles.container}>
            <Text style={styles.text}>{id}</Text>
            <Text style={styles.text}>{userDept}</Text>
            <Text style={styles.text}>{userRole}</Text>
            <Text style={styles.price}>{userEmail}</Text>
        </View>
    </Swipeable>
);

export default ListItem;