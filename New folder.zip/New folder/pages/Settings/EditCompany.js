import React, { useState, useEffect } from 'react';
import {
    Alert, KeyboardAvoidingView, SafeAreaView, TouchableOpacity, TouchableWithoutFeedbackBase,
    Button,
    Image,
    FlatList,
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    TouchableWithoutFeedback,
    View, Keyboard, Dimensions
} from 'react-native';
import {Text} from 'react-native-paper';
import Modal from 'react-native-modal';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import SaveButton from '../../components/SaveButton';
import { UserContext } from '../../App';

import Ionicons from '@expo/vector-icons/Ionicons';
import Icon from '@expo/vector-icons/FontAwesome5';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { industryCategory, industries } from '../../assets/industries';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import * as Permissions from 'expo-permissions';

const UPDATE_ORGANIZATION = gql`
  mutation ($org_id: String!, $companyName: String!, $userId: String!,$admin1: String!,
    $admin2: String!, $companyEmail: String!,$location: String!,
    $industry: Int!, $phone:String! $logo: String) {
    update_organizations (
      _set: {
        name: $companyName,
        editedBY: $userId,
        admin1: $admin1,
        admin2: $admin2,
        email: $companyEmail,
        location: $location,
        cat_id: $industry,
        phone: $phone,
        logo: $logo
      },
      where: {
        org_id: {
          _eq: $org_id
        }
      }
    ) {
      returning {
        org_id
        admin1
        admin2
      }
    }
  }
`;

const DELETE_ORGANIZATION = gql`
  mutation ($org_id: String) {
    delete_todos (
      where: {
        org_id: {
          _eq: $org_id
        }
      }
    ) {
      affected_rows
    }
  }
`;

const Settings = ({ navigation, route }) => {
    const isAddButton = null;
    const balance = null;
    const {item} = route.params;

    useEffect(() => {
        getPermissionAsync();

    }, []);
    const user_context = React.useContext(UserContext);
var [show, setShow] = useState(false) ;
    var [companyName, setCompanyName] = useState('');
    
    var [location, setLocation] = useState('');
    var [modalVisible, setModalVisible] = useState(false);
    var [phone, setPhone] = useState('');
    var [industry, setIndustry] = useState('');
    var [logo, setLogo] = useState(null);
    var userId=user_context.userId;
    var [admin1, setAdmin1Email] = useState('');
    var [admin2, setAdmin2Email] = useState('');
    var [companyEmail, setCompanyEmail] = useState('');
    const [avatarBase, setAvatarBase] = useState(null);

    var org_id = item.org_id;
    function logoFrame(value) {
        var res = item.name;
        //res = R.split(" ", 1);
        //res = R.slice(0,3, res);
        return (res);
    }
    const pickImage = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: false,
                base64: true,
                aspect: [4, 3],
                quality: 0.1,
            });
            if (!result.cancelled) {
                setAvatarBase(result.uri);
                setLogo('data:image/jpeg;base64,' + result.base64);
                
            }

            //console.log(result);
        } catch (E) {
            console.log(E);
        }
    };
    
    //  render() {
    return (
        <SafeAreaView style={{ flex: 1 }}>

            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>

                <ScrollView>
                    {/* <Query query={GET_ProductCategories} fetchPolicy='cache-and-network'>
                        {({ loading, error, data }) => {
                            if (loading || error) return <View><Text>Data loading error Check Internet connectivity</Text></View>
                            return ( */}
                    <Mutation
                        mutation={UPDATE_ORGANIZATION}
                        variables={{
                            companyName,
                            userId,
                            admin1,
                            admin2,
                            companyEmail,
                            location,
                            industry,
                            phone,
                            logo,
                            org_id,
                        }}
                    >
                        {
                            (insertOrganization, { loading, error }) => {
                                const submit = () => {
                                   
                                    if (error) {
                                        return <Text> Error </Text>;
                                    }
                                    if (loading || companyName === '' &&
                                        userId === '' &&
                                        admin1 === '' &&
                                        admin2 === '' &&
                                        companyEmail === '' &&
                                        location === '' &&
                                        industry === '' &&
                                        logo === '') {
                                        return;
                                    } 
                                  /* console.log(companyName+" n " +
                                      userId + " n " +
                                      admin1 + " n " +
                                      admin2 + " n " +
                                      companyEmail + " n " +
                                      location + " n " +
                                      industry + " n " +
                                      phone + " n " + org_id + logo)
                                     */
                                   insertOrganization();
alert("edit Successfully")
                                }

                                return (

                                    <View style={styles.MainContainer}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <View>
                                                <Text style={{ color: '#000' }}>Change Logo</Text>
                                                <TouchableOpacity
                                                    style={styles.bigCircle}
                                                    onPress={() => pickImage()}
                                                >
                                                    {
                                                        logo && <Image source={{ uri: logo }} style={{ width: 100, height: 100, borderRadius: 35 }} />
                                                    }
                                                    {logo !== null ? <Image source={{ uri: item.logo }} style={styles.bigCircle} /> :
                                                        <Text style={[styles.logo, { color: '#000' }]}>{logoFrame(item.name)}</Text>
                                                    }
                                                </TouchableOpacity>
                                            </View>
                                            <View style={{ width: 150, marginLeft: 10 }}>
                                                <Text>Select business nature</Text>
                                                <RNPickerSelect
                                                    placeholder={industries}
                                                    items={industryCategory}
                                                    onValueChange={(value) => {
                                                        setIndustry(value)
                                                    }}
                                                    style={{
                                                        ...pickerSelectStyles,
                                                        iconContainer: {
                                                            top: 10,
                                                            right: 12,
                                                        },
                                                    }}
                                                    value={industry ? industry : item.cat_id}
                                                    useNativeAndroidPickerStyle={false}
                                                    textInputProps={{ underlineColor: 'yellow' }}
                                                    Icon={() => {
                                                        return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                                                    }}
                                                />
                                            </View>
                                        </View>
                                        <View paddingVertical={5} />

                                        <Mytextinput
                                            placeholder="Company name"
                                            onChangeText={text => { setCompanyName(text) }}
                                            style={{ padding: 10 }}
                                            defaultValue={item.name}
                                        />

                                        <View paddingVertical={5} />

                                        <Mytextinput
                                            placeholder="Company Location"
                                            defaultValue={item.location}
                                            onChangeText={text => { setLocation(text) }}
                                            style={{ padding: 10 }}
                                        />
                                        <View paddingVertical={5} />
                                        <Mytextinput
                                            placeholder="Company Email"
                                            defaultValue={item.email}
                                            onChangeText={text => { setCompanyEmail(text) }}
                                            style={{ padding: 10 }}
                                        />

                                        <View paddingVertical={5} />
                                        <Mytextinput
                                            placeholder="Company Phone"
                                            defaultValue={item.phone}
                                            onChangeText={text => { setPhone(text) }}
                                            style={{ padding: 10 }}
                                            keyboardType={'numeric'}
                                        />
                                        <View paddingVertical={5} />
                                        <Text>Admin1 email address </Text>
                                        <View style={styles.rowItem}>
                                            <TextInput
                                                placeholder="Admin1's Email Address"
                                                defaultValue={item.admin1}
                                                onChangeText={text => { setAdmin1Email(text) }}
                                                style={styles.textInput}
                                            />
                                            <TouchableOpacity
                                                style={styles.circle}
                                                onPress={() => { setModalVisible(true) }}>
                                                <Icon name='user-plus' style={styles.icons} />
                                            </TouchableOpacity>
                                        </View>
                                        <View paddingVertical={5} />
                                        <Text>Admin2 email address </Text>

                                        <View style={styles.rowItem}>
                                            <TextInput
                                                placeholder="Admin2's Email Address"
                                                defaultValue={item.admin2}
                                                onChangeText={text => { setAdmin2Email(text) }}
                                                style={styles.textInput}
                                            />
                                            <TouchableOpacity
                                                style={styles.circle}
                                                onPress={() => { setModalVisible(true) }}>
                                                <Text> </Text>
                                            </TouchableOpacity>
                                        </View>

                                        <View paddingVertical={5} />
                                        <View style={styles.row}>
                                            
                                            <View paddingHorizontal={5} />
                                            {show ? <SaveButton
                                                title="confirm"
                                                style={{ width: 100, backgroundColor: 'green',}}
                                                customClick={() => {
                                                    submit();
                                                    navigation.goBack();
                                                    setShow(false);
                                                }}
                                            /> : <SaveButton
                                                    style={{ width: 100,  }}
                                                    title="UPDATE"
                                                    customClick={() => {
                                                        companyName ? companyName : setCompanyName(item.name);
                                                        companyEmail ? companyEmail : setCompanyEmail(item.email);
                                                        admin1 ? admin1 : setAdmin1Email(item.admin1);
                                                        admin2 ? admin2 : setAdmin2Email(item.admin2);
                                                        location ? location : setLocation(item.location);
                                                        industry ? industry : setIndustry(item.cat_id);
                                                        phone ? phone : setPhone(item.phone);
                                                        logo ? logo : setLogo(item.logo);
                                                        setShow(true);
                                                        //submit();
                                                    }}
                                                /> }
                                            
                                        </View>
                                    </View>
                                );
                            }
                        }
                    </Mutation>

                    {/*    );
                        }
                        }
                    </Query> */}
                </ScrollView>
            </KeyboardAvoidingView>

        </SafeAreaView>
    );
    // }
}
const createThreeButtonAlert = () =>
    Alert.alert(
        "Alert Title",
        "My Alert Msg",
        [
            {
                text: "Ask me later",
                onPress: () => submit()
            },
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
            },
            { text: "OK", onPress: () => console.log("OK Pressed") }
        ],
        { cancelable: false }
    );
const getPermissionAsync = async () => {
    if (Constants.platform.ios || Constants.platform.android) {
        const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
        if (status !== 'granted') {
            alert('Sorry, we need camera roll permissions to make this work!');
        }
    }
};
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({

    MainContainer: {
        flex: 1,
        paddingHorizontal: 20,
        justifyContent: 'flex-end',
        width: 250,
        marginLeft: 10,
        marginTop: 10,
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 3,
    },
    row: {
        marginRight: 3,
        marginBottom: 10,
    },
    textInput: {
        borderRadius: 15,
        marginRight: 3,
        width: 250,
        borderColor: '#000',
        backgroundColor: '#7ed',
        paddingLeft: 10,
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        //  marginRight:4,
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        backgroundColor: '#400f',
        marginTop: 2,
        marginBottom: 3,
    },
    logo: {
        fontFamily: 'LovingYou',
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },

});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});
export default Settings;