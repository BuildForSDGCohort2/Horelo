import React, { useState, useEffect } from 'react';
import {
    KeyboardAvoidingView, SafeAreaView, TouchableOpacity, TouchableHighlight,
    Button,
    FlatList,
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    TouchableWithoutFeedback,
    View,
} from 'react-native';
import Modal from 'react-native-modal';
import {Text} from 'react-native-paper';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import IonIcons from '@expo/vector-icons/Ionicons';
import Icon from '@expo/vector-icons/FontAwesome5';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
// import RNPickerSelect, { defaultStyles } from './debug';


const department_names = [
    {
        label: 'Department 1',
        value: 'Dept1',
    },
    {
        label: 'Department 2',
        value: 'Dept2',
    },
    {
        label: 'Department 3',
        value: 'Dept3',
    },
];
EditUsers.navigationOptions = {
    title: 'Edit Users',
}
//export default class App extends React.Component {
export default function EditUsers() {
    const [companyName, setCompanyName] = useState(null);
    const [location, setLocation] = useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const [phone, setPhone] = useState(null);
    const [industry, setIndustry] = useState(null);
    const [department, setDepartment] = useState(null);
    const [logo, setLogo] = useState(null);
    const [userEmail, setUserEmail] = useState(null);
    const [userRole, setUserRole] = useState(null);
    const [companyEmail, setCompanyEmail] = useState(null);


    const User_roles = [
        {
            label: 'Data Entry',
            value: 'data',
        },
        {
            label: 'Department Head',
            value: 'head',
        },
        {
            label: 'Administrator',
            value: 'comp_admin',
        },
    ];

    //render() {
    const departments = {
        label: 'Select a department...',
        value: null,
        color: '#9EA0A4',
    };
    const roles = {
        label: 'Select user role...',
        value: null,
        color: '#9EA0A4',
    };
    function departmentSet(value) {
        setDepartment(value);
    }
    function user_role(value) {
        setUserRole(value);
    }
    
    return (
        <View style={styles.MainContainer}>
            <ScrollView
                contentContainerStyle={styles.scrollContentContainer}>
                <Text>Please Select Department of business </Text>
                <View style={{ marginLeft: 5, width: 200 }}>
                    <RNPickerSelect
                        placeholder={departments}
                        items={department_names}
                        onValueChange={(value) => {
                            //setCashflow(value)
                            departmentSet()
                        }}
                        style={{
                            ...pickerSelectStyles,
                            iconContainer: {
                                top: 10,
                                right: 12,
                            },
                        }}
                        value={department}
                        useNativeAndroidPickerStyle={false}
                        textInputProps={{ underlineColor: 'yellow' }}
                        Icon={() => {
                            return <IonIcons name="md-arrow-down" size={24} color="gray" />;
                        }}
                    />
                </View>
                <View paddingVertical={5} />

                <View style={styles.rowItem}>
                    <TextInput
                        placeholder="Users' Email Address"
                        onChangeText={(value) => { setUserEmail(value) }}
                        style={styles.textInput}
                    />
                    <TouchableOpacity
                        style={styles.circle}
                        onPress={() => { setModalVisible(true) }}>
                        <Icon name='user-plus' style={styles.icons} />
                    </TouchableOpacity>
                </View>

                <View paddingVertical={5} />

                <View style={{ marginLeft: 5, width: 200 }}>
                    <RNPickerSelect
                        placeholder={roles}
                        items={User_roles}
                        onValueChange={(value) => {
                            //setCashflow(value)
                            user_role()
                        }}
                        style={{
                            ...pickerSelectStyles,
                            iconContainer: {
                                top: 10,
                                right: 12,
                            },
                        }}
                        value={userRole}
                        useNativeAndroidPickerStyle={false}
                        textInputProps={{ underlineColor: 'yellow' }}
                        Icon={() => {
                            return <IonIcons name="md-arrow-down" size={24} color="gray" />;
                        }}
                    />
                </View>
            </ScrollView>
        </View>
    );
    //}
}

const styles = StyleSheet.create({

    MainContainer: {
        flex: 1,
        marginTop: 3,
        marginBottom: 10,
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 3,
    },
    textInput: {
        borderRadius: 15,
        marginRight: 3,
        width: 250,
        borderColor: '#000',
        backgroundColor: '#7ed'
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        //  marginRight:4,
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        backgroundColor: '#400f',
        marginTop: 2,
        marginBottom: 3,
    },
    scrollContentContainer: {
        flex: 1,
        paddingHorizontal: 15,
        paddingTop: 20,
        paddingBottom: 10,
    },
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});