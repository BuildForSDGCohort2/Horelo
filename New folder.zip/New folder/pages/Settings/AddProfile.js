import React, { useState, useEffect } from 'react';
import {
    KeyboardAvoidingView, SafeAreaView, TouchableOpacity, TouchableHighlight,
    Button,
    FlatList,
   
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    View,
} from 'react-native';
import {Text} from 'react-native-paper';
import Mytextinput from '../../components/MyTextInput';
import Ionicons from '@expo/vector-icons/Ionicons';
import Icon from '@expo/vector-icons/FontAwesome5';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';


const country_code = [
    {
        label: 'Retail',
        value: 'retail',
        code: 'retail',
    },
    {
        label: 'WholeSale',
        value: 'wholesale',
        code: 'wholesale',
    },
];
AddProfile.navigationOptions = {
    title: 'Add User Profile',
};
//export default class App extends React.Component {
export default function AddProfile() {
    const [userName, setUserName] = useState(null);
    const [phone, setPhone] = useState(null);
    const [country, setCountry] = useState(null);
    const [code, setCode] = useState(null);
    const [avatar, setAvatar] = useState(null);
    const [userEmail, setUserEmail] = useState(null);
   

    //render() {
    const countryPlaceHolder = {
        label: 'Select a country...',
        value: null,
        color: '#9EA0A4',
    };
    const codes = {
        label: '+256',
        value: null,
        color: '#9EA0A4',
    };
    function country_info(value) {
        setCountry(value);
        setCode(code);
    }
    
    return (
        <View style={styles.MainContainer}>
            <ScrollView

                contentContainerStyle={styles.scrollContentContainer}>

                <Mytextinput
                    placeholder="User name"
                    onChangeText={() => { setUserName(value) }}
                    style={{ padding: 10 }}
                />

                <View paddingVertical={5} />

                <Mytextinput
                    placeholder="User Email"
                    onChangeText={(value) => { setUserEmail(value) }}
                    style={{ padding: 10 }}
                    keyboardType={Email}
                />

                <View paddingVertical={5} />

                <View style={{ marginLeft: 5, width: 200 }}>
                    <RNPickerSelect
                        placeholder={countryPlaceHolder}
                        items={country_code}
                        onValueChange={(value, code) => {
                            //setCashflow(value)
                            country_info()
                        }}
                        style={{
                            ...pickerSelectStyles,
                            iconContainer: {
                                top: 10,
                                right: 12,
                            },
                        }}
                        value={country}
                        useNativeAndroidPickerStyle={false}
                        textInputProps={{ underlineColor: 'yellow' }}
                        Icon={() => {
                            return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                        }}
                    />
                </View>

                <View paddingVertical={5} />
                <View style={styles.rowItem}>
                    <Text style={{width:80}}>{code}</Text>
                    <Mytextinput
                        placeholder="User Phone"
                        onChangeText={(value) => { setPhone(value) }}
                        style={{ padding: 10 }}
                        keyboardType={Number}
                    />
                </View>
                
                
            </ScrollView>
        </View>
    );
    //}
}

const styles = StyleSheet.create({

    MainContainer: {
        flex: 1,
        marginTop: 3,
        marginBottom: 10,
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 3,
    },
    textInput: {
        borderRadius: 15,
        marginRight: 3,
        width: 250,
        borderColor: '#000',
        backgroundColor: '#7ed'
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        //  marginRight:4,
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        backgroundColor: '#400f',
        marginTop: 2,
        marginBottom: 3,
    },
    scrollContentContainer: {
        flex: 1,
        paddingHorizontal: 15,
        paddingTop: 20,
        paddingBottom: 10,
    },
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});