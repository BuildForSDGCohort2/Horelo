import React, { useState, useEffect } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView, SafeAreaView, TouchableOpacity,
  Button,
  FlatList,
  Image,
  TextInput,
  Platform,
  ScrollView,
  StyleSheet,
  View, Keyboard,
  Dimensions
} from 'react-native';
import {Text} from 'react-native-paper';
import Icon from '@expo/vector-icons/FontAwesome5';
import ListItem, { Separator } from './UserListItem';

// import all basic components
import { UserContext } from '../../App';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';

const ViewUsers = ({route, navigation }) => {

  useEffect(() => {
    const item = route.params.item.org_id;
  }, []);
  const item= route.params.item.org_id;
  const user_context = React.useContext(UserContext);
  const orgID = user_context.org_id;
  const [isLoading, setIsLoading] = useState(false);
  

  navigation.setOptions = {
    title: 'Users',
  };
  
  const FETCH_INVITATIONS = gql` 
query invitations($item: String!){
  invitations(where: {org_id: {_eq: $item}}){
    id
    user
    org_id
    accepted
    department
    role
  }
  
}`;
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>
          <View style={styles.MainContainer}>
            <View paddingVertical={5} />
            <Query query={FETCH_INVITATIONS} variables={{item}} fetchPolicy='cache-and-network'>
              {({ loading, error, data, refetch }) => {
                if (loading) return <View styles={styles.activity}>
                  <ActivityIndicator size="large" color="#000ff" /></View>

                if (error) return <View>{console.log("my error gql " + error)}
                  <Text>Data loading error ${error.message}</Text></View>

                return (
                <View style= {{ flex: 1 }
            }>
                  <Text>Users List</Text>

                  <FlatList
                    data={data.invitations}
                    keyExtractor={item => item.id}
                    renderItem={({ item }) => (
                      <ListItem
                        {...item}
                        onSwipeFromLeft={() => {}}
                        onSwipeFromLeft={() => {}}

                      />
                    )}
                    ItemSeparatorComponent={() => <Separator />
                    }
                    refreshing={isLoading}
                  onRefresh={() => { refetch() }}
                  />
                  </View>
                );
              }
              }
            </Query>
          </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
  activity: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  MainContainer: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'flex-end',
    marginLeft: 10,
    marginTop: 10,
  },
  rowItem: {
    flexDirection: 'row',
    marginLeft: 5,
    marginRight: 3,
  },
  row: {
    marginRight: 3,
    marginBottom: 10,
  },
  textInput: {
    borderRadius: 15,
    marginRight: 3,
    width: 250,
    height: 50,
    borderColor: '#000',
    backgroundColor: '#7ed',
    paddingLeft: 10,
  },
  bigCircle: {
    height: 90,
    width: 90,
    borderRadius: 50,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  circle: {
    height: 50,
    width: 50,
    borderRadius: 35,
    backgroundColor: '#000',
    alignItems: 'center',
    //  marginRight:4,
  },
  icons: {
    fontSize: 30,
    fontFamily: 'ValidityScriptBI',
    color: 'white',
    marginLeft: 3,
    marginTop: 10,
    backgroundColor: '#000',
    borderRadius: 35,
    height: 40,
    width: 40,
  },
  text: {
    color: 'brown',
    fontSize: 20,
    fontFamily: 'YellowRabbit',
  },

  logo: {
    fontFamily: 'LovingYou',
    fontSize: 30,
    color: 'white',
    marginLeft: 3,
    marginTop: 10,
  },


});


export default ViewUsers;