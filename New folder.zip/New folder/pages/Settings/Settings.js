//This is an example code for NavigationDrawer//
import React, { Component, useState, useEffect } from 'react';
//import react in our code.
import { Alert, ActivityIndicator, Button, Image, ScrollView, StyleSheet, View,  FlatList, TouchableOpacity, TouchableHighlight } from 'react-native';
// import all basic components
import * as R from 'ramda';
import AsyncStorage from '@react-native-community/async-storage';
import {Text} from 'react-native-paper';
import createApolloClient from '../apollo';
import OrganizationItem from '../../components/OrganizationItem';
import WorkItem from '../../components/WorkItem';
import InvitationItem from '../../components/InvitationItem';
import { UserContext } from '../../App';
import MyButton from '../../components/MyButtons';
import { Query, Mutation } from 'react-apollo';
import gql from 'graphql-tag';
import Modal from 'react-native-modal';


const GET_Organizations = gql`
query organizations($email: String!){
  organizations(order_by:{createdAT: desc})
      {
    id
    org_id
    name
    createdBY
    admin1
    admin2
    logo
    product_category{
        name
    }
    email
    location
    cat_id
    phone
  }
invitations(where: {user: {_eq: $email}},order_by:{createdAT: desc})
      {
           id
    org_id
     accepted
    active
    alias
    createdAT
    department
    organization {
      name
      logo
    }
    role
    user
  }
  
}`;
const GET_Invitations = gql`
query invitations($email: String ){
  
invitations(where: {user: {_eq: $email}},order_by:{createdAT: desc})
      {
          id
          org_id
    accepted
    active
    alias
    createdAT
    department
    organization {
      name
      logo
    }
    role
    user
  }
}`;

const Settings = ({ navigation }) => {

    
    const user_context = React.useContext(UserContext);
    const [userId, setUserId] = useState(user_context.userId);
    const [reload, setReload] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    var id;
    var alias, orgID,
        role,
        dept;

    const email = user_context.email;
    const auth0_id = user_context.userId;
    const [modalVisible, setModalVisible] = useState(false);
    var accepted;
    var active;
    useEffect(() => {


    }, [reload]);
    const [name, setName] = useState("");
    let invites;

    const client = createApolloClient(user_context.token);

    const declineOffer = async () => {

        console.log(id + " declineOffer " + alias + "n" +
            accepted + "n" + active);
        await client.mutate({
            mutation: gql`
        mutation ($active: Boolean, $id: Int, $alias: String){
          update_invitations (
            _set: { active: $active},
           where:{
               id: {
                   _eq: $id
                },_and: {alias: {_eq: $alias}}
            }
          ) {
            affected_rows
            returning{
                id
                accepted
            }
          }
        }
      `   ,
            variables: {
                id: id,
                accepted: accepted,
                alias: alias
            }
        });

    };
    const setDefaults = async () => {
        user_context.setOrg_id(orgID);
        user_context.setDept_id(dept);
        user_context.setRole(role);

        await client.mutate({
            mutation: gql`
        mutation ($orgID: String, $role: String, $dept: String, $auth0_id:String, $email:String ){
          update_users (
            _set: { org_id: $orgID, role: $role, dept:$dept},
           where:{
               auth0_id: {
                   _eq: $auth0_id
                },_and: {email: {_eq: $email}}
            }
          ) {
            affected_rows
            returning{
                org_id
                dept
                role
            }
          }
        }
      `   ,
            variables: {
                orgID: orgID,
                role: role,
                dept: dept,
                auth0_id: auth0_id,
                email: email
            }
        });
        AsyncStorage.setItem(
            'CurrentProfile',
            //JSON.stringify(decodedToken)
            JSON.stringify({
                orgID: orgID,
                deptID: dept,
                role: role,
            })
        ).then(() => {
            alert('Default Profile Set');
        });
    };

    const acceptOffer = async () => {
       
        await client.mutate({
            mutation: gql`
        mutation ($accepted: Boolean, $id: Int, $alias: String){
          update_invitations (
            _set: { accepted: $accepted},
           where:{
               id: {
                   _eq: $id
                },_and: {alias: {_eq: $alias}}
            }

          ) {
            affected_rows
            returning{
                id
                accepted
            }
          }
        }
      `  ,
            variables: {
                id: id,
                accepted: accepted,
                alias: alias
            }
        }).then(console.log);
        /* }).then((result) => {
            console.log("graphql response", result);
            return result.data;
        }).catch((error) => {
            console.log("Graphql query error", error);

            let err = error;
            if (error.graphQlErrors && error.graphQlErrors.length > 0)
                err = error.graphQlErrors[0];
            throw err;
        }); */
setReload(!reload);
    };

    const deleteOffer = async () => {
        await client.mutate({
            mutation: gql`
        mutation ($id: Int, $alias: String){
          delete_invitations (
            where:{
               id: {
                   _eq: $id
                },_and: {alias: {_eq: $alias}}
            }
          ) {
            affected_rows
          }
        }
      `  ,
            variables: {
                id: id,
                alias: alias,
            }          //}).then(console.log);
        }).then((result) => {
            // console.log("graphql response", result);
            return result.data;
        }).catch((error) => {
            console.log("Graphql query error", error);
            let err = error;
            if (error.graphQlErrors && error.graphQlErrors.length > 0)
                err = error.graphQlErrors[0];
            throw err;
        });
        
    };
    function DeclineOffer() {
        declineOffer();
        setReload(!reload);
    }
    function AcceptOffer() {
        acceptOffer();
    }

    //  render() {
    return (<View style={styles.MainContainer}>
        
        <View>
            <Query query={GET_Organizations} 
            
            variables={{ email }} fetchPolicy='cache-and-network'>
                {({ loading, error, data, refetch }) => {
                    if (loading) return <View styles={styles.activity}>
                        <ActivityIndicator size="large" color="#000ff" />
                    </View>
                    if (error) return <View>{console.log("my error gql " + error)}
                        <Text>Data loading error ${error.message} </Text></View>


                    return (
                        <View>
                            <Text>Admin Roles</Text>
                            <FlatList
                                data={data.organizations}
                                horizontal={true}
                                renderItem={({ item, index }) =>
                                    <View style={{
                                        backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#ff8dff"
                                    }}>
                                        <TouchableHighlight
                                            style={styles.icon_button}
                                            underlayColor="#ccc"
                                            onPress={() => { alert("hi here " + item.name); }
                                            }
                                        >
                                            <OrganizationItem {...item}
                                                logo={item.logo}
                                                name={item.location}
                                                title={item.name}
                                                customClick={() => navigation.navigate("ViewCompany", { item: item })}
                                                viewClick={() => navigation.navigate("ViewUsers", { item: item })}
                                                editClick={() => navigation.navigate("EditCompany", { item: item })} />
                                        </TouchableHighlight>

                                    </View>

                                }
                                keyExtractor={item => item.id}
                                refreshing={isLoading}
                  onRefresh={() => { refetch() }}
                            />
                            {/*  {invites = data.invitations.filter((invite) =>
                                                invite.accepted)}
                                            {console.log("invites new")}

                                            {console.log(invites)}
                                            {console.log("invite")}
                                            {console.log(data.invitations.filter((accepted) =>
                                                !!accepted))}
                                            {console.log("invits")}
 */}
                            <Text>User Roles</Text>
                            <FlatList
                                data={data.invitations.filter((accepted) =>
                                    accepted.active === true && accepted.accepted === true)}
                                horizontal={true}
                                renderItem={({ item, index }) =>
                                    <View style={{
                                        backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#ff8dff"
                                    }} {...item}>
                                        <WorkItem {...item}
                                            logo={item.organization.logo}
                                            title={item.organization.name}
                                            name={item.role}
                                            status={item.accepted}
                                            customClick={() => { console.log() }}
                                        />
                                        <View style={{ padding: 5 }}>

                                            <TouchableOpacity
                                                style={[styles.profileView,]}
                                                onPress={() => {
                                                    orgID = item.org_id;
                                                    role = item.role;
                                                    dept = item.department;
                                                    setDefaults()
                                                }}>
                                                <View style={[styles.rowItem]}>
                                                    <Text style={styles.logo}>{(user_context.org_id === item.org_id) ? "Default" : "Set Default"}</Text>
                                                </View>
                                            </TouchableOpacity>
                                            <View style={{ padding: 5 }} />
                                            <TouchableOpacity
                                                style={[styles.profileView, { backgroundColor: '#199' }]}
                                                onPress={() => {
                                                    user_context.setOrg_id(item.org_id);
                                                    user_context.setRole(item.role);
                                                    user_context.setDept_id(item.department);
                                                }}>
                                                <Text style={[styles.logo,]}>{(user_context.org_id === item.org_id) ? "Current" : "Set Current"}</Text>
                                            </TouchableOpacity>
                                        </View>
                                        <View style={[styles.rowItem]}>


                                        </View>

                                    </View>

                                }

                                keyExtractor={item => item.id.toString()}
                                refreshing={isLoading}
                                onRefresh={() => { refetch() }}
                            />
                            <Text>Available Invitations</Text>
                            <FlatList
                                data={data.invitations.filter((accepted) =>
                                    accepted.accepted === false && accepted.active === true)}
                                horizontal={true}
                                renderItem={({ item, index }) =>
                                    <View style={{
                                        backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#ff8dff"
                                    }}>
                                        <InvitationItem {...item}
                                            logo={item.organization.logo}
                                            title={item.organization.name}
                                            name={item.role}
                                            status={item.accepted}
                                            customClick={() => navigation.navigate("WorkCompany")}
                                            declineClick={() => {
                                                id = item.id; alias = item.alias;
                                                active = true; DeclineOffer()
                                            }}
                                            acceptClick={() => {
                                                id = item.id; alias = item.alias;
                                                accepted = true; AcceptOffer()
                                            }}
                                        />

                                    </View>

                                }
                                keyExtractor={item => item.id.toString()}
                                refreshing={isLoading}
                                onRefresh={() => { refetch() }}
                            />
                        </View>
                    );
                }
                }
            </Query>
        </View>

        <View style={styles.rowItem}>
            <Text style={{ fontSize: 14 }}> Add Company </Text>
            <View style={{ marginLeft: 10 }} />

            <MyButton
                title="Add Company "
                customClick={() => navigation.navigate('AddCompany')}
            />
        </View>
   


    </View>
    );
    // }
}

const styles = StyleSheet.create({
    activity: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
    wrapper: {
        height: 280,
        width: 280,
    },
    MainContainer: {
        flex: 1,
        paddingHorizontal: 5,
        padding: 10,
    },
    image: {
        height: 100,
        width: 100,
        color: 'white',
    },
    circle: {
        height: 75,
        width: 75,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    profileView: {
        height: 35,
        borderRadius: 5,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
    },
    sideMenuProfileIcon: {
        resizeMode: 'contain',
        width: 100,
        height: 100,
        margin: 10,
        borderRadius: 100 / 2,
    },
    actionButton: {
        fontSize: 20,
        height: 100,
        width: 100,
        color: 'white',
    },
    rowItems: {
        flexWrap: 'wrap',
        alignItems: 'flex-start',
        flexDirection: 'row',
    },
    rowItem: {
        flexDirection: 'row',
        marginTop: 10,
        marginHorizontal: 10,
    },
    slider: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#97CAE5',
        flexDirection: 'row',
    },
    slide1: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#97CAE5',
        flexDirection: 'row',
    },
    slide2: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#97CAE5',
        flexDirection: 'row',
    },
    slide3: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#92BBD9'
    },
    text: {
        color: '#9f9f',
        fontSize: 11,
        fontWeight: 'bold'
    },
    textItem: {
        marginTop: 25,
        fontWeight: 'bold',
    },
    logo: {
        fontFamily: 'LovingYou',
        fontSize: 30,
        color: 'white',
    },
});
export default Settings;