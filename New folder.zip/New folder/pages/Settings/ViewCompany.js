import React, { useState, useEffect } from 'react';
import {
    KeyboardAvoidingView, SafeAreaView, TouchableOpacity,
    Button,
    FlatList,
    Image,
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    View, Keyboard,
    Dimensions
} from 'react-native';
import {Text} from 'react-native-paper';
import EmptyList from '../../components/EmptyList';
import Icon from '@expo/vector-icons/FontAwesome5';
import Ionicons from '@expo/vector-icons/Ionicons';
import ListItem, { Separator } from './UserListItem';
import MyButtons from '../../components/MyButtons';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import SaveButton from '../../components/SaveButton';
import createApolloClient from '../apollo';
import AsyncStorage from '@react-native-community/async-storage';

import { UserContext } from '../../App';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import * as R from 'ramda';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { rolesPlaceHolder, deptPlaceHolder, user_roles, deptss } from '../../assets/industries';
import { getTS } from '../../assets/getTS';

const INSERT_INVITATIONS = gql`
        mutation ($orgID: String, $userEmail: String!, $alias: String!, 
             $userID: String, $createdBy: String, $userDepartment: String,
            $userRole: String!){
          insert_invitations (
            objects: [{ alias: $alias, org_id: $orgID, user:$userEmail,
            createdBY: $userID, accepted: "false",
            role: $userRole, department: $userDepartment }],
            on_conflict:{
                constraint: invitations_alias_key,
                update_columns:[]
            }

          ) {
            affected_rows
            returning{
                alias 
                org_id
                user
                createdBY 
                accepted
                role 
                department
            }
          }
        }`;


let usersList = [];

const ViewCompany = ({route, navigation }) => {

    const {item} = route.params;
    const user_context = React.useContext(UserContext);
    const client = createApolloClient(user_context.token);

    const [list, setList] = React.useState(usersList);
    const [alias, setAlias] = React.useState('');
    
    const [userID, setUserID] = useState(user_context.userId);
    const [userEmail, setUserEmail] = useState('');
    const [email, setEmail] = useState(user_context.email);
    const [role, setRole] = useState("Admin");
    const [department, setDepartment] = useState("Admin");
    const [userDepartment, setUserDepartment] = useState('');
    const [userRole, setUserRole] = useState('');
    const [userNum, setUserNum] = useState(1);
    const [logo, setLogo] = useState(null);
    
    const orgID = item.org_id;
    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: item.name,
             });
    }, [navigation]);
    /* user_context.setOrg_id(orgID);
    user_context.setDept_id("Admin");
    user_context.setRole("Admin");
    user_context.setLogo(item.logo); */
    function logoFrame(value) {
        var res = item.name;
        //res = R.split(" ", 1);
        //res = R.slice(0,3, res);
        return (res);
    }
    function nameInitials(value) {
        var res = value;
        // res = res.split("", 2);
        return (res);
    }
    const setDefaults = async () => {
        user_context.setOrg_id(item.org_id);
        user_context.setDept_id("Admin");
        user_context.setRole("Admin");

        await client.mutate({
            mutation: gql`
        mutation ($orgID: String, $role: String, $department: String, $userID:String, $email:String ){
          update_users (
            _set: { org_id: $orgID, role: $role, dept:$department},
           where:{
               auth0_id: {
                   _eq: $userID
                },_and: {email: {_eq: $email}}
            }
          ) {
            affected_rows
            returning{
                org_id
                dept
                role
            }
          }
        }
      `   ,
            variables: {
                orgID: orgID,
                role: role,
                department: department,
                userID: userID,
                email: email
            }
        });
        AsyncStorage.setItem(
            'CurrentProfile',
            //JSON.stringify(decodedToken)
            JSON.stringify({
                orgID: item.org_id,
                deptID: "Admin",
                role: "Admin",
            })
        ).then(() => {
            alert('Profile Set');
        });
    };
  return (<SafeAreaView style={{ flex: 1 }}>

    <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>

        <ScrollView>

            <View style={styles.MainContainer}>
                <View style={{ width: 250, marginLeft: 10 }}>
                    {/* <View style={styles.wrapper, { backgroundColor: '#233', height: 500, width: 300 }}>
*/}

                    <View style={styles.rowItem}>
                       
                        <TouchableOpacity
                            style={styles.bigCircle}
                            >
                            {logo !== null ? <Image source={{ uri: logo }} style={styles.bigCircle} /> :
                                <Text style={styles.logo}>{logoFrame(item.name)}</Text>
                            }
                        </TouchableOpacity>
                        <View style={{ marginLeft: 20 }}>
                           
                            <Text style={styles.text}> {item.name}</Text>
                            <Text style={styles.text}> {item.email}</Text>
                            <Text style={styles.text}> {item.phone}</Text>
                              <Text style={styles.text}> {item.product_category.name}</Text> 
                            <Text style={styles.text}> {item.location}</Text>

                        </View>

                    </View>
                    <View style={styles.rowItem}>
                        <Text style={styles.icons}>{nameInitials(item.name)}</Text>
                        <View>
                            <Text style={{ paddingLeft: 15, paddingTop: 13 }}> {item.name}</Text>
                            <Text style={{ paddingLeft: 15, }}> Co-owner</Text>
                        </View>
                    </View>
                     <View style={styles.rowItem}>
                        <Text style={styles.icons}>{nameInitials(item.name)}</Text>
                        <View>
                            <Text style={{ paddingLeft: 15, paddingTop: 13 }}> {item.name}</Text>
                            <Text style={{ paddingLeft: 15, }}> Gen. Manager</Text>
                        </View>
                    </View>
                    <View style={styles.rowItem}>
                        <Text style={styles.icons}>{nameInitials(item.name)}</Text>
                        <View>
                            <Text style={{ paddingLeft: 15, paddingTop: 13 }}> {item.name}</Text>
                            <Text style={{ paddingLeft: 15, }}> co-creator</Text>
                        </View>
                    </View> 
                    {/*  <View style={{ width: 60,margin: 10 }}>
                                                <Button style={{ width: 20, marginTop: 10, }} title="Edit" onPress={() => { setModalVisible(!modalVisible); navigation.navigate('EditCompany', { item: obj }) }} />
                                            </View>  */}
                </View>
                <Mutation
                    mutation={INSERT_INVITATIONS}
                    variables={{
                        alias,
                        orgID,
                        userEmail,
                        userID,
                        userRole,
                        userDepartment,
                    }}
                >
                    {
                        (insertInvitation, { loading, error }) => {
                            const submit = () => {
                                if (error) {
                                    return <Text> Error </Text>;
                                }
                                if (loading || list.emptyList) {
                                    return;
                                }
                                
                              //   list.forEach(function (obj) {
                              //      setAlias(obj.userEmail + "-" + orgID);
                              //      setUserEmail(obj.userEmail);
                              //      setUserRole(obj.userRole);
                              //      console.log(obj.userEmail + "-" + orgID + "-" +
                              //          obj.userDept + "-" + obj.userRole);
                               //     insertInvitation();
                              //  }); 
                                insertInvitation();
                                alert('user added');
                                setUserEmail('');
                                setUserRole('');
                            }
                            return (
                                <View>
                                    <View style={{ width: 200, marginLeft: 10 }}>
                                        <Text>Please </Text>
                                        <View style={styles.rowItem}>
                                            <RNPickerSelect
                                                placeholder={deptPlaceHolder}
                                                items={deptss}
                                                onValueChange={(value) => {
                                                    console.log(value)
                                                    setUserDepartment(value)
                                                }}
                                                style={{
                                                    ...pickerSelectStyles,
                                                    iconContainer: {
                                                        top: 10,
                                                        right: 12,
                                                    },
                                                }}
                                                value={userDepartment}
                                                useNativeAndroidPickerStyle={false}
                                                textInputProps={{ underlineColor: 'yellow' }}
                                                Icon={() => {
                                                    return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                                                }}
                                            />
                                            <View paddingHorizontal={5} />
                                            <RNPickerSelect
                                                placeholder={rolesPlaceHolder}
                                                items={user_roles}
                                                onValueChange={(value) => {
                                                    
                                                    setUserRole(value)
                                                }}
                                                style={{
                                                    ...pickerSelectStyles,
                                                    iconContainer: {
                                                        top: 10,
                                                        right: 12,
                                                    },
                                                }}
                                                value={userRole}
                                                useNativeAndroidPickerStyle={false}
                                                textInputProps={{ underlineColor: 'yellow' }}
                                                Icon={() => {
                                                    return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                                                }}
                                            />
                                        </View>
                                    </View>

                                    <View paddingVertical={5} />
                                    <Text>Add Users</Text>


                                    <View paddingVertical={5} />
                                    <View style={styles.rowItem}>
                                        <TextInput
                                            placeholder="user's Email Address"
                                            onChangeText={(value) => { setUserEmail(value); setAlias(value + "-" + orgID); }}
                                            style={styles.textInput}
                                            value={userEmail}
                                        />
                                        <TouchableOpacity
                                            style={styles.circle}
                                            onPress={() => { submit() }}>
                                            <Icon name='user-plus' style={styles.icons} />
                                        </TouchableOpacity>
                                    </View>
                                    <View paddingVertical={5} />
                                    <View style={styles.rowItem}>
                                    <MyButtons
                                        title="View All Users "
                                            customClick={() => navigation.navigate('ViewUsers', { item: orgID })}
                                    />
                                    <MyButtons
                                        title="Invite User(s) "
                                        customClick={() => submit()}
                                    />
                                    </View>
                                    <MyButtons
                                    style={{backgroundColor:'teal'}}
                                        title="Set As Default "
                                        customClick={() => setDefaults()}
                                    />
                                </View>
                            );
                        }
                    }
                </Mutation> 
            </View>


            {/* <FlatList
                data={list}
                keyExtractor={item => item.id}
                renderItem={({ item }) => (

                    <ListItem
                        {...item}
                        onSwipeFromLeft={() => handleEdit(item.id)}
                        onSwipeFromLeft={() => handleDel(item.id)}

                    //onRightPress={() => alert('swiped from left!')}
                    //onRightPress={(onPress2) => alert('swiped from right!')}
                    //onPress={()=>()}
                    />

                )}

                ItemSeparatorComponent={() => <Separator />
                }
                ListEmptyComponent={<EmptyList containerStyle={{flex:1}} />}
            />
*/}
        </ScrollView>
    </KeyboardAvoidingView>

</SafeAreaView>
);
// }
}
//title of the page

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({

MainContainer: {
flex: 1,
paddingHorizontal: 20,
justifyContent: 'flex-end',
width: 250,
marginLeft: 10,
marginTop: 10,
},
rowItem: {
flexDirection: 'row',
marginLeft: 5,
marginRight: 3,
},
row: {
marginRight: 3,
marginBottom: 10,
},
textInput: {
borderRadius: 15,
marginRight: 3,
width: 250,
height: 50,
borderColor: '#000',
backgroundColor: '#7ed',
paddingLeft: 10,
},
bigCircle: {
height: 90,
width: 90,
borderRadius: 50,
backgroundColor: '#000',
alignItems: 'center',
justifyContent: 'center',
},
circle: {
height: 50,
width: 50,
borderRadius: 35,
backgroundColor: '#000',
alignItems: 'center',
//  marginRight:4,
},
icons: {
fontSize: 30,
fontFamily: 'ValidityScriptBI',
color: 'white',
marginLeft: 3,
marginTop: 10,
backgroundColor: '#000',
borderRadius: 35,
height: 40,
width: 40,
},
text: {
color: 'brown',
fontSize: 20,
fontFamily: 'YellowRabbit',
},

logo: {
fontFamily: 'LovingYou',
fontSize: 30,
color: 'white',
marginLeft: 3,
marginTop: 10,
},


});
const pickerSelectStyles = StyleSheet.create({
inputIOS: {
fontSize: 16,
paddingVertical: 12,
paddingHorizontal: 10,
borderWidth: 1,
borderColor: 'gray',
borderRadius: 4,
color: 'black',
paddingRight: 30, // to ensure the text is never behind the icon
},
inputAndroid: {
fontSize: 16,
paddingHorizontal: 10,
paddingVertical: 8,
borderWidth: 0.5,
borderColor: 'purple',
borderRadius: 8,
color: 'black',
paddingRight: 30, // to ensure the text is never behind the icon
},
});


export default ViewCompany;