//This is an example code for NavigationDrawer//
import React, { Component, useState, useEffect } from 'react';
//import react in our code.
import { ActivityIndicator, StyleSheet, View, FlatList, Image, TouchableHighlight } from 'react-native';
import {Text} from 'react-native-paper';
// import all basic components

import MyButton from '../../components/MyButtons';

const Settings = ({ navigation }) => {
    const isAddButton = null;
    const balance = null;

    useEffect(() => {


    }, []);
    const [loading, setLoading] = useState(true);
    const [articles, setArticles] = useState([]);


    //  render() {
    return (
        <View style={styles.MainContainer}>
            <View style={styles.contentContainer}>

                <Text style={{ fontSize: 23 }}> Screen two </Text>
                <MyButton
                    title="Add Company"
                    customClick={() => navigation.navigate('AddCompany')}
                />

            </View>


        </View>
    );
    // }
}

const styles = StyleSheet.create({
    MainContainer: {
        flex: 1,
        paddingTop: 20,
        alignItems: 'center',
        marginTop: 50,
        justifyContent: 'center',
    },
    image: {
        height: 100,
        width: 100,
        color: 'white',
    },
    actionButton: {
        fontSize: 20,
        height: 100,
        width: 100,
        color: 'white',
    },
    contentContainer: {
        paddingHorizontal: 20,
        paddingVertical: 20
    },
    rowItem: {
        flexDirection: 'row',
    }
});
export default Settings;