import * as AuthSession from "expo-auth-session";
// import {Linking} from 'expo';
import jwtDecode from "jwt-decode";
import React, { useState, useEffect, useContext, createContext } from "react";
import { UserContext } from '../App';
import { ActivityIndicator, Alert, Button, Platform, StyleSheet, Text, View, TextInput, SafeAreaView } from "react-native";
// import * as {WebBrowser} from 'expo-web-browser';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-community/async-storage';
//import { withNavigation } from 'react-navigation';
import createApolloClient from './apollo';
import gql from 'graphql-tag';
import { ApolloProvider as LegacyApolloProvider, Query } from 'react-apollo';
import { toLower } from "ramda";
import {GET_Users} from './Queries';
import Auth0 from 'react-native-auth0';
//import { TextInput } from "react-native-paper";

// const prefix = Linking.makeUrl('/');
//Expo Client: 'exp://localhost:port'
//Standalone: 'mycoolredirect://' this is from scheme
// WebBrowser.maybeCompleteAuthSession();
const MY_SECURE_AUTH_STATE_KEY = 'MySecureAuthStateKey';


const auth0ClientId = 'xm0rhxbCUFplWFuhMyEP3O8EpSwNaG2o';
// const auth0Domain = 'https://dev-haqt-0da.auth0.com';
// const auth0ClientId = "";
// const authorizationEndpoint = "https://arielweinberger.eu.auth0.com/authorize";
const authorizationEndpoint = "https://dev-haqt-0da.auth0.com/authorize";

const useProxy = Platform.select({ web: false, default: false });
// for stand alone and published apps use { useProxy }
// const useProxy = Platform.select({ web: false, default: true });

// const redirectUri = AuthSession.makeRedirectUri({ useProxy });

// for stand alone and 'expo start' apps use { useProxy: false }
const redirectUri = AuthSession.makeRedirectUri({ useProxy });
export const AppContext = createContext({});


function Auth({ navigation }) {

    const [isLoggedIn, setIsLoggedIn] = useState(true);
    const [name, setName] = useState(null);
    const [username, setUsername] = useState(null);
    const [email, setEmail] = useState(null);
    const [userID, setUserID] = useState(null);
    const [token, setToken] = useState(null);
    const [org_id, setOrg_id] = useState(null);
    const [role, setRole] = useState(null);
    const [dept_id, setDept_id] = useState(null);

    const Dcontext = React.useContext(UserContext);
    const apolloClient = createApolloClient(token);
const auth0 = new Auth0({ domain: 'dev-haqt-0da.auth0.com', clientId: 'xm0rhxbCUFplWFuhMyEP3O8EpSwNaG2o' });

auth0.webAuth
    .authorize({scope: 'openid profile email offline_access'})
    .then(credentials =>{
      // Successfully authenticated
      // Store the accessToken
      alert(credentials.accessToken);
      console.log(credentials);
      Dcontext.setToken(token);
      setAccessToken(credentials.accessToken);}
    ).catch((error) => console.log(error));
    /* const [request, result, promptAsync] = AuthSession.useAuthRequest(
        {
            redirectUri,
            clientId: auth0ClientId,
            // id_token will return a JWT token
            responseType: "id_token",
            // retrieve the user's profile
            scopes: ["openid", "profile", "email", "offline_access"],

            extraParams: {
                // ideally, this will be a random value
                nonce: "nonce",
            },
        },
        { authorizationEndpoint }
    ); 
 useEffect(() => {
    // Stop the Splash Screen from being hidden.
    const showSplashScreen = async () => {
      //await SplashScreen.preventAutoHideAsync();
       var res = await SecureStore.getItemAsync('MySecureAuthStateKey');
        const detail = JSON.parse(res);

        const { avatar, name, email, token, id } = detail;
        Dcontext.setEmail(email);
        Dcontext.setUsername(name);
        Dcontext.setToken(token);
        Dcontext.setUserId(id);
        Dcontext.setAvatar(avatar);
        if(!name) return(setName(name));
    }
    showSplashScreen();
   // getToken();
  }, [name]);
    const getItem = async () => {

         var res = await SecureStore.getItemAsync('MySecureAuthStateKey');
        const detail = JSON.parse(res);

        const { avatar, name, email, token, id } = detail;
        Dcontext.setEmail(email);
        Dcontext.setUsername(name);
        Dcontext.setToken(token);
        Dcontext.setUserId(id);
        Dcontext.setAvatar(avatar);
        setName(name);
        
        console.log(JSON.parse(res), 'hello here', token); 

        const client = createApolloClient(token);
        await client.mutate({
            mutation: gql`
        mutation ($username: String, $userID: String, $email: String){
          insert_users (
            objects: [{ name: $username, auth0_id: $userID, email:$email}],
            on_conflict:{
                constraint: users_email_key,
                update_columns:[]
            }

          ) {
            affected_rows
            returning{
                auth0_id
                name
                email
            }
          }
        }
      `,
            variables: {
                username: name,
                userID: userID,
                email: email
            }
        //}).then(console.log);
         }).then((result) => {
            console.log("graphql response", result);
            return result.data.name;
        }).catch((error) => {
            console.log("Graphql query error", error);

            let err = error;
            if (error.graphQlErrors && error.graphQlErrors.length > 0)
                err = error.graphQlErrors[0];
            throw err;
        });
 
           };
    // Retrieve the redirect URL, add this to the callback URL list
    // of your Auth0 application.
    console.log(`Redirect URL: ${redirectUri}`);
    //

    React.useEffect(() => {

        if (result) {
            if (result.error) {
                Alert.alert(
                    "Authentication error",
                    result.params.error_description || "something went wrong"
                );
                return;
            }
            if (result.type === "success") {
                const auth = result.params;

                if (Platform.OS !== 'web') {
                        // store session in storage and redirect back to the app
                    const encodedToken = result.params.id_token;
                    setToken(encodedToken);
                    const decodedToken = jwtDecode(encodedToken);
                    //console.log(decodedToken, "here is ec");
                    console.log(encodedToken, "here is token");
                    SecureStore.setItemAsync(
                        // AsyncStorage.setItem(
                        'MySecureAuthStateKey',
                        //JSON.stringify(decodedToken)
                        JSON.stringify({
                            token: encodedToken,
                            name: decodedToken.nickname,
                            id: decodedToken.sub,
                            exp: decodedToken.exp,
                            email: decodedToken.email,
                            avatar: decodedToken.picture
                        })
                    ).then(() => {
                        alert('token saved locally');
                        // this.props.login(decodedToken.sub, decodedToken.nickname, encodedToken);
                    });
                }
                // Retrieve the JWT token and decode it
                const jwtToken = result.params.id_token;
                const decoded = jwtDecode(jwtToken);
                getItem();

                //console.log(jwtDecode("my token " + auth.id_token));
                const { nickname, name, email, sub, picture } = decoded;
                setName(name);
                setUsername(nickname);
                setUserID(sub);
                setEmail(email);
                //setAvatar(picture);
                //getItem();
                //console.log(sub + " my id");

                //getItem();  
            }
        }
    }, [result]);
*/
    return (
        <SafeAreaView style={styles.container}>

            {name ? (
                <View>
                    <Text style={styles.title}>You are logged in as, {username}!</Text>
                    <Button
                        title={"continue as " + username}
                        onPress={() => navigation.navigate('App')}
                    />
                    <LegacyApolloProvider client={apolloClient}>
                        <Query query={GET_Users}  fetchPolicy='cache-and-network'>
                            {({ loading, error, data }) => {
                               if (loading)  return <View styles={styles.activity}>
                <ActivityIndicator size="large" color="#000ff" />
                </View>
                if ( error) return <View>{console.log("my error gql "+error)}
                <Text>Data loading error ${error.message}</Text></View>
                                {
                                    data.users.forEach(function (obj) {
                                        Dcontext.setOrg_id(obj.org_id);
                                        Dcontext.setDept_id(obj.dept_id);
                                        Dcontext.setRole(obj.role);
                                        console.log(obj.email + " my list ");
                                        AsyncStorage.setItem(
                                            'CurrentProfile',
                                            //JSON.stringify(decodedToken)
                                            JSON.stringify({
                                                orgID: obj.org_id,
                                                deptID: obj.dept_id,
                                                role: obj.role,
                                                others: obj.others,
                                                email: obj.email
                                            })
                                        ).then(() => {
                                            alert('Profile Set');
                                        });
                                    });
                                    Dcontext.setMyAccounts(data.accounts);
                                    Dcontext.setCashflow(data.cashflows);
                                }
                                return (
                                    <View>
                                        <Text style={styles.title}>current Profile {Dcontext.org_id}!</Text>
                                        <Text style={styles.title}>{Dcontext.dept_id}!</Text>
                                        <Text style={styles.title}>{Dcontext.role}!</Text>
                                        <Button
                                            //disabled={!request}
                                            title="proceed home"
                                            // used only with expo published apps
                                            // onPress={() => promptAsync({ useProxy })}

                                            // used only with expo start apps
                                            onPress={() => navigation.navigate('App')}
                                        />
                                    </View>
                                );
                            }
                            }
                        </Query>
                    </LegacyApolloProvider>

                </View>
            ) : (
                    <View>
                        <Button
                            disabled={!request}
                            title="Online Login"
                            // used only with expo published apps
                            // onPress={() => promptAsync({ useProxy })}

                            // used only with expo start apps
                            onPress={() => promptAsync({ redirectUri })}
                        />
                        <View style={{ paddingTop: 10 }} />
                       
                    </View>

                )}
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#03eccf",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 10,
    },
     activity:{
        position:'absolute',
        alignItems:'center',
        justifyContent:'center',
left: 0,
right: 0,
top: 0,
bottom: 0,
    },
    title: {
        fontSize: 20,
        textAlign: "center",
        marginTop: 10,
        flexWrap: 'wrap',
    },
}); 

export default Auth;
//export default withNavigation(Auth);