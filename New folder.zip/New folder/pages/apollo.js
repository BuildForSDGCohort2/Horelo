import { ApolloClient, defaultOptions } from 'apollo-client';
import { onError } from 'apollo-link-error';
import { ApolloLink } from 'apollo-link';
import { HttpLink } from 'apollo-link-http';
import { InMemoryCache } from 'apollo-cache-inmemory';
import {persistCache} from 'apollo-cache-persist';
import AsyncStorage from '@react-native-community/async-storage';
import { Alert } from "react-native";

import gql from 'graphql';
//

const GRAPHQL_ENDPOINT = `https://micentsn.herokuapp.com/v1/graphql`;

const createApolloClient = (token) => {
  const cache = new InMemoryCache();
  
    const httpLink = new HttpLink({
        uri: GRAPHQL_ENDPOINT,
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });
  const errorLink = onError(({ graphQLErrors, networkError }) => {
    if (graphQLErrors) {
      Alert.alert(
        "graphql error",
        graphQLErrors.error_description || "graphql went wrong"
      );
      return;
    }

    if (networkError) {
      Alert.alert(
        "networkError error",
        networkError.error_description || "networkError went wrong"
      );
      return;
    }
  });
  //const link = ApolloLink.from([errorLink, httpLink]);
  const link = ApolloLink.from([httpLink]);
  const client = new ApolloClient({
    link,
    cache,
    defaultOptions
    //typeDefs,
  });

// const persist = persistCache({
  //  cache: client.cache,
  //  storage: AsyncStorage,
  //  trigger: 'write',
  //  debug:true,
 // });
   
    return client; 
    
};
export default createApolloClient;


 /* 
import React, { useState, useEffect, useContext } from 'react';
import { ApolloClient, defaultOptions } from 'apollo-client';
import { onError } from 'apollo-link-error';
import { ApolloLink } from 'apollo-link';
import { HttpLink } from 'apollo-link-http';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { persistCache } from 'apollo-cache-persist';
import AsyncStorage from '@react-native-community/async-storage';
import { Alert } from "react-native";
import { FETCH_TRANSACTIONS } from './Home/Home';

import gql from 'graphql';
//

const GRAPHQL_ENDPOINT = `https://micentsn.herokuapp.com/v1/graphql`;
const createApolloClient = (token) => {
  const [client, setClient] = useState(undefined);
  const httpLink = new HttpLink({
    uri: GRAPHQL_ENDPOINT,
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  const errorLink = onError(({ graphQLErrors, networkError }) => {
    if (graphQLErrors) {
      Alert.alert(
        "graphql error",
        graphQLErrors.error_description || "graphql went wrong"
      );
      return;
    }

    if (networkError) {
      Alert.alert(
        "networkError error",
        networkError.error_description || "networkError went wrong"
      );
      return;
    }
  });
  //const link = ApolloLink.from([errorLink, httpLink]);
  const link = ApolloLink.from([httpLink]);
  useEffect(() => {
    const cache = new InMemoryCache();

    persistCache({
      cache,
      storage: AsyncStorage,
    });

    const client = new ApolloClient({
      link,
      cache,
      defaultOptions
      //typeDefs,
    });
    const initData = {
      transactions: [],
    };
    cache.readQuery({
      query: FETCH_TRANSACTIONS
    });
    cache.writeData({ data: initData });
    
    // See above for additional options, including other storage providers.
    persistCache({
      cache,
      storage: AsyncStorage,
    }).then(() => {
      client.onResetStore(async () => cache.writeData({ data: initData }));
      setClient(client);
    }); */
    /* try {
      cache.readQuery({
        query: FETCH_TRANSACTIONS
      });
    } catch (error) {
      cache.writeData({
        data: {
          transactions: []
        }
      });
    } */
    /* const persist = persistCache({
      cache: client.cache,
      storage: AsyncStorage,
      trigger: 'write',
      debug:true,
    });
     */
   /*  return () => { };
  }, []);
  if (client === undefined) return alert("Loading...");
  return client;

};
export default createApolloClient; */