import React from 'react';
import { Button, ActivityIndicator, View, StyleSheet, Dimensions, FlatList, TouchableHighlight } from 'react-native';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
import {Text} from 'react-native-paper';
import Icon from '@expo/vector-icons/MaterialCommunityIcons';
import MyButton from '../../components/AddCashFlowButton';
//import { withNavigation } from 'react-navigation';
import AsyncStorage from '@react-native-community/async-storage';
//import store from 'react-native-simple-store';
import SwitchSelector from 'react-native-switch-selector';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import { UserContext } from '../../App';
import { Dropdown } from 'react-native-material-dropdown';
import { Picker } from '@react-native-community/picker'


export const GET_Cashflows = gql`
    query cashflows($orgID: String!) {
  cashflows(where: {orgID: {_eq: $orgID}}){
    id
    name
    icon
    type
    orgID
  }

}`;
const options = [
    { label: 'INCOMES', value: '1' },
    { label: 'EXPENSES', value: '0' },

];


const initialLayout = { width: Dimensions.get('window').width };

function CashFlows({ navigation }) {
    const user_context = React.useContext(UserContext);
    const orgID = user_context.org_id;
    const [isLoading, setIsLoading] = React.useState(false);
    const [cashflowList, setCashflowList] = React.useState([]);
    const [dataCart, setDataCart] = React.useState([]);

    const [key, setKey] = React.useState(options[1]);
    const [keyLabel, setKeyLabel] = React.useState(key.label);
    const [keyValue, setKeyValue] = React.useState(key.value);
    const [val, setVal] = React.useState("income");
    const [selectedVal, setSelectedVal] = React.useState(null);
    const [newLabel, setNewLabel] = React.useState("now");

    let cashflowItem = [];
    
   
    let pickerValues = cashflowList.map((item, i)=>{
        return(
            <Picker.Item label={item.name}
            value={item.icon} key={i}/>
           )
           // console.log(item.name) 
        })
    
    function cashFlowValues() {
        try {
            AsyncStorage.setItem('cashFlowValues',JSON.stringify(cashflowList));
        } catch (error) {
            
        }
         
    }
    return (
        <View
            style={[styles.scene, { backgroundColor: '#ff24' }]} >
            <View style={{ paddingTop: 5 }} />
            <SwitchSelector
                options={options}
                hasPadding={true}
                bold={true}
                initial={0}
                fontSize={12}
                textColor={'#aaaaaa'}
                selectedColor={'#fff'}
                buttonColor={'#262625'}
                backgroundColor={'#328'}
                borderColor={'#689'}
                onPress={value => {
                    setVal(value == 1 ? "income" : "expense");
                    setKey(options[value])
                    setKeyLabel(key.label)
                    setKeyValue(key.value)
                }}
            />

            {/* <Text style={{ fontWeight: 'bold', color: '#345' }}>
                    {keyLabel} - {keyValue} -- {val}
                </Text> */}

            <View style={[styles.scene, { backgroundColor: '#23f89d' }]} >
           
                <Query query={GET_Cashflows} 
                
                variables={{ orgID }} fetchPolicy='cache-and-network'>
                    {({ loading, error, data, refetch }) => {
                        if (loading) return <View styles={styles.activity}>
                            <ActivityIndicator size="large" color="#000ff" />
                        </View>
                        if (error) return <View>{console.log("my error gql " + error)}
                            <Text>Data loading error ${error.message} </Text></View>
                           
                            try {
                                AsyncStorage.setItem('cashFlowValues',JSON.stringify(cashflowList));
                            } catch (error) {
                                
                            }
                             
                        return (
                            <View>
                                {setCashflowList(data.cashflows)}
                              
                                
                                <FlatList
                                    data={data.cashflows.filter((type) =>
                                        type.type === val)}
                                        
                                    renderItem={({ item, index }) =>
                                        <TouchableHighlight
                                            onPress={() => { 
                                                 navigation.navigate('EditCashFlow', { items: item })  }}
                                            {...item}
                                        >
                                            {val === "income" ?
                                                <View style={styles.item,
                                                {
                                                    alignItems: 'center', flexDirection: 'row',
                                                    backgroundColor: index % 2 == 0 ? "#f4d4b4" : "#fdfdfe"
                                                }}>
                                                    <View style={styles.incomecircle}>
                                                        <Icon name={item.icon} style={styles.icons} />
                                                    </View>
                                                    <Text style={styles.name}>{item.name}</Text>
                                                </View>
                                                :
                                                <View style={styles.item, { alignItems: 'center', flexDirection: 'row', backgroundColor: index % 2 == 0 ? "#f4d4b4" : "#fdfdfd" }}>
                                                    <View style={styles.expenseCircle}>
                                                        <Icon name={item.icon} style={styles.icons} />
                                                    </View>
                                                    <Text style={styles.name}>{item.name}</Text>

                                                </View>
                                            }
                                        </TouchableHighlight>
                                    }
                                    keyExtractor={item => item.id.toString()}
                                    refreshing={isLoading}
                                    onRefresh={() => { refetch() }}
                                />

                            </View>
                        );
                    }
                    }
                </Query>

            </View>

            <MyButton />
        </View>
    );
}

const styles = StyleSheet.create({
    activity: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
    scene: {
        flex: 1,
        fontFamily: 'ValidityScriptBI',
    },

    item: {
        flex: 1,
        marginLeft: 1,
        flexDirection: 'row',
    },

    name: {
        fontSize: 18,
        fontWeight: 'bold',
        paddingLeft: 10
    },

    icons: {
        fontSize: 30,
        color: 'white',
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        borderTopLeftRadius: 35,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        backgroundColor: '#004f32',
        marginStart: 10,
        marginTop: 2,
        marginBottom: 3,
        alignItems: 'center',
        justifyContent: 'center',
    },
    expenseCircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        borderTopLeftRadius: 35,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        backgroundColor: "red",
        marginStart: 10,
        marginTop: 2,
        marginBottom: 3,
        alignItems: 'center',
        justifyContent: 'center',
    },
});
export default CashFlows;