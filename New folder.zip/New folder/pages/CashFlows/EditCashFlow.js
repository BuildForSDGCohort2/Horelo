import React, { useState, useEffect, useContext } from 'react';
import {
    Alert, TouchableOpacity, TouchableHighlight,
    Button,
    FlatList,
    ScrollView,
    StyleSheet,
    View,
} from 'react-native';
import {Text} from 'react-native-paper';
import Icon from '@expo/vector-icons/MaterialCommunityIcons';
import SaveButton from '../../components/SaveButton';

import { UserContext } from '../../App';
import Modal from 'react-native-modal';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
import Mytextinput from '../../components/MyTextInput';
import Ionicons from '@expo/vector-icons/Ionicons';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import dateTime from '../../assets/getTS';

const UPDATE_CASHFLOW = gql`
  mutation ($id: Int!, $icon: String!, $userId: String!, 
     $cashflow: String!, $name: String!){
    update_cashflows (
      _set:{
        name: $name,
        editedBY: $userId,
        icon: $icon,
        type:$cashflow,
      },
      where: {
        id: {
          _eq: $id
        }
      }
    ){
      returning {
        id
        icon
        type
        name
      }
    }
  }
`;
const DELETE_CASHFLOW = gql`
  mutation ($id: String) {
    delete_cashflows (
      where: {
        id: {
          _eq: $id
        }
      }
    ) {
      affected_rows
    }
  }
`;


const cashflowCategory = [
    {
        label: 'Income',
        value: 'income',
    },
    {
        label: 'Expense',
        value: 'expense',
    },
];

EditCategory.navigationOptions = {
    title: 'Edit Cashflow',
};
//export default class App extends React.Component {
export default function EditCategory({route, navigation}) {
   

    useEffect(() => {
       
    }, []);
    var [show, setShow] = useState(false);

    const [modalVisible, setModalVisible] = useState(false);
    const user_context = React.useContext(UserContext);
    var [cashflow, setCashflow] = useState(null);
    var [name, setName] = useState(null);
    const userId = user_context.userId;
    const { items } = route.params;
    const [createdAT, setCreatedAT] = useState(null);
   
    let id = items.id, orgID = items.orgID;

    var [icon, setIcon] = useState(null);
   
    const placeholder = {
        label: items.type ,
        value: items.type,
        color: '#9EA0A4',
    };
    return (
        <View style={styles.container}>
            {/*  <Header titleText="Add Category" /> */}
            <Mutation
                mutation={UPDATE_CASHFLOW}
                variables={{
                    id,
                    name,
                    icon,
                    cashflow,
                    userId,
                }}
                >
                {
                    (updateCashFlow, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text> Error </Text>;
                            }
                            if (loading ) {
                                return;
                            }
                            
                            {/* console.log(name + " nhere ");
                            console.log(icon + " mhere ");
                            console.log(cashflow + " shere flow");
                            console.log(items.orgID + " rhere ");
                            console.log(items.id + " rhere id ");  */}
                            updateCashFlow();
                            setName('');
                            setCashflow('');
                            alert("cash flow updated successfully")
                        }
                        return (
                            <View style={[styles.scrollContainer, styles.scrollContentContainer]}>
                                      <View style={styles.rowItem}>
                                        <TouchableOpacity
                                            onPress={() => { setModalVisible(true) }}>
                                            <View style={styles.circle}>
                                            <Icon name={icon? icon : items.icon} style={styles.icons} />
                                            </View>
                                        </TouchableOpacity>

                                    <Mytextinput
                                            placeholder="Category name"
                                        defaultValue={items.name}
                                        onChangeText={text => { setName(text)}}
                                        //value={items.icon}
                                        />
                                   
                                    </View>
                               
                                   {/*  <Mytextinput
                                        placeholder="Category name"
                                        style={{ padding: 10 }}
                                        value={items.name}
                                    /> */}
                                    <Modal
                                        animationType='slide'
                                        transparent={false}
                                        visible={modalVisible}
                                        onRequestClose={() =>
                                            Alert.alert("modal has closed")}>
                                        <View style={styles.MainContainer}>
                                            <Text>Hello!</Text>
                                            <FlatList
                                                data={expenseCategories}
                                                renderItem={({ item }) =>
                                                    <TouchableHighlight
                                                        onPress={() => { setIcon(item.icon); setModalVisible(false); }
                                                        }>
                                                        <View style={styles.incomecircle}>
                                                            <Icon name={item.icon} style={styles.icons} />
                                                        </View>
                                                    </TouchableHighlight>
                                                }
                                                keyExtractor={item => item.id}
                                                numColumns={4}
                                            />
                                            <Button style={{ marginTop: 20 }} title="Cancel" onPress={() => { setModalVisible(!modalVisible) }} />

                                        </View>
                                    </Modal>
                                    <View paddingVertical={10} />
                                    <RNPickerSelect
                                    //placeholder={placeholder}
                                        items={cashflowCategory}
                                        defaultValue={items.type}
                                        onValueChange={(value) => {
                                            setCashflow(value)
                                        }}
                                        style={{
                                            ...pickerSelectStyles,
                                            iconContainer: {
                                                top: 10,
                                                right: 12,
                                                width: 20,
                                            },
                                        }}
                                    value={cashflow ? cashflow : items.type}
                                        useNativeAndroidPickerStyle={false}
                                        textInputProps={{ underlineColor: 'yellow' }}
                                        Icon={() => {
                                            return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                                        }}
                                    />
                                <View style={{  marginTop: 20, marginBottom: 20, flexDirection:'row'}}>

                                        <View paddingHorizontal={5} />
                                        {show ? <SaveButton
                                            title="confirm"
                                            style={{ width: 100, backgroundColor: 'green', }}
                                            customClick={() => {
                                                submit();
                                                navigation.goBack();
                                                setShow(false);
                                            }}
                                        /> : <SaveButton
                                                style={{ width: 100, }}
                                                title="UPDATE"
                                                customClick={() => {
                                                    icon ? icon : setIcon(items.icon);
                                                    name ? name : setName(items.name);
                                                    cashflow ? cashflow : setCashflow(items.type);
                                                    setShow(true);
                                                    //submit();
                                                }}
                                            />}

                                    <View paddingRight={30}/>
                                <SaveButton
                                    title="Delete"
                                    onPress={() => { del() }} />
                            </View>
                            </View>
                        );
                    }
                }
            </Mutation>
        </View>
    );
    //}
}

const styles = StyleSheet.create({
    
    MainContainer: {
        flex: 1,
        paddingTop: 20,
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        justifyContent: 'flex-start',
        alignSelf: 'center',
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 12,
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        marginTop: 10,
        justifyContent: 'center',
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 2,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        borderTopLeftRadius: 35,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        backgroundColor: '#400f',
        marginStart: 10,
        marginTop: 2,
        marginBottom: 3,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    scrollContainer: {
        flex: 1,
        paddingHorizontal: 15,
    },
    scrollContentContainer: {
        paddingTop: 40,
        paddingBottom: 10,
    },
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        marginLeft: 20,
        width: 300,
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        marginLeft: 20,
        width: 300,
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});