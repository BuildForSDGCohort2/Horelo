import React, { useState, useEffect, useContext} from 'react';
import {
    Alert, KeyboardAvoidingView, SafeAreaView, TouchableOpacity, TouchableHighlight,
    Button,
    FlatList,
    ScrollView,
    StyleSheet,
    View,
} from 'react-native';
import {Text} from 'react-native-paper';
import Icon from '@expo/vector-icons/MaterialCommunityIcons';
import { UserContext } from '../../App';

import Modal from 'react-native-modal';
// import FlatList from 'flatlist-react';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import Header from '../../components/Header';
import Ionicons from '@expo/vector-icons/Ionicons';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
// import RNPickerSelect, { defaultStyles } from './debug';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import dateTime from '../../assets/getTS';

const INSERT_CASHFLOW = gql`
  mutation ($icon: String!, $userId: String!, 
    $orgID: String!, $deptID: String!, $cashflow: String!, $name: String!){
    insert_cashflows (
      objects: [{
        name: $name,
        createdBY: $userId,
        icon: $icon,
        type:$cashflow,
        orgID: $orgID,
        dept: $deptID
      }]
    ){
      returning {
        id
        icon
        type
        name
      }
    }
  }
`;


const cashflowCategory = [
    {
        label: 'Income',
        value: 'income',
    },
    {
        label: 'Expense',
        value: 'expense',
    },
];
AddCashFlow.navigationOptions = {
    title: 'Add Cashflow',
};
//export default class App extends React.Component {
export default function AddCashFlow() {
    const User_context = React.useContext(UserContext);
   const [orgID, setOrgID] = useState(User_context.org_id);
    const [userId, setUserId] = useState(User_context.userId);
    const [deptID, setDeptID] = useState(User_context.dept_id);
    const [cashflow, setCashflow] = useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const [name, setName] = useState('');
    const [icon, setIcon] = useState(null);
    const [createdAT, setCreatedAT] = useState(null);


    //render() {
    const placeholder = {
        label: 'Select a cashflow...',
        value: null,
        color: '#9EA0A4',
    };
    
    return (
        <View style={styles.container}>
            {/*  <Header titleText="Add Category" /> */}
            <Mutation
                mutation={INSERT_CASHFLOW}
                variables={{
                    name,
                    icon, 
                    cashflow,
                    userId,
                    orgID,
                    deptID,                    
                }}
                
            >
                {
                    (insertCashFlow, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text> Error </Text>;
                            }
                            if (loading || setName === '' || setCashflow === '') {
                                return;
                            }
                            
                            insertCashFlow();
                            setName('');
                            setCashflow('');
                            alert('Cash flow added successfully')
                        }
                        return (
                            <View style={styles.container}>
            <ScrollView
                style={styles.scrollContainer}
                contentContainerStyle={styles.scrollContentContainer}>
                <View style={styles.rowItem}>
                    <TouchableOpacity
                        onPress={() => { setModalVisible(true) }}>
                        <View style={styles.circle}>
                            <Icon name={icon} style={styles.icons} />
                        </View>
                    </TouchableOpacity>

                    <Mytextinput
                        placeholder="Category name"
                        onChangeText={(value) => { setName(value) }}
                        value={name}
                    />
                </View>
                <Modal
                    animationType='slide'
                    transparent={false}
                    visible={modalVisible}
                    onRequestClose={() =>
                        Alert.alert("modal has closed")}>
                    <View style={styles.MainContainer}>
                        <Text>Hello!</Text>
                        <FlatList
                            data={expenseCategories}
                            renderItem={({ item }) =>
                                <TouchableHighlight
                                    onPress={() => { setIcon(item.icon); setModalVisible(false); }
                                    }>
                                    <View style={styles.incomecircle}>
                                        <Icon name={item.icon} style={styles.icons} />
                                    </View>
                                </TouchableHighlight>
                            }
                            keyExtractor={item => item.id}
                            numColumns={4}
                        />
                        <Button style={{ marginTop: 20 }} title="Cancel" onPress={() => { setModalVisible(!modalVisible) }} />

                    </View>
                </Modal>
                <View paddingVertical={10} />
                <RNPickerSelect
                    placeholder={placeholder}
                    items={cashflowCategory}
                    onValueChange={(value) => {
                        setCashflow(value)
                    }}
                    style={{
                        ...pickerSelectStyles,
                        iconContainer: {
                            top: 10,
                            right: 12,
                            width: 20,
                        },
                    }}
                    value={cashflow}
                    useNativeAndroidPickerStyle={false}
                    textInputProps={{ underlineColor: 'yellow' }}
                    Icon={() => {
                        return <Ionicons name="md-arrow-down" size={24} color="gray" />;
                    }}
                />
            </ScrollView>
            <Button style={{ marginTop: 20 }} 
            title="Save" 
                                    onPress={() => { setCreatedAT(dateTime()); submit()}} />
             </View>
            );
            }
          }
        </Mutation>
        </View>
    );
    //}
}

const styles = StyleSheet.create({
    flex: {
        flex: 1
    },
    MainContainer: {
        flex: 1,
        paddingTop: 20,
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        justifyContent: 'flex-start',
        alignSelf: 'center',
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 12,
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        marginTop: 10,
        justifyContent: 'flex-start',
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 2,
        marginTop: 10,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        borderTopLeftRadius: 35,
        borderTopRightRadius: 35,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        backgroundColor: '#400f',
        marginStart: 10,
        marginTop: 2,
        marginBottom: 3,
    },
    container: {
        flex: 1,
    },
    scrollContainer: {
        flex: 1,
        paddingHorizontal: 15,
    },
    scrollContentContainer: {
        paddingTop: 40,
        paddingBottom: 10,
    },
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        marginLeft: 20,
        width: 300,
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        marginLeft: 20,
        width: 300,
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});