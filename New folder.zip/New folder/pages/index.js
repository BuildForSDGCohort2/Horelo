import React, { Component, useContext, useState } from 'react';
import { View, Image, TouchableOpacity, Text, Dimensions, } from 'react-native';

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createDrawerNavigator } from 'react-navigation-drawer';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import Icon from '@expo/vector-icons/FontAwesome5';
import Ionicons from '@expo/vector-icons';
import Icons from 'react-native-vector-icons/Ionicons';  
import Home from './Home/Home';
import Depart from './Home/Depart';
import Admin from './Home/Admin';
import AddPOS from './Home/AddPOS';
import AddTransaction from './Home/AddTransaction';
import Accounts from './Accounts/Accounts';
import AddAccount from './Accounts/AddAccount';
import EditAccount from './Accounts/EditAccount';
import AddCashFlow from './CashFlows/AddCashFlow';
import EditCashFlow from './CashFlows/EditCashFlow';
import Settings from './Settings/Settings';
import AddProfile from './Settings/AddProfile';
import UserProfile from './Settings/UserProfile';
import EditProfile from './Settings/EditProfile';
import AddCompany from './Settings/AddCompany';
import EditCompany from './Settings/EditCompany';
import ViewCompany from './Settings/ViewCompany';
import ViewUsers from './Settings/ViewUsers';
import Reports from './Reports/Reports';
import Stock from './Stock/Stock';
import StockList from './Stock/StockList';
import EditProduct from './Stock/EditProduct';
import AddProduct from './Stock/AddProduct';
import FirstStack from './Home/FirstStack';
import SecondStack from './Accounts/SecondStack';
import CashFlows from './CashFlows/CashFlows';
import HomeTab from './TabOne/HomeTab';
import Cart from './TabOne/Cart';
import ProductPage from './TabOne/ProductPage';
import Products from './TabOne/Products';
import CustomSidebarMenu from './CustomDrawer';
import LoginScreen from './Login';


global.currentScreenIndex = 0;
class NavigationDrawerStructure extends Component {
  //Structure for the navigation Drawer
  toggleDrawer = () => {
    //Props to open/close the drawer
    this.props.navigationProps.toggleDrawer();
  };
  render() {
    return (
      <View style={{ flexDirection: 'row' }}>
        <TouchableOpacity onPress={this.toggleDrawer.bind(this)}>
          {/*Donute Button Image */}
          <Image
            source={require('../image/drawer.png')}
            style={{ width: 25, height: 25, marginLeft: 5 }}
          />
        </TouchableOpacity>

      </View>
    );
  }
}
function myicon({ focused, color, size }) {
  return (<Icon color="blue" size={50}
    name={focused ? 'home' : 'home'} />);
}

/* const Login_StackNavigator = createStackNavigator({
  //All the screen from the Screen3 will be indexed here
  LoginScreen: {
    screen: Login,
  },
  
});  */
const Home_StackNavigator = createStackNavigator({
  //All the screen from the Screen1 will be indexed here
  First: {
    screen: Home,
    navigationOptions: ({ navigation }) => ({

      title: 'Home',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: 'red',
      },
      headerTintColor: '#fff',

    })
  },
  FirstStack: {
    screen: FirstStack,
    headerMode: 'none',
  },
  AddPOS: AddPOS,
  AddTransaction: AddTransaction,
});

const Admin_StackNavigator = createStackNavigator({
  //All the screen from the Screen1 will be indexed here
  First: {
    screen: Admin,
    navigationOptions: ({ navigation }) => ({

      title: 'Demo Screen one',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: 'red',
      },
      headerTintColor: '#fff',

    })
  },
  FirstStack: {
    screen: FirstStack,
    headerMode: 'none',
  },
  AddPOS: AddPOS,
  AddTransaction: AddTransaction,
});

const Depart_StackNavigator = createStackNavigator({
  //All the screen from the Screen1 will be indexed here
  First: {
    screen: Depart,
    navigationOptions: ({ navigation }) => ({

      title: 'Demo Screen one',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: 'red',
      },
      headerTintColor: '#fff',

    })
  },
  FirstStack: {
    screen: FirstStack,
    headerMode: 'none',
  },
  AddPOS: AddPOS,
  AddTransaction: AddTransaction,
});


const Accounts_StackNavigator = createStackNavigator({
  //All the screen from the Accounts will be indexed here
  Second: {
    screen: Accounts,
    navigationOptions: ({ navigation }) => ({
      title: 'Accounts',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: 'red',
      },
      headerTintColor: '#fff',
    }),
  },
  Screen2Second: {
    screen: SecondStack,
  },
  AddAccount: {
    screen: AddAccount,
  },
  EditAccount: {
    screen: EditAccount,
  },
});

const Reports_StackNavigator = createStackNavigator({
  //All the screen from the Screen3 will be indexed here
  Third: {
    screen: Reports,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 3',
      headerLeft: ()=>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },

});
const Stock_StackNavigator = createStackNavigator({
  //All the screen from the stock will be indexed here
  Stock: {
    screen: Stock,
    navigationOptions: ({ navigation }) => ({
      title: 'Stock',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),

  },
  AddProduct: AddProduct,
  EditProduct: EditProduct,
});
const Screen4_StackNavigator = createStackNavigator({
  //All the screen from the Screen3 will be indexed here
  CashFlows: {
    screen: CashFlows,
    navigationOptions: ({ navigation }) => ({
      title: 'CashFlows',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
  AddCashFlow: { screen: AddCashFlow, },
  EditCashFlow: EditCashFlow,
}, {
  //headerMode: 'none',
});
const Screen5_StackNavigator = createStackNavigator({
  //All the screen from the Screen3 will be indexed here
  Settings: {
    screen: Settings,
    navigationOptions: ({ navigation }) => ({
      title: 'Settings',
      headerLeft: () =>(<NavigationDrawerStructure navigationProps={navigation} />),
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
  AddCompany: AddCompany,
  EditCompany: EditCompany,
  ViewCompany: ViewCompany,
  ViewUsers: ViewUsers,
  AddProfile: AddProfile,
  UserProfile: UserProfile,
  EditProfile: EditProfile,
});

const DrawerNavigatorExample = createDrawerNavigator({
  //Drawer Options and indexing
  Home: {
    //Title
    screen: Home_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Home',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'home' : 'home'} />, */
    },

  },
  Accounts: {
    //Title
    screen: Accounts_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Accounts',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'cash-register' : 'cash-register'} />, */
    },
  },
  Reports: {
    //Title
    screen: Reports_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Reports',
      /* drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
        name={focused ? 'chart-area' : 'chart-bar'} />, */
    },
  },
  Stock: {
    //Title
    screen: Stock_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Stock',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'folder' : 'folder-open'} />, */
    },
  },
  CashFlows: {
    //Title
    screen: Screen4_StackNavigator,
    navigationOptions: {
      drawerLabel: 'CashFlows',
      /* drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
        name={focused ? 'columns' : 'book'} />, */
    },
  },
  Settings: {
    //Title
    screen: Screen5_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Settings',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'toolbox' : 'tools'} />, */
    },
  },
},
  {
    //For the Custom sidebar menu we have to provide our CustomSidebarMenu
    contentComponent: CustomSidebarMenu,
    //Sidebar width
    drawerWidth: Dimensions.get('window').width - 100,
  }
);

const DrawerNavigatorAdmin = createDrawerNavigator({
  //Drawer Options and indexing

  Home: {
    //Title
    screen: Admin_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Home',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'home' : 'home'} />, */
    },

  },
  Accounts: {
    //Title
    screen: Accounts_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Accounts',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'cash-register' : 'cash-register'} />, */
    },
  },
  Reports: {
    //Title
    screen: Reports_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Reports',
      /* drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
        name={focused ? 'chart-area' : 'chart-bar'} />, */
    },
  },
  Stock: {
    //Title
    screen: Stock_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Stock',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'folder' : 'folder-open'} />, */
    },
  },
  CashFlows: {
    //Title
    screen: Screen4_StackNavigator,
    navigationOptions: {
      drawerLabel: 'CashFlows',
      /* drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
        name={focused ? 'columns' : 'book'} />, */
    },
  },
  Settings: {
    //Title
    screen: Screen5_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Settings',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'toolbox' : 'tools'} />, */
    },
  },
},
  {
    //For the Custom sidebar menu we have to provide our CustomSidebarMenu
    contentComponent: CustomSidebarMenu,
    //Sidebar width
    drawerWidth: Dimensions.get('window').width - 100,
  }
);
const DrawerNavigatorDepart = createDrawerNavigator({
  //Drawer Options and indexing

  Home: {
    //Title
    screen: Depart_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Home',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'home' : 'home'} />, */
    },

  },
  Accounts: {
    //Title
    screen: Accounts_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Accounts',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'cash-register' : 'cash-register'} />, */
    },
  },
  Reports: {
    //Title
    screen: Reports_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Reports',
      /* drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
        name={focused ? 'chart-area' : 'chart-bar'} />, */
    },
  },
  Stock: {
    //Title
    screen: Stock_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Stock',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'folder' : 'folder-open'} />, */
    },
  },
  CashFlows: {
    //Title
    screen: Screen4_StackNavigator,
    navigationOptions: {
      drawerLabel: 'CashFlows',
      /* drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
        name={focused ? 'columns' : 'book'} />, */
    },
  },
  Settings: {
    //Title
    screen: Screen5_StackNavigator,
    navigationOptions: {
      drawerLabel: 'Settings',
      /*  drawerIcon: ({ focused, color, size }) => <Icon color={focused ? 'brown' : 'purple'} size={25}
         name={focused ? 'toolbox' : 'tools'} />, */
    },
  },
},
  {
    //For the Custom sidebar menu we have to provide our CustomSidebarMenu
    contentComponent: CustomSidebarMenu,
    //Sidebar width
    drawerWidth: Dimensions.get('window').width - 100,
  }
);


/* const RoutesDrawer = createSwitchNavigator({
    //Loading: LoadingScreen,
    App: DrawerNavigatorExample,
},
{initialRouteName:'Login'}
);
//const Router = createAppContainer(DrawerNavigatorExample);
const Router = createAppContainer(RoutesDrawer);
export default Router; */
/* 
const LoginStackFlow = createStackNavigator({
  Last: {
    screen: Login,
    navigationOptions: ({ navigation }) => ({
      title: 'Login',
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
      headerMode:'none',
    }),
  },
  Home: {
    screen: DrawerNavigatorExample,}
},

// {initialRouteName:'Login'}
); */

const LoginStackFlow = createStackNavigator({
  Login: { screen: LoginScreen },

},
  {
    initialRouteName: 'Login',
    headerMode: 'none',
  }
);
const RoutesStack = createSwitchNavigator({
  //Loading: LoadingScreen,
  Auth: LoginStackFlow,
  App: DrawerNavigatorExample,
  Adm: DrawerNavigatorAdmin,
  Dep: DrawerNavigatorDepart,
},
  { initialRouteName: 'Auth' }
);
const TabOne_StackNavigator = createStackNavigator({
  //All the screen from the stock will be indexed here
  //Auth: LoginStackFlow,
  Home: HomeTab,
  Products: Products,
  ProductPage: ProductPage,
  Cart: Cart,
});
const BottomTabNavigator = createBottomTabNavigator({
  //Bottom Tab Options and indexing
  Horelo: {
    screen: TabOne_StackNavigator,
    navigationOptions: {
      //tabBarLabel: 'Home',
      tabBarIcon: ({ tintColor }) => (
        <Icons name="ios-home" color={tintColor} size={25} />
      )
    }
  }, 
  Micents:  {
    screen: RoutesStack,
  navigationOptions: {
    //tabBarLabel: 'Home',
    tabBarIcon: ({ tintColor }) => (
      <Icons name="ios-person" color={tintColor} size={25} />
    )
  }
},
},
  {
    navigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, horizontal, tintColor }) => {
        const { routeName } = navigation.state;
        let IconComponent = Icon;
        let iconName;
        if (routeName === 'Home') {
          iconName = focused
            ? 'toolbox' 
            : 'tools';
        
        } else if (routeName === 'Micents') {
          iconName = focused ? 'box' : 'cash';
        }

        // You can return any component that you like here!
        return <IconComponent name={iconName} size={25} color={tintColor} />;
      },
    }),
    tabBarOptions: {
      activeTintColor: 'teal',
      inactiveTintColor: 'purple',
    },
  }
);
const Router = createAppContainer(BottomTabNavigator);
export default Router;

