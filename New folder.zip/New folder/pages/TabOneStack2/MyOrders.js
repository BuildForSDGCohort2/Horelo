//This is an example code for NavigationDrawer//
import React, { Component, useState, useEffect } from 'react';
//import react in our code.
import { Alert, ActivityIndicator, Button, Image, ScrollView, StyleSheet, View,  FlatList, TouchableOpacity, TouchableHighlight } from 'react-native';
// import all basic components
import * as R from 'ramda';
import AsyncStorage from '@react-native-community/async-storage';
import {Text} from 'react-native-paper';
import createApolloClient from '../apollo';
import MyOrderButton from '../../components/MyOrderButton';
import { UserContext } from '../../App';
import MyButton from '../../components/MyButtons';
import { Query, Mutation } from 'react-apollo';
//import gql from 'graphql-tag';
import {gql, useMutation} from '@apollo/client';
import Modal from 'react-native-modal';


const GET_USER_ORDERS = gql`
query users_order_view{
  users_order_view(order_by:{name: desc})
      {
    completed
    orgid
    ready
    name
    trans_id
    logo
    sum
    count
  }
}`;
/* orders(where: {UserID: {_eq: $userId}},order_by:{createdAT: desc})
{
id
OrgID
comment
items
pdt_name
trans_id
amount
ready
readyAT
servedAT
servedBY
createdAT
} */
const MyOrders = ({ navigation }) => {
  React.useLayoutEffect(() => {
    navigation.setOptions({ 
        title: 'My Orders',
         });
}, [navigation]);

    const user_context = React.useContext(UserContext);
    const [userid, setUserId] = useState(user_context.userId);
    const [completed, setCompleted] = useState(null);
    const [trans_id, setTrans_id] = useState(null);
    const [orgid, setOrgid] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [reload, setReload] = useState(false);
    var id;
React.useEffect(()=>{},[reload]);
    const client = createApolloClient(user_context.token);
    const deliveredOrder = async () => {
      await client.mutate({
          mutation: gql`
      mutation ($completed: Boolean, $orgid: String, 
        $trans_id: String, $userid: String){
          update_orders (
          _set: { completed: $completed},
         where:{
             OrgID: {
                 _eq: $orgid
              },
              UserID:{
                _eq: $userid
              },
              _and: {trans_id: {_eq: $trans_id}}
          }

        ) {
          affected_rows
          returning{
              id
          }
        }
      }
    `  ,
          variables: {
            orgid,
            completed,
            trans_id, userid
          }
      }).then(console.log);
      /* }).then((result) => {
          console.log("graphql response", result);
          return result.data;
      }).catch((error) => {
          console.log("Graphql query error", error);

          let err = error;
          if (error.graphQlErrors && error.graphQlErrors.length > 0)
              err = error.graphQlErrors[0];
          throw err;
      }); */
      
  };
    
    
    function  compFalse(){
      Alert.alert(
        'Order Not Deliverd?',
        "Press Not if not delivered",
        [
          {
            text: 'not',
            onPress:()=>{setCompleted(false); deliveredOrder();setReload(!reload);}
          },
          {
            text: 'Cancel',
            onPress:()=>{}
          }
        ],
       
      )
    }
function  compTrue(){
  Alert.alert(
    'Order Deliverd?',
    "Press OHK if delivered",
    [
      {
        text: 'ohk',
        onPress:()=>{
          console.log(trans_id+" o "+ orgid+" c "+ completed+ " u "+ userid)
          setCompleted(true);
          deliveredOrder();setReload(!reload);}
      },
      {
        text: 'Cancel',
        onPress:()=>{}
      }
    ]
  )
}
    //  render() {
    return (<View style={styles.MainContainer}>
        
            <Query query={GET_USER_ORDERS} 
            
            fetchPolicy='cache-and-network'>
                {({ loading, error, data, refetch }) => {
                    if (loading) return <View styles={styles.activity}>
                        <ActivityIndicator size="large" color="#000ff" />
                    </View>
                    if (error) return <View style={{ marginLeft:10,}}>{console.log("my error gql " + error)}
                        <Text>Data loading error ${error.message} </Text></View>
console.log(data.users_order_view)
                    return (
                        <View>
                            <Text>User Orders</Text>
                            <View>
                            <FlatList
                                /* data={data.orders.filter((accepted) =>
                                    accepted.active === true && accepted.accepted === true)} */
                                    data={data.users_order_view.filter(compl=>
                                      compl.completed === null)}
                                   // horizontal={true}
                                   numColumns={2}
                                renderItem={({ item, index }) =>
                                    <View style={{ marginLeft:10,
                                        backgroundColor: index % 2 == 0 ? "#5d4c4f" : "#bababa"
                                    }} {...item}>
                                        <MyOrderButton {...item}
                                            logo={item.logo}
                                            title={item.name}
                                            items={item.count}
                                            total={(item.sum).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                                            status={item.ready}
                                            colorReady={item.ready?"white":"pink"}
                                            colorSeen={item.completed?"gray":'#456'}
                                            customClick={() => { navigation.navigate('Order',{order:item}) }}
                                            falseClick={()=>{setTrans_id(item.trans_id);
                                              setOrgid(item.orgid);
                                              setCompleted(false);
                                              compFalse();}}
                                            truthClick={()=>{setTrans_id(item.trans_id);
                                              setOrgid(item.orgid);
                                              setCompleted(true);
                                              compTrue();
                                            }}
                                        />
                                       
                                    </View>
                                }
                                ItemSeparatorComponent={()=><View paddingVertical={7}/>}
                                keyExtractor={item => item.toString()}
                                extraData={data.users_order_view}
                                refreshing={isLoading}
                  onRefresh={() => { refetch() }}
                            />
</View>
                            <Text>Old Orders</Text>
                            <View>
                            <FlatList
                            refreshing={isLoading}
                            onRefresh={() => { refetch() }}
                            data={data.users_order_view}
                                extraData={data.users_order_view.filter(comple=>
                                  !comple.completed == null)}
                                //horizontal={true}
                                numColumns={2}
                                renderItem={({ item, index }) =>
                                    <View style={{ marginLeft:10,
                                      backgroundColor: index % 2 == 0 ? "#4d4c4f" : "#bababa"
                                    }} {...item}>
                                      {item.completed !== null ?
                                         <MyOrderButton {...item}
                                            logo={item.logo}
                                            title={item.name}
                                            items={item.count}
                                            total={(item.sum).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                                            status={item.ready}
                                            customClick={() => { navigation.navigate('Order',{order:item}) }}

                                        />
                                        :
                                        <Text> No old items </Text>
                                      }

                                    </View>

                                }
                            />
                            </View>
                                 </View>
                    );
                }
                }
            </Query>
    </View>
    );
    // }
}

const styles = StyleSheet.create({
    activity: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
   
    MainContainer: {
        flex: 1,
        paddingHorizontal: 5,
        padding: 10,
       
    },
   
    
});
export default MyOrders;
