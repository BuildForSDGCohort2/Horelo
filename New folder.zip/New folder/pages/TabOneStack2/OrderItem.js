import React from 'react';
import { StyleSheet,  View } from 'react-native';
import {withNavigation} from 'react-navigation';
import {Text} from 'react-native-paper';

function OrderItem (){
    return (     
      <View style={styles.MainContainer}>
         <Text>Order</Text>
      </View>
    );
}
const styles = StyleSheet.create({
  MainContainer: {
    flex: 1,
    paddingTop: 20,
    alignItems: 'center',
    marginTop: 50,
    justifyContent: 'center',
  },
});
export default OrderItem;