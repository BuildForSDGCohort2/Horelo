import React, { useState, useEffect } from 'react';
import {
    Alert,
    KeyboardAvoidingView, SafeAreaView, TouchableOpacity, TouchableWithoutFeedbackBase,
    Button,
    FlatList,
    TextInput,
    Platform,
    ScrollView,
    StyleSheet,
    TouchableWithoutFeedback, TouchableHighlight,
    View, Keyboard, Dimensions
} from 'react-native';
import { Text } from 'react-native-paper';
import {Picker} from '@react-native-community/picker';
import Modal from 'react-native-modal';
import { categoriesTypes as types, incomeCategories, expenseCategories } from '../../assets/categories';
// import all basic components
import Mytextinput from '../../components/MyTextInput';
import SaveButton from '../../components/SaveButton';
import { UserContext } from '../../App';
import Ionicons from '@expo/vector-icons/Ionicons';
import Icon from '@expo/vector-icons/FontAwesome5';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { industryCategory, industries } from '../../assets/industries';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import { Dropdown } from 'react-native-material-dropdown';
import AsyncStorage from '@react-native-community/async-storage';
import { toUpper } from 'ramda';
import { acc } from 'react-native-reanimated';
import genId from '../../assets/getID';


const INSERT_TRANSACTION = gql`
  mutation ($orgID: String, $dept: String, $userId: String, $trans_id: String,
    $cashflow: String,$cashflow_id: Int, $accountID: Int, $amounts: numeric,
    $quantity: Int, $pdt_name: String,  $role: String ){
    insert_transactions  (
      objects: [{
        orgID: $orgID,
        dept: $dept,
        userID: $userId,
        account_id: $accountID,
        cashflow: $cashflow,
        amount: $amounts,
        items: $quantity,
        name: $pdt_name,
        role: $role,
        trans_id:$trans_id,
        cashflow_id:$cashflow_id,
      }]
    ){
      returning {
        id
        orgID
        dept
        userID
        account_id
        cashflow
        amount
        items
        name
      }
    }
  }
`;


//export default class App extends React.Component {
export default function AddTransaction({route, navigation }) {
    const [itemEdit, setItems] = useState({});
    const { cashF } = route.params;
    React.useLayoutEffect(() => {
    navigation.setOptions = {
        title: () => ({cashF}),
    };
},[navigation]);


    
    const user_context = React.useContext(UserContext);
    const [list, setList] = useState([]);

    const [pdt_name, setPdt_name] = useState('');
    const trans_id = genId();
    const [quantity, setQuantity] = useState(1);
    const [userId, setUserId] = useState(user_context.userId);
    const orgID = user_context.org_id;
    const role = user_context.role;
    const dept = user_context.dept_id;
    const [accountID, setAccountID] = useState(null);
    const [account, setAccount] = useState(null);
    const [accountList, setAccountList] = useState([]);
    const [productID, setProductID] = useState('');
    const [category, setCategory] = useState('');
    const [cashflow, setCashflow] = useState(cashF);
    const [cashIncome, setCashIncome] = useState([]);
    const [cashExpense, setCashExpense] = useState([]);
    const [cashflow_id, setCashflow_id] = useState('');
    const [cashflowList, setCashflowList] = useState([]);
    const [createdAT, setCreatedAT] = useState();
    const [amounts, setAmount] = useState(null);
    const [color, setColor] = useState("gray");
    const [selectedVal, setSelectedVal] = React.useState(null);
    const [newLabel, setNewLabel] = React.useState("now");

    const [selectedValue, setSelectedValue] = useState();
    let cashflowItem=[];
    let newList = [];
    var arr = [];

    useEffect(() => {
        //setItems(navigation.getParam('item'));
       /*  try
        {AsyncStorage.removeItem('accounts')
        alert("sucess")
      }
        catch(err){
          alert(err)
        }
        try
        {AsyncStorage.removeItem('cashflows')
        alert("sucess")
      }
        catch(err){
          alert(err)
        } */
            AsyncStorage.getItem('accountValues').then((result)=>{
                if(result !== null){
                    const accc =JSON.parse(result);
                    console.log(accc.map(item=>item.name) + " my accounts");
                    setAccountList(accc);
                    console.log(accountList.length +" my list length ") 
                } 
               
            }).catch((err)=>{
                alert(err)
              });
            AsyncStorage.getItem('cashFlowValues').then((result)=> {
                if(result !== null){
                    const accc =JSON.parse(result);
                    //console.log(accc.map(item=>item.name)+ "my cash flows")
                    const exp =accc.filter((item)=>
                        item.type !== 'income'
                    );
                    const inc =accc.filter((item)=>
                        item.type === 'income'
                    );
                    setCashIncome(inc);
                    setCashExpense(exp);
                    setCashflowList(accc); 
                    //console.log(cashflowList.length +" my list length ") 
                    console.log(cashF + " my param") 
                                    } 
            }).catch((err)=>{
                alert(err)
              });

    }, []);
       let accountValues = accountList.map((item, i)=>{
        return(
            <Picker.Item label={item.name}
            value={item.id} key={i}/>
            
           )
          // console.log(cashF + " my param") 
        }) 
        let cashflowExpense = cashExpense.map((item,index)=>{
            return(
                <Picker.Item label={item.name}
                value={item.id} key={index}/>
               )
            }) 
            let cashflowIncome = cashIncome.map((item,index)=>{
                return(
                    <Picker.Item label={item.name}
                    value={item.id} key={index}/>
                   )
                })  
    return (
        <SafeAreaView style={{ flex: 1 }}>
             <View style={{ fontSize:20, alignItems:'center', marginTop: 10 }}>
            <Text
            
            >{toUpper(cashF)}</Text>
            </View> 
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null} style={{ flex: 1 }}>
                
                <ScrollView>
                    {/* <Query query={GET_ProductCategories} fetchPolicy='cache-and-network'>
                        {({ loading, error, data }) => {
                            if (loading || error) return <View><Text>Data loading error Check Internet connectivity</Text></View>
                            return ( */}
                    
                    <Mutation
                        mutation={INSERT_TRANSACTION}
                        variables={{
                            orgID,
                            dept,
                            userId,
                            accountID,
                            cashflow,
                            cashflow_id,
                            amounts,
                            pdt_name,
                            trans_id,
                            quantity,
                            role
                        }}
                  
                    >
                        {

                            (insertTransactions, { loading, error }) => {
                                const submit = () => {
                                    if (error) {
                                        return <Text>${error.message} {console.log("my error gql " + error)}</Text>;
                                    }
                                    if (loading || list === []) {
                                        return;
                                    }
                                    //setTrans_id();
console.log(
    typeof orgID+" n "+
     dept+" nDept "+
     role+" nRole "+
    typeof  userId+" n "+
   typeof accountID+" num "+
   typeof  cashflow+" n "+
   typeof  cashflow_id+" num "+
   typeof  amounts+" n "+
   typeof pdt_name+" n "+
   typeof  trans_id+" n "+
   typeof  quantity )

                                   // insertTransactions();
                                    Alert.alert("transaction saved!");
                                  //  navigation.goBack();
                                    //setList([]);
                                }

                                return (

                                    <View style={styles.MainContainer}>
                                        <View style={{ width: 250, marginLeft: 10 }}>
                                 <Text>Please Select an cashFlow </Text>

                                 {
                                    cashF !== 'expense'?
                                  <Picker
                                  style={{color: "#fff", backgroundColor:'#635f'}}
                                    selectedValue={cashflow_id}
                                    onValueChange={(value)=>{console.log(value);setCashflow_id(value)}}
                                    label={"none"}>
                                {cashflowExpense}
                                </Picker>
                                :
                                <Picker
                                style={{color: "#fff", backgroundColor:'#39f6'}}
                                    selectedValue={cashflow_id}
                                    onValueChange={(value)=>{console.log(value);setCashflow_id(value)}}
                                    label={"none"}>
                                {cashflowIncome}
                                </Picker>
                                }
                                </View> 
                                        <View style={{ width: 250, marginLeft: 10 }}>
                                          
                                            <Text>Please Select an account </Text>
                                               <Picker
                                                style={{color: "#fff", backgroundColor:'#39f6'}}
                                    selectedValue={accountID}
                                    onValueChange={(value)=>{console.log(value);setAccountID(value)}}
                                    label={"none"}>
                                {   accountValues }
                                </Picker>  
                                    
                                  
                                        </View>

                                        <View paddingVertical={5} />
                                        
                                        <Mytextinput
                                            placeholder="Note / Description"
                                            onChangeText={(value) => { setPdt_name(value) }}
                                            style={{ padding: 10 }}
                                            multiline={true}
                                        />

                                        <View paddingVertical={5} />

                                        <Mytextinput
                                            placeholder="Amount"
                                            onChangeText={(value) => { setAmount(Number(value)) }}
                                            style={{ padding: 10 }}
                                            keyboardType={'numeric'}
                                        />


                                        <View paddingVertical={5} />
                                        <View style={styles.row}>
                                            <SaveButton
                                                title="SAVE"
                                                customClick={() => { submit(); }}
                                            />

                                        </View>
                                    </View>
                                );
                            }
                        }
                    </Mutation>

                    {/*    );
                        }
                        }
                    </Query> */}
                </ScrollView>
            </KeyboardAvoidingView>

        </SafeAreaView>
    );
    //}
}
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({

    MainContainer: {
        flex: 1,
        paddingHorizontal: 20,
        justifyContent: 'flex-end',
        width: 250,
        marginLeft: 10,
        marginTop: 10,
    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 3,
    },
    row: {
        marginRight: 3,
        marginBottom: 10,
    },
    textInput: {
        borderRadius: 15,
        marginRight: 3,
        width: 250,
        borderColor: '#000',
        backgroundColor: '#7ed',
        paddingLeft: 10,
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        //  marginRight:4,
    },
    icons: {
        fontSize: 30,
        color: 'white',
        marginLeft: 3,
        marginTop: 10,
    },
    incomecircle: {
        height: 50,
        width: 50,
        color: "#000",
        borderRadius: 35,
        backgroundColor: '#400f',
        marginTop: 2,
        marginBottom: 3,
    },

});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});