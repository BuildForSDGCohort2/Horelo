import React from 'react';
const listReducer = (state, action) => {
    switch (action.type) {
        case 'ADD_ITEM':
            return state.concat({ text: action.text, id: action.id });
        
        case 'UPDATE_ITEM':
            return state.map((item) => {
                if (item.id === action.id) {
                    const updatedItem = {
                        ...item,
                    };

                    return updatedItem;
                }

                return item;
            });

        case 'REMOVE_ITEM':
                return state.filter((item) => item.id !== action.id);

        default:
            throw new Error();
    }
};

export default listReducer;