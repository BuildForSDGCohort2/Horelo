import React from 'react';
import {
  ActivityIndicator,
  StyleSheet, Dimensions, Image, View, Text, TextInput, SafeAreaView, FlatList,
  ScrollView, TouchableHighlight, TouchableOpacity,
  Button
} from 'react-native';
import EmptyList from '../../components/EmptyList';
import { withNavigation } from 'react-navigation';
import moment from 'moment';
//import { AppContext } from '../Auth';
import { UserContext } from '../../App';
import * as SecureStore from 'expo-secure-store';
import uuid from 'react-native-uuid';
//import { v4 as uuidv4 } from 'uuid';
import Icon from '@expo/vector-icons/Foundation';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import MyButton from '../../components/MyButton';
import gql from 'graphql-tag';
import { Query, Mutation } from 'react-apollo';
import { FETCH_TODOS } from '../Queries';

let icon_name, name, items, createdAt, amount;
export const FETCH_TRANSACTIONS = gql`
query ($org_id: String!){
    transactions(where: {orgID:{_eq: $org_id}})
      {
        id
        orgID
        dept_id
        account_id
        product_id
        cashflow
        amount
        items
        name
        createdAT
        icon
      }
  }
`;

/* const INSERT_TODO = gql`

  mutation insert_todos($input: CreateTodosInput){
    insert_todos (
      input: $input
    ){
      returning {
        id
        text
        is_complete
      }
    }
  }
  input CreateTodosInput{
  text: String!
  userId: String!
}
`; */
const INSERT_TODOS = gql`
  mutation ($text: String!, $userId: String!){
    insert_todos (
      objects: [{
        text: $text,
        user_id: $userId,
      }]
    ){
      returning {
        id
        text
        is_complete
      }
    }
  }
`;
// 
const quotes = [
];

export const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Items',
    icons: 'plus',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63]5',
    title: 'Second Item',
    icons: 'plus',

  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
    icons: 'minus',

  },
  {
    id: '453694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
    icons: 'home',

  },
];

keyExtractor = (item, index) => index.toString();

function Item({ title, icons, id, icon, amount, name, createdAt, items }) {
  return (
    <View style={styles.item}>
      <View style={styles.circle}><POSIcon name={icon} style={styles.icons} /></View>
      <View style={styles.itemContainer}>
        <Text style={styles.title}>{name}</Text>
        <Text style={styles.subtitle2}>{items}</Text>
        <Text style={styles.subtitle3}>{createdAt}</Text>
      </View>
      <Text style={styles.subtitle4}>{amount}</Text>
    </View>
  );
}
function trans({ title, icons }) {
  return (
    <View style={styles.item}>
      <View style={styles.circle}><Icon name={"plus"} style={styles.icons} /></View>
      <View style={styles.itemContainer}>
        <Text style={styles.title}>{text}</Text>
        <Text style={styles.subtitle2}>{text}2</Text>
        <Text style={styles.subtitle3}>{text}3</Text>
      </View>
      <Text style={styles.subtitle4}>{text}4</Text>
    </View>
  );
}

function Admin({ navigation }) {
  const Dcontext = React.useContext(UserContext);
  const [text, setText] = React.useState(null);
  const [userId, setUserID] = React.useState(null);
  const [org_id, setOrg_id] = React.useState(Dcontext.org_id);
  const [list, setList] = React.useState(quotes);


  //const Acontext = React.useContext(AppContext);
  //console.log(Dcontext + "my user context"  );
  /*  useEffect(() => {
     let isMounted = true;
     asyncFn().then(data => {
       if (isMounted) onSuccess(data);
     });
     return () => { isMounted = false };
   }, [asyncFn, onSuccess]); */
  const getuserID = async () => {
    try {
      const res = await SecureStore.getItemAsync('MySecureAuthStateKey');
      if (res !== null) {
        const detail = JSON.parse(res);
        const { id } = detail;
        setUserID(id);
      }
    } catch (error) {
      // Error retrieving data
    }
  };
  function handleAdd() {
    // add item
    const newList = list.concat({ text, id: uuid.v4() });
    //const newList = list.concat({ text, id: 11 });
    //dispatchList({ type: 'ADD_ITEM', text, id: 12 });

    setList(newList);
    console.log(newList);
    setText(null);
  }

  return (
    <View style={{ flex: 1 }}>
      <SafeAreaView>
        <Mutation
          mutation={INSERT_TODOS}
          variables={{
            text,
            userId,
          }}
          update={(cache, { data: { insert_todos } }) => {
            const data = cache.readQuery({
              query: FETCH_TODOS,
            });
            const newTodo = insert_todos.returning[0];
            const newData = {
              todos: [newTodo, ...data.todos]
            }
            cache.writeQuery({
              query: FETCH_TODOS,
              data: newData
            });
          }}
        >
          {
            (insertTodo, { loading, error }) => {
              const submit = () => {
                if (error) {
                  return <Text> Error </Text>;
                }
                if (loading || text === '') {
                  return;
                }
                console.log(" my id " + userId + " ");
                setText('');
                insertTodo();//
              }

              return (
                <View style={styles.inputContainer}>
                  <View style={styles.textboxContainer}>
                    <TextInput
                      style={{ borderColor: '#000', height: 40, backgroundColor: '#123123', width: 250, margin: 10, color: '#fff' }}
                      editable={true}
                      onChangeText={(value) => { setText(value); getuserID() }}
                      value={text}
                    />
                  </View>
                  <View style={styles.buttonContainer}>
                    <TouchableOpacity >
                      <Text style={{ borderColor: '#1414', height: 40, backgroundColor: '#123123', width: 50, margin: 10, color: '#fff' }}
                        onPress={() => submit()}
                        disabled={text === ''}> Add </Text>
                    </TouchableOpacity>
                  </View>

                </View>
              );
            }
          }
        </Mutation>

        <View style={styles.list}>
          <Query query={FETCH_TRANSACTIONS} variables={{ org_id }} fetchPolicy='cache-and-network'>
            {({ loading, error, data }) => {
              if (loading) return <View styles={styles.activity}>
                <ActivityIndicator size="large" color="#000ff" />
              </View>
              if (error) return <View>{console.log("my error gql " + error)}
                <Text>Data loading error ${error.message} org id is ${org_id}</Text></View>
              return (
                <View><Text>Org Admin</Text>
                <FlatList
                  data={data.transactions}
                  ListEmptyComponent={<EmptyList containerStyle={{ width: 300, }} />}
                  renderItem={({ item, index }) =>
                    <View style={{
                      backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#ff8dff"
                    }} {...item} key={item.id}>
                      {console.log(item.icon)}

                      <TouchableHighlight
                        style={styles.icon_button}
                        underlayColor="#ccc"
                        onPress={() => { alert("hi here " + item.icon); }
                        }
                      >
                        <Item name={item.name} createdAt={moment(item.createdAT).format('MMM Do YYYY, h:mm:ss a')} items={item.items}
                          amount={Number(item.amount)
                            .toFixed(2)
                            .replace(/\d(?=(\d{3})+\.)/g, '$&,')} icon={item.icon} id={item.id} />
                      </TouchableHighlight>
                    </View>}
                  // renderItem={({ item, index }) => <View style={styles.itemContainer, { backgroundColor: index % 2 == 0 ? "#f4d4b4" : "#fdfdfd"}}>
                  //   <Text style={styles.item}>{item.title} {item.icons}</Text>
                  //   <View style={styles.circle }><Icon name={item.icons} style={styles.icons} /></View>
                  //  </View>
                  //  }
                  keyExtractor={item => item.id.toString()}
                />
</View>
              );
            }
            }
          </Query>
        </View>
        {/* <FlatList
            data={DATA}
            renderItem={({ item, index }) => 
            <View style={ { 
              backgroundColor: index % 2 == 0 ? "#f4d4c4" : "#ff8dff" 
              }}>
                <TouchableHighlight
                  style={styles.icon_button}
                  underlayColor="#ccc"
                  onPress={() => { alert("hi here " + item.icons ); }
                  }
                >
            <Item title={item.title} icons={item.icons} /> 
            </TouchableHighlight>
            </View>}   
           // renderItem={({ item, index }) => <View style={styles.itemContainer, { backgroundColor: index % 2 == 0 ? "#f4d4b4" : "#fdfdfd"}}>
           //   <Text style={styles.item}>{item.title} {item.icons}</Text>              
           //   <View style={styles.circle }><Icon name={item.icons} style={styles.icons} /></View>
          //  </View>
          //  }             
            keyExtractor={item => item.id}
          />  
 */}

      </SafeAreaView>
      <MyButton />

    </View>
  );
}
/*  

  }
} */
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
  MainContainer: {
    flex: 1,
    paddingTop: 5,
    //alignItems: 'center',
    marginTop: 20,
    //justifyContent: 'center',
  },
  item: {
    flexDirection: 'row',
    padding: 2,
    marginLeft: 2,
  },
  itemContainer: {
    //flexDirection: "row-reverse",
    //flex: 1,
    //alignContent: 'space-around',
    marginStart: 10,
  },

  subtitle4: {
    fontSize: 24,
    fontWeight: 'bold',
    //marginLeft: vw * 0.1,
    //paddingRight:5,
    marginTop: 14,
  },
  subtitle3: {
    fontSize: 14,
    //marginEnd: 10,
    opacity: 0.5,
    fontWeight: 'bold',
  },
  subtitle2: {
    marginLeft: 0,
    fontSize: 12,
    fontWeight: 'bold',
    opacity: 0.5,
  },
  icons: {
    fontSize: 40,
    color: 'white',
  },
  circle: {
    height: 50,
    width: 50,
    color: "#000",
    borderRadius: 35,
    borderTopLeftRadius: 35,
    borderTopRightRadius: 35,
    borderBottomLeftRadius: 35,
    borderBottomRightRadius: 35,
    backgroundColor: '#002f32',
    alignItems: 'center',
    justifyContent: 'center'
  },
  //for the coffee
  container: {
    height: vh,
    width: vw,
    backgroundColor: '#fdfdfd'
  },
  header: {
    width: vw,
    height: vw / 1.6,
    resizeMode: 'contain'
  },
  title: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 21,
    color: '#252525'
  },
  subtitle: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#bf200b'
  },

  block: {
    flex: 1,
    height: vh / 4,
    margin: vw / 40
  },
  productImage: {
    width: '100%',
    height: vh / 7,
    resizeMode: 'contain',
    backgroundColor: '#ffffff'
  },
  name: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#252525',
    width: '80%',
    marginTop: 15
  },
  price: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#bf200b',
    marginTop: 7
  },
  list: {
    height: vh * 0.4,
    marginTop: vh / 40,
    marginBottom: 0.5,
  },

  slide1: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9DD6EB'
  },
  slide2: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#97CAE5'
  },
  slide3: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#92BBD9'
  },
  text: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold'
  },
});
export default withNavigation(Admin);