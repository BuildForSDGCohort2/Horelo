/*jshint -W033 */

import  React,{useEffect, useState} from 'react';
import { View, StyleSheet, Image, Text, TouchableOpacity, Dimensions } from 'react-native';

const vh = Dimensions.get('screen').height;
const vw = Dimensions.get('screen').width;

FirstStack.navigationOptions = {
  title: 'Demo First Stack',
};
export default function FirstStack({ navigation }){
  const [item, setItem] = useState({});

  useEffect(()=> {
    setItem(navigation.getParam('item'));
  },[]);

  /* constructor(props) {
    super(props); 
  this.state = { item: {} }
  this.state = { item: {} }
  }
  componentDidMount() {
    this.setState({
      item: this.props.navigation.getParam('item')
    });
  }

  render() {
    */
    return (
      <View style={styles.container}>
        {console.log(item + " my item")}
        {console.log(item.color + " my item color")}
        {console.log(navigation.getParam('item') +" my grapgh")}
        <View style={{ ...styles.backgroundFill, backgroundColor: item.color }} />
        <Image style={styles.productImage} source={{ uri: item.taskImage }} />
        <View style={styles.details}>
          {/* <Text style={styles.title}>{item.user.name}</Text> */}
          <Text style={styles.subtitle}>{item.task}</Text>
          
           <Text style={styles.description}>Lorem ipsum dolor.</Text>
          {/* <Text style={styles.detail}>{`BLEND TYPE: ${item.id}`}</Text> */}
        </View>
      </View>
    );
  }
//}



const styles = StyleSheet.create({
  container: {
    height: vh,
    width: vw,
    backgroundColor: '#fdfdfd'
  },
  backButton: {
    position: 'absolute',
    top: vh / 18,
    left: vw / 30,
    zIndex: 10,
    width: 50,
    height: 50,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  backText: {
    fontFamily: 'maven-pro-bold',
    fontSize: 23,
    color: '#fff',
  },
  backgroundFill: {
    width: '100%',
    height: vh / 3.2
  },
  productImage: {
    width: '100%',
    height: vh / 2.7,
    resizeMode: 'contain',
    position: 'absolute',
    top: vh / 14
  },
  details: {
    margin: 50,
    position: 'absolute',
    top: vh / 2.5
  },
  title: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 14,
    color: '#252525'
  },
  subtitle: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 14,
    color: '#bf200b',
    marginTop: 10
  },
  description: {
    fontFamily: 'maven-pro-regular',
    fontSize: vw / 22,
    color: '#4c4c4c',
    marginTop: 20
  },
  detail: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#bf200b',
    marginTop: 20
  },
});
 

/*
//This is an example code for NavigationDrawer//
import React, { useState, useEffect } from 'react';
//import react in our code.
import { StyleSheet, ScrollView, View, Text, KeyboardAvoidingView, SafeAreaView } from 'react-native';
import { useHeaderHeight } from 'react-navigation-stack';

// import all basic components
import MyTextInput from '../../components/MyTextInput';
import MyButtons from '../../components/MyButtons';

import gql from 'graphql-tag';
export const Headlines = gql` 
  query TopHeadlines {
    headlines
      @rest(
        type: "HeadlinesPayload"
        path: "top-headlines?country=us&category=technology"
      ) {
      totalResults
      articles @type(name: "ArticlePayload") {
        title
        publishedAt
        url
        urlToImage
        source @type(name: "SourcePayload") {
          name
        }
      }
    }
}`;
FirstStack.navigationOptions = {
  title: 'Demo First Stack',
};
export default function FirstStack({ navigation }) {
  //Screen1 Component

  return (
    <ScrollView>
      <KeyboardAvoidingView keyboardVerticalOffset={useHeaderHeight} style={styles.flex} behavior='height'>
        <SafeAreaView style={styles.flex}>

          <View style={styles.MainContainer}>
            <MyTextInput
              placeholder="Enter Name"
              onChangeText={(value) => setUser_name(value)}
              style={{ padding: 10 }}
            />
            <MyTextInput
              placeholder="Enter Contact No"
              onChangeText={(value) => setUser_contact(value)}
              maxLength={10}
              keyboardType="numeric"
              style={{ padding: 10 }}
            />
            <MyTextInput
              placeholder="Enter Address"
              onChangeText={(value) => setUser_address(value)}
              maxLength={225}
              numberOfLines={10}
              multiline={true}
              style={{ textAlignVertical: 'top', padding: 10 }}
            />
             <MyButtons
              title="Submit"
              customClick={
                // this.add.bind(this)
                }
            /> 
             <MyButtons
              title="Demo Back First"
              customClick={() => this.props.navigation.navigate('First')}
            /> 
            <MyButtons
              title="Demo Back First"
              customClick={() => navigation.navigate('First')}
            />
            <MyButtons
              title="POS"
              customClick={() => navigation.navigate('AddPOS')}
            />
          </View>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1
  },
  MainContainer: {
    flex: 1,
    paddingTop: 20,
    alignItems: 'center',
    marginTop: 50,
    justifyContent: 'flex-start',
  },
}); */