/*jshint -W033 */

import React, { useState, useEffect } from 'react';
//import react in our code.
import { Alert,TextInput, FlatList,Dimensions, StyleSheet, Button, ScrollView, View, KeyboardAvoidingView, SafeAreaView, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { useHeaderHeight } from '@react-navigation/stack';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import ListItem, { Separator } from './ListItem';
import EmptyList from '../../components/EmptyList';
import { Asset, Constants, FileSystem, Permissions } from 'react-native-unimodules';
// import all basic components
import createApolloClient from '../apollo';
import MyTextInput from '../../components/MyTextInput';
import MyButtons from '../../components/MyButtons';
import MyText from '../../components/MyText';
import { BarCodeScanner } from 'expo-barcode-scanner';
import Modal from 'react-native-modal';
import InputSpinner from "react-native-input-spinner";
import gql from 'graphql-tag';
import { Mutation } from 'react-apollo';
import { UserContext } from '../../App';
import genId from '../../assets/getID';
import dateTime from '../../assets/getTS';
import AsyncStorage from '@react-native-community/async-storage';
import Autocomplete from 'react-native-autocomplete-input';

const INSERT_TRANSACTION = gql`
  mutation ($orgID: String, $deptID: String, $userId: String, $trans_id: String,
    $cashflow: String, $accountID: Int, $amounts: numeric,
    $quantity: Int, $pdt_name: String,  $role: String ){
    insert_transactions  (
      objects: [{
        orgID: $orgID,
        dept: $deptID,
        userID: $userId,
        account_id: $accountID,
        cashflow: $cashflow,
        amount: $amounts,
        items: $quantity,
        name: $pdt_name,
        role: $role,
        trans_id:$trans_id,
      }]
    ){
      returning {
        id
        orgID
        dept
        userID
        account_id
        cashflow
        amount
        items
        name
      }
    }
  }
`;

let trans = [];

export default function AddPOS({ navigation }) {
    const user_context = React.useContext(UserContext);
    const client = createApolloClient(user_context.token);
    var trans_id = "";
    const [pdtID, setPdtID] = useState();
    const [list, setList] = React.useState(trans);
    const [priceList, setPriceList] = React.useState(trans);
    const [text, setText] = React.useState([]);
    const [hasPermission, setHasPermission] = useState(null);
    const [scanned, setScanned] = useState(null);
    const [barcodeItem, setBarcodeItem] = useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const [pdt_name, setPdt_name] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [price, setPrice] = useState(0);
    const [amounts, setAmount] = useState(0);
    const [index, setNum] = useState(1);
    const [clicked, setClicked] = useState(false);
    const [querySections, setQuerySections] = useState('');

    const orgID = user_context.org_id;
    const [deptID, setDeptID]= useState(user_context.dept_id);
    const userId = user_context.userId;
    const role = user_context.role;
    const [accountID, setAccountID] = useState(3);
    const [productID, setProductID] = useState();
    const [cashflow, setCashflow] = useState("pos");
    const [totals, setTotals] = useState(0);
    const [createdAT, setCreatedAT] = useState();
    var [show, setShow] = useState(false);
    var [showPdtName, setShowPdtName] = useState(false);
    var amountss=0;
    var pdt_names="none";
    var trans_ids="none";
    var quantitys=1;

    React.useLayoutEffect(() => {
        navigation.setOptions({ 
            title: 'POS',
            tabBarVisible:false,
            headerRight: () => (
                <Text 
               
                style={[{ fontFamily: 'maven-pro-bold', fontSize: 24, marginBottom: 1,marginRight: 10, }]}>
                Ttl: {(totals).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
            </Text>
        ), });
    }, [totals]);

    useEffect(() => {
        
     try {
        AsyncStorage.getItem('priceList', (err, result) => {
            result !== null ? 
            setPriceList(JSON.parse(result)) :
            setPriceList([]);
        });}catch(error){
            console.log(error)
        }
        (async () => {
            const { status } = await BarCodeScanner.requestPermissionsAsync();
            setHasPermission(status === 'granted');
        })();
    }, []);

    const handleBarCodeScanned = ({ type, data }) => {
        setScanned(true);
        setBarcodeItem(data);
        //handleSearch(data);
        // Alert.alert('Bar code with type ${type} and  ${data} has been captured');
        setScanned(null);
        setModalVisible(!modalVisible);
    };
    function findSection(querySections) {
        if (querySections === '') {
            return [];
        }
        const regex = new RegExp(`${querySections.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&').trim()}`, 'ig');
        return priceList.filter(sectionCollect => sectionCollect.name.search(regex) >= 0);
    }
    var fSections = findSection(querySections);
    const comp = (a, b) => a.toLowerCase().trim() === b.toLowerCase().trim();

    //if (hasPermission === null) {
    //    return (<Text> Requesting for camera permission</Text>);
   // }
    if (hasPermission === false) {
        return <Text>No access to camera</Text>
    }
    function ItemPrice(value) {
        let val = value.toLocaleString('000');
        setPrice(val);
    }
    function ItemName(value) {
        let val = value.toLocaleString('000');
        setPdt_name(val);

    }
    function amountPaid() {
        if (quantity !== null && price !== null) {
            return 1 * price * quantity;
        }
    }
    function itemPlaceholder() {

        return 'Item Name';
    }
    const format = amount => {
        setAmount(price * quantity * 1);
        return Number(amount)
            .toFixed(2)
            .replace(/\d(?=(\d{3})+\.)/g, '$&,');
    };



    function genID() {
        // track input field's state
        setProductID(genId());
    }
    function cashflowList(value) {
        setCashflow(value);
    }
    function handleAdd() {
        const newList = list.concat({ pdt_name, amounts, quantity, price, id: genId() });
        let num = newList.reduce((acc, cart) => {
            return acc + cart.amounts;
        }, 0);
        setTotals(num);
        setList(newList);
        setBarcodeItem(null);
        setPdt_name(null);
        setAmount(0);
        setQuantity(1);
        setPrice(0);
        setQuerySections('');
        }
    function handleEdit(pdtID) {
        const newList = list.map(item =>
            item.id !== pdtID ? item : {
                ...item,
                pdt_name: pdt_name,
                amounts: amounts,
                quantity: quantity,
                price: price,
            }
        );
        setList(newList);
        let num = newList.reduce((acc, cart) => {
            return acc + cart.amounts;
        }, 0);
        setTotals(num);
        setBarcodeItem(null);
        setPdt_name(null);
        setAmount(0);
        setQuantity(1);
        setQuerySections('');
        setPrice(0);
    }
    function handleDel(id) {
        const newList = list.filter((item) => item.id !== id);
        setList(newList);
        let num = newList.reduce((acc, cart) => {
            return acc + cart.amounts;
        }, 0);
        setTotals(num);
    }
    function handleSearch(barcodeItem) {
        priceList.filter(item => {
            item.pdt_barcode !== barcodeItem ? item :
            setPrice(item.price)
            setPdt_name(item.pdt_name)
            setShowPdtName(true)
            setProductID(item.id)
        }
        )
    }
    const  onTransaction= async () => {
          console.log(
             amountss+" na "+
     pdt_names+" np "+
     trans_ids+" nt "+
    quantitys
            ) ; 
           /*  console.log(i +" num "+obj.name+" num "+ obj.amount+" num "+orgID+" n "+
            deptID+" n "+
            userId+" n "+
            accountID+" n "+
            cashflow+" n "+
            amounts+" n 0 Amount "+
            pdt_name+" null pdt_name "+
            trans_id+" n "+
            quantity+" n "+
            role) ; */ 
      
            await client.mutate({
            mutation: gql`
            mutation ($orgID: String!, $deptID: String!, $userId: String!, $trans_id: String!,
                $cashflow: String!, $accountID: Int, $amounts: numeric!,
                $quantity: Int!, $pdt_name: String!,  $role: String!){
                insert_transactions  (
                  objects: [{
                    orgID: $orgID,
        dept: $deptID,
        userID: $userId,
        account_id: $accountID,
        cashflow: $cashflow,
        amount: $amounts,
        items: $quantity,
        name: $pdt_name,
        role: $role,
        trans_id:$trans_id,
                  }]
                ){
                  returning {
                    id
                    orgID
                    dept
                    userID
                    account_id
                    cashflow
                    amount
                    items
                    name
                  }
                }
              }
         `  ,
            variables: {
                orgID,
                deptID,
                userId,
                accountID,
                cashflow,
                amounts:amountss,
                pdt_name:pdt_names,
                trans_id,
                quantity:quantitys,
                role,
            }
        }).then(result=>{
            Alert.alert("transaction saved!");
            console.log
        }); 
   
    };
    return (
        <SafeAreaView style={styles.flex}>
            <Mutation
                mutation={INSERT_TRANSACTION}
                variables={{
                    orgID,
                    deptID,
                    userId,
                    accountID,
                    cashflow,
                    amounts,
                    pdt_name,
                    trans_id,
                    quantity,
                    role,
                }}
            
            >
                {

                    (insertTransactions, { loading, error }) => {
                        const submit = () => {
                            if (error) {
                                return <Text>${error.message} {
                                    console.log("my error gql " + error)}</Text>;
                            }
                            if (loading || list === []) {
                                return;
                            }


                            list.map((obj, i) => {
/* console.log(obj.amounts);
console.log(obj.pdt_name);
console.log(obj.quantity); */
                                amountss=obj.amounts;
                                pdt_names=obj.pdt_name;
                                 trans_ids=genId();
                                 quantitys=obj.quantity; 
                                 deptID ==null ? deptID : setDeptID('none');
                                   /* setAmount(obj.amounts);
                                 setPdt_name(obj.pdt_name);
                                 setQuantity(obj.quantity);   */
                                 console.log(user_context.dept_id)
                                 console.log(deptID)
                                 console.log(user_context.role)
                                 console.log(user_context.org_id)
                                 // trans_ids=genId();
                                onTransaction();
                            });
                            // insertTransactions();
                            Alert.alert("transaction saved!");
                            setList([]);
                        }
                        return (
                            <View style={{marginBottom:vh / 40 }}>
                                <ScrollView>
                                    <KeyboardAvoidingView keyboardVerticalOffset={useHeaderHeight} style={styles.flex} behavior='height'>

                                        <View style={styles.MainContainer}>
                                            <View style={styles.rowItem}>
                                            <TouchableOpacity
                                                    onPress={() => { setModalVisible(true) }}>
                                                    {/* <Text style={styles.circle} />  */}
                                                    <View style={styles.circle}>
                                                        <POSIcon name='barcode' style={styles.icons} />
                                                    </View>
                                                </TouchableOpacity>
                                                {barcodeItem ? handleSearch(barcodeItem) : null}
                                                {showPdtName && priceList==null ?
                                                    <MyTextInput
                                                        //editable={false}
                                                        placeholder={itemPlaceholder()}
                                                        value={pdt_name}
                                                        onChangeText={(value) => { setPdt_name(value) }}
                                                        style={{ padding: 10 }}
                                                    /> :
                                                    <View style={{ flex: 1, top: 15 }}>
                                                        <View style={styles.autocompleteContainer}>
                                                            <Autocomplete
                                                                autoCapitalize='sentences'
                                                                autoCorrect={false}
                                                                data={clicked || fSections.length === 1 && comp(querySections, priceList[0].name) ? [] : fSections}
                                                                defaultValue={querySections}
                                                                onChangeText={(text) => { setQuerySections(text); setClicked(false);setPdt_name(text) }}
                                                                onPress={() => setClicked(true)}
                                                                placeholder="Enter the Product Name"
                                                                renderItem={({ item }) => (
                                                                    <TouchableOpacity onPress={() => {
                                                                        setClicked(true);
                                                                        setQuerySections(item.name);
                                                                        setPdt_name(item.name);
                                                                        
                                                                        setPrice(item.price)
                                                                        setAmount(item.price * quantity);
                                                                        setProductID(item.id);
                                                                    }}>
                                                                        <Text style={styles.text}>
                                                                            {item.name}  {item.quantity}_({item.units})</Text>
                                                                    </TouchableOpacity>
                                                                )}
                                                            />
                                                        </View>
                                                    </View>
                                                }
                                                <TouchableOpacity
                                                    onPress={() => { setPdt_name(null); setShowPdtName(true); setBarcodeItem(null); }}>
                                                    {/* <Text style={styles.circle} />  */}
                                                    <View style={styles.circle}>
                                                        <POSIcon name='edit' style={styles.icons} />
                                                    </View>
                                                </TouchableOpacity>
                                            </View>
                                            <View paddingVertical={1} />

                                            <Modal
                                                animationType='slide'
                                                transparent={false}
                                                visible={modalVisible}
                                                onRequestClose={() =>
                                                    Alert.alert("modal has closed")}>
                                                <View style={styles.BarCodeContainer}>
                                                    <Text>{pdt_name}</Text>

                                                    <BarCodeScanner
                                                        onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
                                                        style={StyleSheet.absoluteFillObject}
                                                    >

                                                    </BarCodeScanner>
                                                    {scanned && <Button title={'tap to scan again'}
                                                        onPress={() => setScanned(false)} />}

                                                </View>
                                                <Button style={{ marginBottom: 20 }} title="Cancel" onPress={() => { setModalVisible(!modalVisible) }} />

                                            </Modal>

                                            <Text>
                                                No. of Items:
                        </Text>

                                            <InputSpinner
                                                max={1000}
                                                step={1}
                                                type={'float'}
                                                colorMax={"#f04048"}
                                                colorMin={"#40c5f4"}
                                                value={quantity}
                                                //value={this.state.number}
                                                onChange={(num) => {
                                                    setQuantity(num);
                                                    setAmount(1 * num * price);
                                                }}
                                            />
                                            <View paddingVertical={1} />
                                            <Text style={styles.text}>Price</Text>
                                            
                                            <View style={styles.rowItem}>
                                                <MyTextInput
                                                    placeholder="1000"
                                                    onChangeText={(text) => {
                                                        /* 
                                                        var regExpr = new RegExp("^[0-9,\b][0-9,\b]*$");
                                                        value= regExpr.test(value); */
                                                        setPrice(text);
                                                        setAmount(1 * quantity * text);
                                                    }}
                                                    keyboardType="numeric"
                                                    style={{fontSize:30
                                                       }}
                                                    value={String(Number(price))}
                                                />
                                                <TouchableOpacity
                                                    onPress={() => { setPrice(null) }}>
                                                    {/* <Text style={styles.circle} />  */}
                                                    <View style={styles.circle}>
                                                        <POSIcon name='edit' style={styles.icons} />
                                                    </View>
                                                </TouchableOpacity>
                                            </View>
                                            <View paddingVertical={2} />
                                            <Text>
                                                Total Amount:
                        </Text>
                                            <View style={styles.rowItem}>
                                                <MyTextInput
                                                    style={{fontSize:30, fontFamily: 'LovingYou'
                                                    }}
                                                    value={String((Number(amounts)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','))}
                                                    // onChangeText={() => setAmount(price * quantity)}
                                                    editable={false}
                                                    onFocus={false}
                                                />
                                                <TouchableOpacity>
                                                    <View style={styles.circle}>
                                                        <POSIcon name='calculator' style={styles.icons} />
                                                    </View>
                                                </TouchableOpacity>
                                            </View>
                                            <View paddingVertical={5} paddingHorizontal={20} style={styles.rowItem}>
                                                <MyButtons
                                                    title="Save Items"
                                                    customClick={() => { 
                                                        /* console.log(pdt_name+" n "+
                                                                        price +" n "+ amounts
                                                                        ); */
                                                                    trans_id=genId();
                                                                    //setProductID(genId()); 
                                                                    submit(); 
                                                    }}
                                                    style={{ height: 40, marginTop: 10 }}
                                                />
                                                <View paddingHorizontal={50} />

                                                {show ?
                                                    <MyButtons
                                                        style={{ height: 45, width: 100, backgroundColor: 'teal' }}
                                                        title="Update Item"
                                                        customClick={() => {
                                                            setShow(false);
                                                            handleEdit(pdtID);
                                                        }}
                                                    />
                                                    :
                                                    <TouchableOpacity
                                                        onPress={() => { handleAdd() }}>
                                                        <View style={[styles.circle, { height: 45, backgroundColor: 'blue' }]}>
                                                            <POSIcon name='cart-plus' style={[styles.icons, { color: "#9fff" }]} />
                                                        </View>
                                                    </TouchableOpacity>
                                                }
                                            </View>

                                        </View>
                                    </KeyboardAvoidingView>
                                </ScrollView>
                                <View style={styles.container}>
                                    {/* <Text style={{
                                                color: '#4a4a4a',
                                                fontSize: 15,
                                                margin: 3,
                                            }}>No. </Text> */}
                                    <Text style={styles.textOut}>Name</Text>
                                    <Text style={{
                                        color: '#4a4a4a',
                                        fontSize: 15,
                                        marginLeft: 5,
                                        marginTop: 5,
                                        fontWeight: 'bold',
                                    }}>QTY</Text>
                                    <Text style={styles.price}>Price</Text>
                                    <Text style={[styles.price, { marginLeft: 10, color: '#6cc', }]}>Amount</Text>
                                </View>
                                <View style={{height: vh * 0.225,marginBottom: 40}}>
                                <FlatList
                                    data={list}
                                    extraData={list}
                                    renderItem={({ item, index }) => (
                                        <ListItem
                                            {...item}
                                            onRightPress={() => {
                                                setPdtID(item.id); setShow(true); setBarcodeItem(barcodeItem)
                                                setPdt_name(item.pdt_name);
                                                setAmount(item.amounts);
                                                setQuantity(item.quantity);
                                                setPrice(item.price); 
                                            }}
                                            onSwipeFromLeft={() => handleDel(item.id)}

                                        //onRightPress={() => alert('swiped from left!')}
                                        //onRightPress={(onPress2) => alert('swiped from right!')}
                                        //onPress={()=>()}
                                        />

                                    )}
                                    renderHeader={() => {
                                        return (<View>{/* <SearchBar placeholder="Type here item" /> */}</View>)
                                    }}
                                    ItemSeparatorComponent={() => <Separator />
                                    }
                                    keyExtractor={(item, index) => item.id.toString()}
                                    ListEmptyComponent={<EmptyList containerStyle={{ width: 300, }} />}
                                />
                                </View>
                            </View>
                        );
                    }
                }
            </Mutation>

        </SafeAreaView>

    );
}
//

const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;
const styles = StyleSheet.create({
    autocompleteContainer: {
        flex: 1,
        left: 5,
        position: 'absolute',
        right: 0,
        top: 0,
        zIndex: 1, width: 200
    },
    flex: {
        flex: 1
    },
    MainContainer: {
        flex: 1,
        alignItems: 'center',
        marginTop: 5,
        justifyContent: 'flex-start',
    },
    BarCodeContainer: {
        flex: 1,
        alignItems: 'center',
        margin: 20,
        justifyContent: 'flex-start',

    },
    rowItem: {
        flexDirection: 'row',
        marginLeft: 12,
    },
    text: {
        paddingLeft: 10,
        marginLeft: 5,
        marginRight: 10,
        marginTop: 5,
        borderColor: '#007FFF',
        width: 150,
        borderRadius: 35,
    },
    circle: {
        height: 50,
        width: 50,
        borderRadius: 35,
        backgroundColor: '#000',
        alignItems: 'center',
        marginTop: 10,
        justifyContent: 'center',
    },
    icons: {
        fontSize: 30,
        color: 'white',
    },
    container: {
        backgroundColor: '#fff',
        paddingHorizontal: 10,
        paddingVertical: 2,
        flexDirection: 'row',

    },
    textOut: {
        color: '#4a4a4a',
        fontSize: 15,
        margin: 5,
        width: 80,
        fontWeight: 'bold',
        marginRight: 3,
    },
    price: {
        color: '#9a4a4a',
        fontSize: 15,
        margin: 5,
        paddingLeft: 15,
        width: 80,
        fontWeight: 'bold',
        marginLeft: 10,
    },
});
const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        fontSize: 16,
        paddingVertical: 12,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
    inputAndroid: {
        fontSize: 16,
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderWidth: 0.5,
        borderColor: 'purple',
        borderRadius: 8,
        color: 'black',
        paddingRight: 30, // to ensure the text is never behind the icon
    },
});