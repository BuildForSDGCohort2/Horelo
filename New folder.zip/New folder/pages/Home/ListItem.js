import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Animated,
    TouchableOpacity,
} from 'react-native';
import Swipeable from 'react-native-gesture-handler/Swipeable';
//import { GestureHandler } from 'expo';
//const { Swipeable } = GestureHandler;

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        paddingHorizontal: 5,
        paddingVertical: 2,
        flexDirection: 'row',

    },
    text: {
        color: '#4a4a4a',
        fontSize: 15,
        margin: 5,
        width: 80,
        marginRight:1,
    },
    price: {
        color: '#9a4a4a',
        fontSize: 15,
        
        margin: 5,
        marginLeft:1,
        width: 80,
        fontWeight:'bold',
    },
    separator: {
        flex: 1,
        height: 1,
        backgroundColor: '#e4e4e4',
        marginLeft: 10,
    },
    leftAction: {
        backgroundColor: '#dd2c00',
       
        justifyContent: 'center',
        flex: 1,
        alignItems: 'flex-start',
    },
    rightAction: {
        backgroundColor: '#388e3c',
        // backgroundColor: '#dd2c00',
        justifyContent: 'center',
        // flex: 1,
        alignItems: 'center',
        flexDirection: 'row',

    },
    actionText: {
        color: '#fff',
        fontWeight: '600',
        padding: 20,
    },
});

export const Separator = () => <View style={styles.separator} />;

const LeftActions = (progress, dragX, onPress) => {
    const scale = dragX.interpolate({
        inputRange: [0, 100],
        outputRange: [0, 1.3],
        extrapolate: 'clamp',
    });
    return (
        <View style={styles.leftAction}>
            <TouchableOpacity onPress={onPress}>
                <Animated.Text useNativeDriver={true} style={[styles.actionText, { transform: [{ scale }] }]}>
                    Deleting Item
        </Animated.Text>
            </TouchableOpacity>
        </View>
    );
};

const RightActions = ({ progress, dragX, onPress }) => {
    const scale = dragX.interpolate({
        inputRange: [-100, 0],
        outputRange: [1, 0],
        extrapolate: 'clamp',
    });
    return (

        <View style={styles.rightAction}>
            <TouchableOpacity onPress={onPress}>
                <View style={{ backgroundColor: 'blue' }}>
                    <Animated.Text useNativeDriver={true} style={[styles.actionText, { transform: [{ scale }] }]}>
                        Edit
        </Animated.Text>
                </View>
            </TouchableOpacity>
        </View>

    );
};

const ListItem = ({ id, index, pdt_name,price,quantity, amounts, onSwipeFromLeft, onRightPress }) => (
    <Swipeable
        renderLeftActions={LeftActions}
        onSwipeableLeftOpen={onSwipeFromLeft}
        renderRightActions={(progress, dragX) => (
            <RightActions progress={progress} dragX={dragX} onPress={onRightPress} />
        )}
    >
        <View style={styles.container}>
            <Text style={{
                color: '#4a4a4a',
                fontSize: 15,
                marginLeft: 5, marginTop: 5, width: 20,}}>{index} </Text>
            <Text style={styles.text}>{pdt_name}</Text>
            <Text style={{
                color: '#4a4a4a',
                fontSize: 15,
                marginLeft: 1,
                marginTop: 5,
                paddingRight: 5,
                width: 40,
            }}>{quantity}</Text>
            <Text style={styles.price}>{(price ).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</Text>
           
            <Text style={[styles.price, { marginLeft: 10, color: '#6cc', }]}>{(amounts).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</Text>
        </View>
    </Swipeable>
);

export default ListItem;