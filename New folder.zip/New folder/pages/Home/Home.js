import React,{useState} from 'react';
import {
  ActivityIndicator,
  StyleSheet, Dimensions, Image, View, SafeAreaView, FlatList,
  ScrollView, TouchableHighlight, TouchableOpacity,
  Button
} from 'react-native';
import {Text, TextInput} from 'react-native-paper'; 
import EmptyList from '../../components/EmptyList';
import { withNavigation } from 'react-navigation';
import moment from 'moment';
//import { AppContext } from '../Auth';
import { UserContext } from '../../App';
import * as SecureStore from 'expo-secure-store';
import uuid from 'react-native-uuid';
//import { v4 as uuidv4 } from 'uuid';
import Icon from '@expo/vector-icons/Foundation';
import POSIcon from '@expo/vector-icons/FontAwesome5';
import MyButton from '../../components/MyButton';
import gql from 'graphql-tag';
import AsyncStorage from '@react-native-community/async-storage';
import { Query, Mutation } from 'react-apollo';
import { FETCH_TODOS } from '../Queries';

let icon_name, name, items, createdAt, amount;
export const FETCH_TRANSACTIONS = gql`
query ($org_id: String!){
    transactions(where: {orgID:{_eq: $org_id}})
      {
        id
        orgID
        dept_id
        account_id
        product_id
        cashflow
        amount
        items
        name
        createdAT
        icon
        cashflowByCashflowId{
          icon
          name
          type
          id
        }
        accountByAccount{
          id
          color
          name
        }
      }
      products(where: {org_id: {_eq: $org_id}}){
        id
        alias
        barcode
        name 
        quantity
        units
        pdt_id
        category
        cost
        price
      }
      cashflows(where: {orgID: {_eq: $org_id}}){
        id
        name
        icon
        type
        orgID
      }
      accounts(where:{orgID: {_eq:$org_id}}){
        id
        name
        color
        initialBalance
      }
  }
`;

/* const INSERT_TODO = gql`

  mutation insert_todos($input: CreateTodosInput){
    insert_todos (
      input: $input
    ){
      returning {
        id
        text
        is_complete
      }
    }
  }
  input CreateTodosInput{
  text: String!
  userId: String!
}
`; */
const INSERT_TODOS = gql`
  mutation ($text: String!, $userId: String!){
    insert_todos (
      objects: [{
        text: $text,
        user_id: $userId,
      }]
    ){
      returning {
        id
        text
        is_complete
      }
    }
  }
`;
// 
const quotes = [
];

export const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Items',
    icons: 'plus',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63]5',
    title: 'Second Item',
    icons: 'plus',

  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
    icons: 'minus',

  },
  {
    id: '453694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
    icons: 'home',

  },
];

keyExtractor = (item, index) => index.toString();

function Item({ color, title, icons, id, icon,iconColor, amount, name, createdAt, items }) {
  return (
    <View style={[styles.item,{width:vw * 0.8}]}>
      <View style={[styles.circle, {backgroundColor:"#fff"}]}><POSIcon name={icon} style={[styles.icons,{color:iconColor}]} /></View>
      <View style={styles.itemContainer}>
        <Text style={styles.title}>{name}</Text>
  <Text style={styles.subtitle2}>{items}</Text>
        <Text style={styles.subtitle3}>{createdAt}</Text>
      </View>
      <Text style={[styles.subtitle4, {color: color, alignItems:'flex-end'}]}>{amount}</Text>
    </View>
  );
}
function trans({ title, icons }) {
  return (
    <View style={styles.item}>
      <View style={styles.circle}><Icon name={"plus"} style={styles.icons} /></View>
      <View style={styles.itemContainer}>
        <Text style={styles.title}>{text}</Text>
        <Text style={styles.subtitle2}>{text}2</Text>
        <Text style={styles.subtitle3}>{text}3</Text>
      </View>
      <Text style={styles.subtitle4}>{text}4</Text>
    </View>
  );
}

function Home({ navigation }) {
  const Dcontext = React.useContext(UserContext);
  const [text, setText] = React.useState(null);
  const [userId, setUserID] = React.useState(null);
  const [org_id, setOrg_id] = React.useState(Dcontext.org_id);
  const [list, setList] = React.useState(quotes);
  const [isLoading, setIsLoading] = useState(false);


  
  return (
    <View style={{ flex: 1 }}>
      <SafeAreaView>
        <View style={styles.list}>
          <Query query={FETCH_TRANSACTIONS} 
          variables={{ org_id }} 
          
          fetchPolicy='cache-and-network'>
            {({ loading, error, data, refetch }) => {
              if (loading) return <View styles={styles.activity}>
                <ActivityIndicator size="large" color="#000ff" />
              </View>
              if (error) return <View>{console.log("my error gql " + error)}
                <Text>Data loading error ${error.message} </Text></View>
             
             try {
              AsyncStorage.setItem('priceList', JSON.stringify(data.products));
              AsyncStorage.setItem('accountValues', JSON.stringify(data.accounts));
              AsyncStorage.setItem('cashFlowValues',JSON.stringify(data.cashflows));
          } catch (error) {
              
          }
             return (
                <FlatList
                  data={data.transactions}
                  ListEmptyComponent={<EmptyList containerStyle={{ width: 300, }} />}
                  renderItem={({ item, index }) =>
                    <View style={{
                      backgroundColor: index % 2 == 0 ? "#344a" : "#cdfe"
                    }} {...item} key={item.id}>
{ item.cashflow==='pos' ?
                      <TouchableHighlight
                        style={styles.icon_button}
                        underlayColor="#ccc"
                        onPress={() => { alert("hi here " + item.icon); }
                        }
                      >
                        <Item name={item.name} 
                        color={'blue'}
                        iconColor={item.accountByAccount.color}
                        createdAt={moment(item.createdAT).format('MMM Do YYYY, h:mm:ss a')} items={item.items}
                          amount={"+"+Number(item.amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')} icon={'barcode'} id={item.id} />
                      </TouchableHighlight>
                      :
                      <TouchableHighlight
                        style={styles.icon_button}
                        underlayColor="#ccc"
                        onPress={() => { alert("hi here " + item.icon); }
                        }
                      >
                        <Item name={item.cashflowByCashflowId.name} createdAt={moment(item.createdAT).format('MMM Do YYYY, h:mm:ss a')} 
                        items={item.name}
                         color={item.cashflowByCashflowId.type =='expense' ? 
                         "red" : "green"
                       }
                        iconColor={item.accountByAccount.color}
                         amount={ item.cashflowByCashflowId.type =='expense' ? 
                         "-"+(item.amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                          : 
                          "+"+(item.amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                        }
                        
                         
                          icon={item.cashflowByCashflowId.icon} id={item.id} />
                      </TouchableHighlight>
                      }
                    </View>}
                  
                  keyExtractor={item => item.id.toString()}
                  refreshing={isLoading}
                  onRefresh={() => { refetch() }}

                />

              );
            }
            }
          </Query>
        </View>

      </SafeAreaView>
      <MyButton />

    </View>
  );
}
/*  

  }
} */
const vw = Dimensions.get('screen').width;
const vh = Dimensions.get('screen').height;

const styles = StyleSheet.create({
  MainContainer: {
    flex: 1,
    paddingTop: 5,
    //alignItems: 'center',
    marginTop: 20,
    //justifyContent: 'center',
  },
  item: {
    flexDirection: 'row',
    padding: 2,
    marginLeft: 2,
  },
  itemContainer: {
    //flexDirection: "row-reverse",
    //flex: 1,
    //alignContent: 'space-around',
    marginStart: 10,
  },

  subtitle4: {
    marginEnd: 10,
    fontSize: 24,
    fontWeight: 'bold',
    //alignItems:'flex-end',
    justifyContent:'space-between',
    //paddingRight:5,
    marginTop: 14,
  },
  subtitle3: {
    fontSize: 14,
    //marginEnd: 10,
    opacity: 0.5,
    fontWeight: 'bold',
  },
  subtitle2: {
    marginLeft: 0,
    fontSize: 12,
    fontWeight: 'bold',
    opacity: 0.5,
  },
  icons: {
    fontSize: 40,
    //color: 'white',
  },
  circle: {
    height: 50,
    width: 50,
    color: "#fff",
    borderRadius: 35,
    borderTopLeftRadius: 35,
    borderTopRightRadius: 35,
    borderBottomLeftRadius: 35,
    borderBottomRightRadius: 35,
    backgroundColor: '#002f32',
    alignItems: 'center',
    justifyContent: 'center'
  },
  //for the coffee
  container: {
    height: vh,
    width: vw,
    backgroundColor: '#fdfdfd'
  },
  header: {
    width: vw,
    height: vw / 1.6,
    resizeMode: 'contain'
  },
  title: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 21,
    color: '#252525'
  },
  subtitle: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#bf200b'
  },

  block: {
    flex: 1,
    height: vh / 4,
    margin: vw / 40
  },
  productImage: {
    width: '100%',
    height: vh / 7,
    resizeMode: 'contain',
    backgroundColor: '#ffffff'
  },
  name: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#252525',
    width: '80%',
    marginTop: 15
  },
  price: {
    fontFamily: 'maven-pro-bold',
    fontSize: vw / 22,
    color: '#bf200b',
    marginTop: 7
  },
  list: {
    height: vh * 0.8,
    //top: vh / 20,
    marginBottom:20,
    //position:'absolute',
  },

  slide1: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9DD6EB'
  },
  slide2: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#97CAE5'
  },
  slide3: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#92BBD9'
  },
  text: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold'
  },
});
export default withNavigation(Home);