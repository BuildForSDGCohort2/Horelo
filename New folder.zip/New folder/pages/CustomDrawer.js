//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component,useContext } from 'react';
import { View, StyleSheet, Image, Text,SafeAreaView, TouchableOpacity} from 'react-native';
//import { Icon } from 'react-native-elements';
import Icon from '@expo/vector-icons/FontAwesome5';
import { UserContext } from '../App';
//import { withNavigation } from 'react-navigation';


const addAccount = require('../assets/images/cYoLyf.png');
function CustomSidebarMenu({navigation}) {
    const userDetail = useContext(UserContext);
    React.useEffect(() => {
    }, [userDetail.avatar]);
  const items = [{
                navOptionThumb: 'home',
                navOptionName: 'Home',
                screenToNavigate: 'Home',
            },
            {
                navOptionThumb: 'book',
                navOptionName: 'Accounts',
                screenToNavigate: 'Accounts',
            },
            {
                navOptionThumb: 'chart-area',
                navOptionName: 'Reports',
                screenToNavigate: 'Reports',
            },
            {
                navOptionThumb: 'folder',
                navOptionName: 'Stock',
                screenToNavigate: 'Stock',
            },
            {
                navOptionThumb: 'book-open',
                navOptionName: 'Cash Flows',
                screenToNavigate: 'CashFlows',
            },
            {
                navOptionThumb: 'cogs',
                navOptionName: 'Settings',
                screenToNavigate: 'Settings',
            }
        ];
  
        return (
            <SafeAreaView>
            <View style={styles.sideMenuContainer}>

                    <View style={styles.rowItem}>
                        {/*Top Large Image */}
                        
                        <TouchableOpacity
                        >
                            {userDetail.avatar !== null ? <Image source={{ uri: userDetail.avatar }} style={styles.sideMenuProfileIcon} /> :
                                <Image
                                    source={addAccount}
                                    //source={{ uri: this.profileImage }}
                                    style={styles.sideMenuProfileIcon}
                                />
                            }
                        </TouchableOpacity>
                        <View style={styles.textItem}>
                            <Text>{userDetail.username}</Text>

                            
                        </View>
                        

            </View>
                    <View padding={5} />
                    <Text style={{paddingLeft:15}}>{userDetail.email}</Text> 
                {/*Divider between Top Image and Sidebar Option*/}
                <View
                    style={{
                        width: '100%',
                        height: 1,
                        backgroundColor: '#f8e8f8',
                        marginTop: 10,
                    }}
                />
                
                {/*Setting up Navigation Options from option array using loop*/}
                <View style={{ width: '100%' }}>
                     {/*    {this.items.map((item, key) => ( */}
                    {items.map((item, key) => (
                        <View
                            style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                paddingTop: 10,
                                paddingBottom: 10,
                                backgroundColor: global.currentScreenIndex === key ? '#e0dbdb' : '#ffffff',
                            }}
                            key={key}>
                            <View style={{ marginRight: 10, marginLeft: 20 }}>
                                <Icon name={item.navOptionThumb} size={25} color="#808080" />
                            </View>
                            <Text
                                style={{
                                    fontSize: 15,
                                    color: global.currentScreenIndex === key ? 'red' : 'black',
                                }}
                                onPress={() => {
                                    global.currentScreenIndex = key;
                                    navigation.navigate(item.screenToNavigate);
                                }}>
                                {item.navOptionName}
                            </Text>
                        </View>
                    ))}
                </View>
               
            </View>
            </SafeAreaView>
        );
   // }
}
const styles = StyleSheet.create({
    sideMenuContainer: {
        width: '100%',
        height: '100%',
        backgroundColor: '#8ddd',
        paddingTop: 20,
    },
    sideMenuProfileIcon: {
        resizeMode:'contain',
        width: 150,
        height: 150,
        marginTop:20,
        margin: 10,
        borderRadius: 150 / 2,
    },
    rowItem:{
        flexDirection:'row',
    },
    textItem:{
        marginTop:25,
        fontWeight:'bold',
    }

});
//export default withNavigation(CustomSidebarMenu);
export default CustomSidebarMenu;