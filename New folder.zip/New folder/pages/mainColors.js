const mainColors = {
    lightTheme: {
        //light theme colors 
        type: 'light',
        fontColor: 'black'
    },
    darkTheme: {
        //dark theme colors
        type: 'dark',
        fontColor: 'white'
    }
    //common colors
}

export default mainColors;