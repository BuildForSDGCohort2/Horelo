//This is an example code for NavigationDrawer//
import React, { useState, useEffect, useContext, createContext } from "react";
import { UserContext } from '../App';

//import react in our code.
import { Image, StyleSheet, View, Text, Button, TouchableOpacity} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import * as SecureStore from 'expo-secure-store';
import {withNavigation} from 'react-navigation';
// import all basic components
import MyText from '../components/MyText';
import MyButtons from '../components/MyText';
import MyButton from '../components/MyText';
import Auth from './Auth';
//import { TouchableOpacity } from 'react-native-gesture-handler';



 /* class Login extends Component {
    state = {
        isLoggedIn: false,
        userId: null,
        username: null,
        jwt: null,
        loading: false
    } */

    /* login = (userId, username, token) => {
        this.setState({
            isLoggedIn: true,
            userId,
            username,
            jwt: token,
            loading: false
        });
    }
    logout = () => {
        this.setState({
            isLoggedIn: false,
            loading: false
        })
    }
    remember = async () => {
        const { email, password } = this.state;
        const credentials = { email, password };
        try {
            await SecureStore.setItemAsync(
                'camiloysuspasswords',
                JSON.stringify(credentials)
            );
            this.setState({ email: '', password: '' });
        } catch (e) {
            console.log(e);
        }
    };

    read = async () => {
        try {
            const credentials = await SecureStore.getItemAsync('@todo-graphql:auth0');
            console.log('value of credentials: ', credentials);

            if (credentials) {
                const myJson = JSON.parse(credentials);
                this.setState({
                    email: myJson.email,
                    password: myJson.password,
                });
            }
        } catch (e) {
            console.log(e);
        }
    };
    clear = async () => {
        try {
            await SecureStore.deleteItemAsync('@todo-graphql:auth0');
            this.setState({ email: '', password: '' });
        } catch (e) {
            console.log(e);
        }
    }; */

function Login ({navigation}) {
    const [isLoggedIn, setIsLoggedIn] = useState(true);
    const [loading, setLoading] = useState(false);
    const [userId, setUserId] = useState(null);
    const [username, setUsername] = useState(null);
    const [jwt, setJwt] = useState(null);
    const Dcontext = useContext(UserContext);

    
    const getItem = async () => {
        try{
        const res = await SecureStore.getItemAsync('MySecureAuthStateKey');
        const detail = JSON.parse(res);
        const rol = await AsyncStorage.getItem('CurrentProfile');
        const profiles = JSON.parse(rol);
        const { orgID, deptID, role, others } = profiles;
        Dcontext.setOrg_id(orgID);
        Dcontext.setDept_id(deptID);
        Dcontext.setRole(role);
        
        
if(detail){   
    const { avatar, name, email, token, id } = detail;
    Dcontext.setEmail(email);
    Dcontext.setUsername(name);
    Dcontext.setToken(token);
    Dcontext.setUserId(id);
    Dcontext.setAvatar(avatar);
       
        //setName(name);
        console.log(JSON.parse(res), 'hello here', token);
    setUsername(name);
    setIsLoggedIn(true);
    
   // navigation.navigate('App');
}
}
catch(e){
    setIsLoggedIn(false);
}     
// ...
    };
    const logo = require('../assets/brick.png');

  const  login = (userId, username, token) => {
        this.setState({
            isLoggedIn: true,
            userId,
            username,
            jwt: token,
            loading: false
        });
        
    }
    const logout = () => {
        this.setState({
            isLoggedIn: false,
            loading: false
        });
    }
    //Screen1 Component
    // render() {

       // const { isLoggedIn, userId, username, loading } = this.state;
        if (loading) {
            return (<View>
                <Image
                    resizeMode='cover'
                    source={logo}
                    style={styles.image}
                />
            </View>);
        }
        if (isLoggedIn) {
            getItem();
            return (

           <View></View>

            )
        } else {

            return (
                
                <View style={{flex:1}}>
                    
                        <Auth login={login} />
                    
                </View>
            );
        }

   // }
}

const styles = StyleSheet.create({
    MainContainer: {
        flex: 1,
        paddingTop: 5,
        alignItems: 'center',
        marginTop: 20,
        justifyContent: 'center',
    },
    item: {
        flexDirection: 'row',
        padding: 4,
        marginLeft: 1,
    },
    itemContainer: {
        //flexDirection: "row-reverse",
        flex: 1,
        alignContent: 'space-around',
        marginStart: 20,
    },
    title: {
        // marginStart: 20,
    },
    image: {
        flex: 1,
        width: 'auto',
        marginTop: 10,
    },
});
export default withNavigation(Login);