
export default {
  newAccountDateFormat: 'dddd, MM.DD.YYYY',
};
