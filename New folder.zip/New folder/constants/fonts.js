/* eslint-disable */

export default {
  'Quattrocento-Regular': require('../assets/fonts/QuattrocentoSans-Regular.ttf'),
};
