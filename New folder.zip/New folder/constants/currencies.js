export default {
  dollar: {
    name: '$ - US Dollar',
    sign: '$',
  },
  euro: {
    name: '€ - Euro',
    sign: '€',
  },
  hryvnia: {
    name: '₴ - Hryvnia',
    sign: '₴',
  },
};
